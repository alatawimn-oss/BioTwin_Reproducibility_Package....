"""
src/datasets/mimic4_dataset.py

MIMIC-IV ICU dataset for BioTwin-AgentNet.

Paper spec:
  50,000 patients, 127 variables, 1-hr resampling
  80/10/10 split, seed 42
  Three tasks: cardiac arrhythmia, sepsis, mortality (multi-label)
"""

from pathlib import Path
from typing import List, Optional, Tuple

import h5py
import numpy as np
import torch
from torch.utils.data import Dataset


class MIMIC4Dataset(Dataset):
    """
    Loads preprocessed MIMIC-IV HDF5 tensors.

    HDF5 layout (written by data/preprocess.py):
        X            : (N, 48, 127)  float32
        y            : (N,)          int64   — multi-label packed as int
        patient_ids  : (N,)          int64

    Args:
        hdf5_path:   Path to train.h5 / val.h5 / test.h5
        split_ids:   Optional list of patient IDs to restrict to
                     (from data/splits/mimic4_{split}_ids.txt)
        task:        "arrhythmia" | "sepsis" | "mortality" | "all"
                     "all" returns a 3-dim binary vector per sample
        client_id:   If not None, return only the shard for this FL client
        n_clients:   Total FL client count (used with client_id)
        seed:        Shuffling seed for client sharding
    """

    # bit positions in the packed int label (data/preprocess.py convention)
    TASK_BITS = {"arrhythmia": 0, "sepsis": 1, "mortality": 2}

    def __init__(
        self,
        hdf5_path: str | Path,
        split_ids: Optional[List[int]] = None,
        task: str = "arrhythmia",
        client_id: Optional[int] = None,
        n_clients: int = 100,
        seed: int = 42,
    ) -> None:
        super().__init__()
        self.hdf5_path = Path(hdf5_path)
        self.task = task
        self.client_id = client_id
        self.n_clients = n_clients

        if not self.hdf5_path.exists():
            raise FileNotFoundError(
                f"HDF5 file not found: {self.hdf5_path}\n"
                "Run data/preprocess.py --dataset mimic4 first."
            )

        with h5py.File(self.hdf5_path, "r") as hf:
            X_all   = hf["X"][:]           # (N, 48, 127)
            y_all   = hf["y"][:]           # (N,)
            ids_all = hf["patient_ids"][:] # (N,)

        # filter by split_ids if provided
        if split_ids is not None:
            id_set = set(split_ids)
            mask   = np.array([pid in id_set for pid in ids_all])
            X_all, y_all, ids_all = X_all[mask], y_all[mask], ids_all[mask]

        # shard for federated learning
        if client_id is not None:
            rng  = np.random.default_rng(seed)
            idx  = np.arange(len(X_all))
            rng.shuffle(idx)
            shards = np.array_split(idx, n_clients)
            shard  = shards[client_id % n_clients]
            X_all, y_all, ids_all = X_all[shard], y_all[shard], ids_all[shard]

        self.X   = torch.from_numpy(X_all.astype(np.float32))   # (N, 48, 127)
        self.ids = ids_all

        # decode labels
        if task == "all":
            # return (3,) binary vector
            labels = np.zeros((len(y_all), 3), dtype=np.float32)
            for t, bit in self.TASK_BITS.items():
                labels[:, bit] = ((y_all >> bit) & 1).astype(np.float32)
            self.y = torch.from_numpy(labels)
        else:
            bit    = self.TASK_BITS.get(task, 0)
            labels = ((y_all >> bit) & 1).astype(np.int64)
            self.y = torch.from_numpy(labels)

    # ── sequence length property (used by model builders) ────────────────────
    @property
    def seq_len(self) -> int:
        return self.X.shape[1]      # 48

    @property
    def n_features(self) -> int:
        return self.X.shape[2]      # 127

    def __len__(self) -> int:
        return len(self.X)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.X[idx], self.y[idx]

    # ── continual learning task interface ─────────────────────────────────────
    def as_task_subset(self, task_idx: int, n_tasks: int = 6) -> "MIMIC4Dataset":
        """
        Returns a shallow copy restricted to a temporal task shard.
        Used by EWC / replay in src/continual/.
        Paper: 6 continual tasks over the training split.
        """
        clone = object.__new__(MIMIC4Dataset)
        clone.hdf5_path  = self.hdf5_path
        clone.task       = self.task
        clone.client_id  = self.client_id
        clone.n_clients  = self.n_clients
        n       = len(self.X)
        shards  = np.array_split(np.arange(n), n_tasks)
        shard   = shards[task_idx % n_tasks]
        clone.X   = self.X[shard]
        clone.y   = self.y[shard]
        clone.ids = self.ids[shard]
        return clone


def load_split_ids(split_file: str | Path) -> List[int]:
    """Read a data/splits/mimic4_{split}_ids.txt file."""
    return [int(line.strip()) for line in open(split_file) if line.strip()]
