"""
src/datasets/physionet2019_dataset.py

PhysioNet Computing in Cardiology Challenge 2019 dataset.

Paper spec:
  40,336 records, 40 variables
  Task: sepsis early warning (binary, SepsisLabel)
  Used for generalisation evaluation across MIMIC-IV-trained model
"""

from pathlib import Path
from typing import Optional, Tuple

import h5py
import numpy as np
import torch
from torch.utils.data import Dataset


class PhysioNet2019Dataset(Dataset):
    """
    Loads the preprocessed PhysioNet 2019 HDF5 file.

    HDF5 layout (written by data/preprocess.py):
        X            : (N, 48, 40)   float32
        y            : (N,)          int64  — SepsisLabel (0/1)
        patient_ids  : (N,)          int64

    Args:
        hdf5_path:   Path to data/processed/physionet2019/all.h5
        client_id:   FL client shard index (None = full dataset)
        n_clients:   Total FL client count
        seed:        Sharding RNG seed
    """

    N_FEATURES = 40
    SEQ_LEN    = 48

    # Official 40-variable names from challenge description (in column order)
    FEATURE_NAMES = [
        "HR", "O2Sat", "Temp", "SBP", "MAP", "DBP", "Resp", "EtCO2",
        "BaseExcess", "HCO3", "FiO2", "pH", "PaCO2", "SaO2", "AST",
        "BUN", "Alkalinephos", "Calcium", "Chloride", "Creatinine",
        "Bilirubin_direct", "Glucose", "Lactate", "Magnesium", "Phosphate",
        "Potassium", "Bilirubin_total", "TroponinI", "Hct", "Hgb",
        "PTT", "WBC", "Fibrinogen", "Platelets", "Age", "Gender",
        "Unit1", "Unit2", "HospAdmTime", "ICULOS",
    ]

    def __init__(
        self,
        hdf5_path: str | Path,
        client_id: Optional[int] = None,
        n_clients: int = 100,
        seed: int = 42,
    ) -> None:
        super().__init__()
        self.hdf5_path = Path(hdf5_path)

        if not self.hdf5_path.exists():
            raise FileNotFoundError(
                f"HDF5 file not found: {self.hdf5_path}\n"
                "Run data/preprocess.py --dataset physionet2019 first."
            )

        with h5py.File(self.hdf5_path, "r") as hf:
            X_all   = hf["X"][:]
            y_all   = hf["y"][:]
            ids_all = hf["patient_ids"][:]

        if client_id is not None:
            rng    = np.random.default_rng(seed)
            idx    = np.arange(len(X_all))
            rng.shuffle(idx)
            shards = np.array_split(idx, n_clients)
            shard  = shards[client_id % n_clients]
            X_all, y_all, ids_all = X_all[shard], y_all[shard], ids_all[shard]

        self.X   = torch.from_numpy(X_all.astype(np.float32))
        self.y   = torch.from_numpy(y_all.astype(np.int64))
        self.ids = ids_all

    def __len__(self) -> int:
        return len(self.X)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.X[idx], self.y[idx]

    @property
    def seq_len(self) -> int:
        return self.X.shape[1]

    @property
    def n_features(self) -> int:
        return self.X.shape[2]

    @property
    def pos_weight(self) -> torch.Tensor:
        """BCE pos_weight for class imbalance (sepsis prevalence ~7%)."""
        n_pos = float(self.y.sum())
        n_neg = float(len(self.y) - n_pos)
        return torch.tensor(n_neg / max(n_pos, 1.0))
