"""
src/datasets/eicu_dataset.py

eICU Collaborative Research Database dataset.

Paper spec:
  52,000 records, 335 hospitals
  Used ONLY for knowledge distillation (Phase 2 training)
  No patient overlap with MIMIC-IV

DOI: 10.13026/C2WM1R
"""

from pathlib import Path
from typing import Optional, Tuple

import h5py
import numpy as np
import torch
from torch.utils.data import Dataset


class eICUDataset(Dataset):
    """
    Loads the preprocessed eICU HDF5 file for knowledge distillation.

    HDF5 layout (written by data/preprocess.py):
        X            : (N, 48, F)   float32   F = num vitals extracted
        y            : (N,)         int64     (zeros — labels unused for KD)
        patient_ids  : (N,)         int64

    In Phase 2 (distillation), the teacher model produces soft logits over
    this dataset; the student learns from those soft targets via
    src/distillation/kd.py (T=4, alpha=0.3).

    Args:
        hdf5_path:   Path to data/processed/eicu/distillation.h5
        hospital_id: If not None, restrict to records from this hospital
                     (uses eICU hospitalid field if available in HDF5)
        max_samples: Cap on number of records (for fast debugging)
    """

    SEQ_LEN = 48

    # eICU vitalPeriodic columns used in preprocess.py
    FEATURE_NAMES = [
        "temperature", "sao2", "heartrate", "respiration",
        "systemicsystolic", "systemicdiastolic", "systemicmean", "cvp",
    ]

    def __init__(
        self,
        hdf5_path: str | Path,
        hospital_id: Optional[int] = None,
        max_samples: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.hdf5_path = Path(hdf5_path)

        if not self.hdf5_path.exists():
            raise FileNotFoundError(
                f"HDF5 file not found: {self.hdf5_path}\n"
                "Run data/preprocess.py --dataset eicu first."
            )

        with h5py.File(self.hdf5_path, "r") as hf:
            X_all   = hf["X"][:]
            y_all   = hf["y"][:]
            ids_all = hf["patient_ids"][:]
            # hospital_ids stored optionally
            hosp_all = hf["hospital_ids"][:] if "hospital_ids" in hf else None

        if hospital_id is not None and hosp_all is not None:
            mask  = hosp_all == hospital_id
            X_all, y_all, ids_all = X_all[mask], y_all[mask], ids_all[mask]

        if max_samples is not None:
            X_all   = X_all[:max_samples]
            y_all   = y_all[:max_samples]
            ids_all = ids_all[:max_samples]

        self.X   = torch.from_numpy(X_all.astype(np.float32))
        self.y   = torch.from_numpy(y_all.astype(np.int64))
        self.ids = ids_all

    def __len__(self) -> int:
        return len(self.X)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.X[idx], self.y[idx]

    @property
    def seq_len(self) -> int:
        return self.X.shape[1]

    @property
    def n_features(self) -> int:
        return self.X.shape[2]
