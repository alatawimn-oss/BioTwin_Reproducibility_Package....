"""
src/distillation/kd.py

Phase 2 knowledge distillation orchestration: teacher → student on eICU.

Paper spec:
  Temperature    : T = 4
  Alpha          : alpha = 0.3  (soft loss weight)
  Dataset        : eICU (52K records, 335 hospitals)
  Result         : +0.079 AUROC improvement over training student from scratch
  Teacher        : Phase 1 TeacherLSTM (4.2M params, FP32)
  Student        : StudentLSTM (450K params → INT8 for edge)

Loss:
  L = alpha * T^2 * KLDiv(log_softmax(s/T), softmax(t/T))
       + (1-alpha) * CE(s, hard_labels)

The same DistillationLoss is in src/losses/distillation_loss.py;
this module wraps the full training loop for Phase 2.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from src.losses.distillation_loss import DistillationLoss
from src.utils.logging_utils import CSVLogger, get_tb_writer
from src.utils.checkpointing import save_checkpoint, load_checkpoint, latest_checkpoint


class KnowledgeDistillation:
    """
    Phase 2 KD training loop: distill TeacherLSTM → StudentLSTM on eICU.

    Usage:
        kd = KnowledgeDistillation(
            teacher=teacher_model,
            student=student_model,
            temperature=4.0,
            alpha=0.3,
        )
        kd.train(
            train_loader=eicu_loader,
            n_epochs=50,
            lr=1e-3,
            output_dir="checkpoints/phase2",
        )
    """

    def __init__(
        self,
        teacher: nn.Module,
        student: nn.Module,
        temperature: float = 4.0,    # paper T=4
        alpha: float       = 0.3,    # paper alpha=0.3
        device: str | torch.device = "cpu",
    ) -> None:
        self.teacher     = teacher
        self.student     = student
        self.device      = torch.device(device)
        self.loss_fn     = DistillationLoss(temperature=temperature, alpha=alpha)

        self.teacher.to(self.device).eval()
        for p in self.teacher.parameters():
            p.requires_grad_(False)   # Teacher frozen during KD

        self.student.to(self.device)

    # ------------------------------------------------------------------
    # Training loop
    # ------------------------------------------------------------------

    def train(
        self,
        train_loader: DataLoader,
        n_epochs: int        = 50,
        lr: float            = 1e-3,
        val_loader: Optional[DataLoader] = None,
        output_dir: str      = "checkpoints/phase2",
        resume: bool         = True,
        log_interval: int    = 50,
    ) -> dict:
        """
        Run Phase 2 KD training.

        Args:
            train_loader:  eICU DataLoader (X, y)
            n_epochs:      Training epochs [NOT STATED IN PAPER: 50]
            lr:            Student optimizer LR [NOT STATED IN PAPER: 1e-3]
            val_loader:    Optional validation loader (MIMIC-IV test split)
            output_dir:    Checkpoint + log directory
            resume:        Resume from latest checkpoint if available
            log_interval:  Log every N batches

        Returns:
            Dict with 'best_val_loss', 'final_epoch', and training history.
        """
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        optimizer = torch.optim.Adam(self.student.parameters(), lr=lr)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=n_epochs, eta_min=1e-5
        )

        csv_logger = CSVLogger(out_dir / "kd_metrics.csv")
        tb_writer  = get_tb_writer(out_dir / "tb_kd", comment="phase2_kd")

        start_epoch = 0
        best_val_loss = float("inf")

        # Resume
        if resume:
            ckpt_path = latest_checkpoint(out_dir)
            if ckpt_path:
                ckpt = load_checkpoint(ckpt_path, self.student, optimizer, device=self.device)
                start_epoch = ckpt.get("round", 0) + 1
                best_val_loss = ckpt.get("metrics", {}).get("val_loss", float("inf"))
                print(f"[KD] Resumed from epoch {start_epoch - 1}")

        history = []

        for epoch in range(start_epoch, n_epochs):
            self.student.train()
            epoch_loss = 0.0
            n_batches  = 0

            for batch_idx, (X, y) in enumerate(train_loader):
                X = X.to(self.device)
                y = y.to(self.device)

                optimizer.zero_grad()

                # Teacher soft labels (no_grad — teacher frozen)
                with torch.no_grad():
                    teacher_logits = self.teacher(X)

                # Student forward
                student_logits = self.student(X)

                # Combined KD + CE loss
                loss = self.loss_fn(student_logits, teacher_logits, y)
                loss.backward()

                # Gradient clipping [NOT STATED IN PAPER: 1.0]
                nn.utils.clip_grad_norm_(self.student.parameters(), 1.0)
                optimizer.step()

                epoch_loss += loss.item()
                n_batches  += 1

                if batch_idx % log_interval == 0:
                    global_step = epoch * len(train_loader) + batch_idx
                    tb_writer.add_scalar("kd/train_loss", loss.item(), global_step)

            avg_train_loss = epoch_loss / max(n_batches, 1)
            scheduler.step()

            row = {"epoch": epoch, "train_loss": avg_train_loss}

            # Optional validation
            val_loss = None
            if val_loader is not None:
                val_loss = self._evaluate(val_loader)
                row["val_loss"] = val_loss
                tb_writer.add_scalar("kd/val_loss", val_loss, epoch)

            csv_logger.log(row)
            history.append(row)

            # Checkpoint
            is_best = val_loss is not None and val_loss < best_val_loss
            if is_best:
                best_val_loss = val_loss
                save_checkpoint(
                    out_dir / "best_student.pt",
                    self.student,
                    optimizer,
                    round_or_epoch=epoch,
                    metrics={"val_loss": val_loss, "train_loss": avg_train_loss},
                )

            if (epoch + 1) % 10 == 0:
                save_checkpoint(
                    out_dir / f"student_epoch_{epoch:03d}.pt",
                    self.student,
                    optimizer,
                    round_or_epoch=epoch,
                    metrics=row,
                )

            print(
                f"[KD] Epoch {epoch}/{n_epochs - 1} | "
                f"train_loss={avg_train_loss:.4f}"
                + (f" | val_loss={val_loss:.4f}" if val_loss is not None else "")
            )

        tb_writer.close()
        return {
            "best_val_loss": best_val_loss,
            "final_epoch":   n_epochs - 1,
            "history":       history,
        }

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _evaluate(self, loader: DataLoader) -> float:
        """Compute mean distillation loss on a validation set."""
        self.student.eval()
        self.teacher.eval()
        total, n = 0.0, 0
        for X, y in loader:
            X = X.to(self.device)
            y = y.to(self.device)
            t_logits = self.teacher(X)
            s_logits = self.student(X)
            loss = self.loss_fn(s_logits, t_logits, y)
            total += loss.item()
            n     += 1
        return total / max(n, 1)

    # ------------------------------------------------------------------
    # Load best student
    # ------------------------------------------------------------------

    def load_best_student(self, output_dir: str = "checkpoints/phase2") -> None:
        """Load the best student checkpoint produced by train()."""
        best_path = Path(output_dir) / "best_student.pt"
        if best_path.exists():
            load_checkpoint(best_path, self.student, device=self.device)
            print(f"[KD] Loaded best student from {best_path}")
        else:
            print(f"[KD] Warning: no best_student.pt found at {best_path}")
