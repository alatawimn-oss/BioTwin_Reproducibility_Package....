from .kd import KnowledgeDistillation

__all__ = ["KnowledgeDistillation"]
