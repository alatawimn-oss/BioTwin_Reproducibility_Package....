"""
src/metrics/evaluation.py

All evaluation metrics reported in BioTwin-AgentNet.

Paper targets (Table 7 / Table 8 / Table 9 / Table 10):
  Cardiac arrhythmia  AUROC 0.943  CI (0.938, 0.948)
  Sepsis              AUROC 0.876  CI (0.869, 0.883)  6.2h early warning
  Mortality           AUROC 0.901  CI (0.895, 0.907)
  MI attack success   52.3%        95% Wilson CI (50.9%, 53.7%)
  Attribute inference 11.3% above random
  Catastrophic forgetting 6.3% (Table 10 full model)
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats
from sklearn.metrics import (
    average_precision_score,
    roc_auc_score,
)


# ── AUROC ─────────────────────────────────────────────────────────────────────

def compute_auroc(
    y_true: np.ndarray,
    y_score: np.ndarray,
    multi_class: str = "ovr",
) -> float:
    """
    Compute AUROC. Handles binary and multi-class.

    Args:
        y_true:      (N,) integer labels
        y_score:     (N,) or (N, C) predicted probabilities
        multi_class: 'ovr' or 'ovo' for multi-class

    Returns:
        AUROC scalar
    """
    if y_score.ndim == 2 and y_score.shape[1] == 2:
        y_score = y_score[:, 1]   # binary: take positive class prob
    return float(roc_auc_score(y_true, y_score, multi_class=multi_class
                               if y_score.ndim > 1 else "raise"))


# ── AUPRC ────────────────────────────────────────────────────────────────────

def compute_auprc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    if y_score.ndim == 2:
        y_score = y_score[:, 1]
    return float(average_precision_score(y_true, y_score))


# ── Wilson confidence interval ────────────────────────────────────────────────

def compute_wilson_ci(
    p: float,
    n: int,
    confidence: float = 0.95,
) -> Tuple[float, float]:
    """
    Wilson score interval for a proportion p observed over n samples.

    Paper uses this for:
      AUROC CI — approximated as proportion CI on the DeLong statistic
      MI attack CI: 52.3% (50.9%, 53.7%) with n=1000 (paper Sec IV-D)

    Args:
        p:          Observed proportion (e.g. 0.523)
        n:          Sample size
        confidence: Confidence level (0.95)

    Returns:
        (lower, upper) Wilson CI
    """
    z    = stats.norm.ppf(1 - (1 - confidence) / 2)
    denom = 1 + z ** 2 / n
    centre = (p + z ** 2 / (2 * n)) / denom
    margin = z * math.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / denom
    return max(0.0, centre - margin), min(1.0, centre + margin)


# ── Sepsis early-warning lead time ────────────────────────────────────────────

def compute_early_warning_hours(
    y_true: np.ndarray,
    y_score: np.ndarray,
    timestamps_hours: np.ndarray,
    threshold: float = 0.5,
) -> float:
    """
    Mean lead time (hours) between first positive prediction and
    clinical sepsis onset.

    Paper spec: 6.2h mean early warning (Table 7).

    Args:
        y_true:           (N,) binary labels (1 = sepsis event)
        y_score:          (N,) predicted probabilities per hour
        timestamps_hours: (N,) hour offset from ICU admission
        threshold:        Decision threshold (0.5)

    Returns:
        Mean lead time in hours for true-positive detections.
    """
    lead_times = []
    for i in np.where(y_true == 1)[0]:
        # earliest prediction above threshold before onset
        candidates = np.where(
            (y_score[:i+1] >= threshold) & (timestamps_hours[:i+1] <= timestamps_hours[i])
        )[0]
        if len(candidates) > 0:
            first_alert = timestamps_hours[candidates[0]]
            onset       = timestamps_hours[i]
            lead_times.append(float(onset - first_alert))
    return float(np.mean(lead_times)) if lead_times else 0.0


# ── Continual learning forgetting rate ────────────────────────────────────────

def compute_forgetting_rate(
    auroc_per_task_after_all: List[float],
    auroc_per_task_at_training: List[float],
) -> float:
    """
    Catastrophic forgetting rate (BWT — backward transfer).

    Paper spec (Table 10 full model): 6.3% forgetting.
    Definition: mean drop in AUROC on previously-seen tasks.

        FR = (1/T) * sum_t max(0, AUROC_t_at_train - AUROC_t_after_all)

    Args:
        auroc_per_task_after_all:    AUROC on each task after training all tasks
        auroc_per_task_at_training:  AUROC on each task right after it was trained

    Returns:
        Forgetting rate as a fraction (e.g. 0.063).
    """
    drops = [
        max(0.0, a_train - a_final)
        for a_train, a_final in zip(
            auroc_per_task_at_training, auroc_per_task_after_all
        )
    ]
    return float(np.mean(drops))


# ── Membership inference attack success rate ─────────────────────────────────

def compute_mi_attack_rate(
    model_outputs_members: np.ndarray,
    model_outputs_nonmembers: np.ndarray,
    threshold: Optional[float] = None,
) -> Dict[str, float]:
    """
    Shadow-model membership inference attack success rate.

    Paper spec (Table 9):
      MI success 52.3% (95% Wilson CI 50.9%–53.7%)
      Near-random (50%) confirms DP is working.

    Uses confidence-score thresholding attack (Shokri et al., 2017):
      A sample is classified as "member" if its prediction confidence
      exceeds the threshold.

    Args:
        model_outputs_members:    (N,) max softmax prob for training members
        model_outputs_nonmembers: (N,) max softmax prob for non-members
        threshold:                Decision threshold (None = Youden's J optimal)

    Returns:
        dict with 'success_rate', 'wilson_ci_lower', 'wilson_ci_upper'
    """
    n = len(model_outputs_members) + len(model_outputs_nonmembers)
    y_true  = np.concatenate([
        np.ones(len(model_outputs_members)),
        np.zeros(len(model_outputs_nonmembers)),
    ])
    y_score = np.concatenate([model_outputs_members, model_outputs_nonmembers])

    if threshold is None:
        # Youden's J: maximise sensitivity + specificity - 1
        from sklearn.metrics import roc_curve
        fpr, tpr, thresholds = roc_curve(y_true, y_score)
        j       = tpr - fpr
        threshold = float(thresholds[np.argmax(j)])

    y_pred     = (y_score >= threshold).astype(int)
    success    = float((y_pred == y_true).mean())
    ci_lo, ci_hi = compute_wilson_ci(success, n)
    return {
        "success_rate":      success,
        "wilson_ci_lower":   ci_lo,
        "wilson_ci_upper":   ci_hi,
        "threshold":         threshold,
    }


# ── Unified evaluation suite ──────────────────────────────────────────────────

class EvaluationSuite:
    """
    Runs all paper metrics in one call and returns a results dict.

    Usage:
        suite   = EvaluationSuite()
        results = suite.evaluate(y_true, y_score, task="sepsis")
    """

    PAPER_TARGETS = {
        "arrhythmia": {"auroc": 0.943, "ci": (0.938, 0.948)},
        "sepsis":     {"auroc": 0.876, "ci": (0.869, 0.883),
                       "early_warning_h": 6.2},
        "mortality":  {"auroc": 0.901, "ci": (0.895, 0.907)},
    }

    def evaluate(
        self,
        y_true: np.ndarray,
        y_score: np.ndarray,
        task: str = "sepsis",
        n_bootstrap: int = 1000,
        seed: int = 42,
    ) -> Dict[str, float]:
        """
        Args:
            y_true:      (N,) integer labels
            y_score:     (N,) or (N,2) predicted probabilities
            task:        "arrhythmia" | "sepsis" | "mortality"
            n_bootstrap: Bootstrap replicates for CI
            seed:        RNG seed for bootstrap

        Returns:
            Dict with auroc, auprc, ci_lower, ci_hi, matches_paper flag.
        """
        if y_score.ndim == 2:
            scores_1d = y_score[:, 1]
        else:
            scores_1d = y_score

        auroc = compute_auroc(y_true, scores_1d)
        auprc = compute_auprc(y_true, scores_1d)

        # Bootstrap CI
        rng      = np.random.default_rng(seed)
        boot_auc = []
        for _ in range(n_bootstrap):
            idx = rng.integers(0, len(y_true), len(y_true))
            try:
                boot_auc.append(compute_auroc(y_true[idx], scores_1d[idx]))
            except ValueError:
                pass
        ci_lo = float(np.percentile(boot_auc, 2.5)) if boot_auc else 0.0
        ci_hi = float(np.percentile(boot_auc, 97.5)) if boot_auc else 0.0

        target = self.PAPER_TARGETS.get(task, {})
        t_auroc = target.get("auroc", None)
        t_ci    = target.get("ci", (None, None))

        return {
            "task":          task,
            "auroc":         auroc,
            "auprc":         auprc,
            "ci_lower":      ci_lo,
            "ci_upper":      ci_hi,
            "paper_target":  t_auroc,
            "within_ci":     (
                t_ci[0] is not None
                and t_ci[0] <= auroc <= t_ci[1]
            ),
        }
