"""
src/meta/neural_process.py

Neural Process (NP) for uncertainty-aware few-shot prediction.

[NOT STATED IN PAPER]: The paper references MAML for edge adaptation
(23.1 ms). A Neural Process is included here as an optional uncertainty
quantification complement to MAML — it provides predictive distributions
over new patients given context sets, complementing the point-estimate
adaptation of MAML.

This is a Conditional Neural Process (CNP) variant that:
  1. Encodes context (support) pairs (X, y) into a latent representation r
  2. Conditions the decoder on r to produce predictions on target X
  3. Provides mean + variance (aleatoric uncertainty) for clinical safety

[NOT STATED IN PAPER]:
  encoder_hidden : 128
  decoder_hidden : 128
  r_dim          : 64
  Input sequence is average-pooled from (T,F) -> F before NP encoding
"""

from __future__ import annotations

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class _Encoder(nn.Module):
    """Encodes (x, y) pairs to fixed-size representation r."""

    def __init__(self, x_dim: int, y_dim: int, hidden: int, r_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(x_dim + y_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, r_dim),
        )

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x : (B, N_ctx, x_dim)
            y : (B, N_ctx, y_dim)
        Returns:
            r : (B, r_dim) aggregated representation
        """
        xy   = torch.cat([x, y], dim=-1)          # (B, N_ctx, x_dim+y_dim)
        r_i  = self.net(xy)                        # (B, N_ctx, r_dim)
        r    = r_i.mean(dim=1)                     # (B, r_dim) — mean aggregation
        return r


class _Decoder(nn.Module):
    """Decodes (x_target, r) to prediction distribution."""

    def __init__(self, x_dim: int, r_dim: int, hidden: int, out_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(x_dim + r_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
        )
        self.mean_head = nn.Linear(hidden, out_dim)
        self.var_head  = nn.Linear(hidden, out_dim)

    def forward(
        self, x_target: torch.Tensor, r: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x_target : (B, N_tgt, x_dim)
            r        : (B, r_dim)
        Returns:
            mean, var: each (B, N_tgt, out_dim)
        """
        B, N_tgt, _ = x_target.shape
        r_exp = r.unsqueeze(1).expand(-1, N_tgt, -1)      # (B, N_tgt, r_dim)
        xr    = torch.cat([x_target, r_exp], dim=-1)
        h     = self.net(xr)
        mean  = self.mean_head(h)
        var   = F.softplus(self.var_head(h)) + 1e-6       # positive variance
        return mean, var


class NeuralProcess(nn.Module):
    """
    Conditional Neural Process for uncertainty-aware patient adaptation.

    Usage:
        np_model = NeuralProcess(x_dim=127, y_dim=1)
        # Encode context (support set):
        r = np_model.encode_context(ctx_X, ctx_y)
        # Predict on targets:
        mean, var = np_model.decode(query_X, r)
        # Training:
        loss = np_model.compute_loss(ctx_X, ctx_y, tgt_X, tgt_y)
    """

    def __init__(
        self,
        x_dim:          int = 127,   # number of features (after temporal pooling)
        y_dim:          int = 1,     # 1 for binary (BCE); n_classes for CE
        r_dim:          int = 64,    # [NOT STATED IN PAPER]
        encoder_hidden: int = 128,   # [NOT STATED IN PAPER]
        decoder_hidden: int = 128,   # [NOT STATED IN PAPER]
        out_dim:        int = 1,     # output dimension (1 for binary probability)
    ) -> None:
        super().__init__()
        self.x_dim   = x_dim
        self.y_dim   = y_dim
        self.r_dim   = r_dim
        self.out_dim = out_dim

        # Temporal pooling: (T, F) -> F
        self._pool = nn.AdaptiveAvgPool1d(1)

        self.encoder = _Encoder(x_dim, y_dim, encoder_hidden, r_dim)
        self.decoder = _Decoder(x_dim, r_dim, decoder_hidden, out_dim)

    def _pool_sequence(self, X: torch.Tensor) -> torch.Tensor:
        """
        Pool (B, [N,] T, F) sequence to (B, [N,] F) via average pooling.
        """
        if X.dim() == 3:
            # (B, T, F) -> (B, F)
            return X.mean(dim=1)
        elif X.dim() == 4:
            # (B, N, T, F) -> (B, N, F)
            B, N, T, F = X.shape
            return X.mean(dim=2)
        return X

    def encode_context(
        self,
        ctx_X: torch.Tensor,
        ctx_y: torch.Tensor,
    ) -> torch.Tensor:
        """
        Encode context (support) set to aggregated representation r.

        Args:
            ctx_X : (B, N_ctx, T, F) or (B, N_ctx, F)
            ctx_y : (B, N_ctx) or (B, N_ctx, y_dim)

        Returns:
            r : (B, r_dim)
        """
        if ctx_X.dim() == 4:
            ctx_X = self._pool_sequence(ctx_X)             # (B, N_ctx, F)
        if ctx_y.dim() == 2:
            ctx_y = ctx_y.unsqueeze(-1).float()            # (B, N_ctx, 1)
        return self.encoder(ctx_X, ctx_y)

    def decode(
        self,
        tgt_X: torch.Tensor,
        r:     torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Predict distribution on target inputs given context representation.

        Args:
            tgt_X : (B, N_tgt, T, F) or (B, N_tgt, F)
            r     : (B, r_dim)

        Returns:
            mean : (B, N_tgt, out_dim)
            var  : (B, N_tgt, out_dim)
        """
        if tgt_X.dim() == 4:
            tgt_X = self._pool_sequence(tgt_X)
        return self.decoder(tgt_X, r)

    def forward(
        self,
        ctx_X:  torch.Tensor,
        ctx_y:  torch.Tensor,
        tgt_X:  torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Full forward pass: encode context -> decode targets.

        Returns:
            mean, var: each (B, N_tgt, out_dim)
        """
        r = self.encode_context(ctx_X, ctx_y)
        return self.decode(tgt_X, r)

    def compute_loss(
        self,
        ctx_X:  torch.Tensor,
        ctx_y:  torch.Tensor,
        tgt_X:  torch.Tensor,
        tgt_y:  torch.Tensor,
    ) -> torch.Tensor:
        """
        Gaussian NLL loss on target set given context encoding.

        L = -log N(y_tgt | mu, sigma^2)

        Args:
            ctx_X, ctx_y : context (support) tensors
            tgt_X, tgt_y : target tensors

        Returns:
            Scalar loss tensor.
        """
        mean, var = self.forward(ctx_X, ctx_y, tgt_X)

        if tgt_y.dim() == 2:
            tgt_y = tgt_y.unsqueeze(-1).float()

        # Gaussian NLL
        nll = 0.5 * (
            torch.log(var)
            + ((tgt_y - mean) ** 2) / var
            + torch.log(torch.tensor(2 * 3.14159265))
        )
        return nll.mean()

    def predict(
        self,
        ctx_X:  torch.Tensor,
        ctx_y:  torch.Tensor,
        tgt_X:  torch.Tensor,
        return_uncertainty: bool = True,
    ) -> dict:
        """
        Convenience method for inference.

        Returns dict with:
            'mean'  : (B, N_tgt, out_dim) predicted means
            'var'   : (B, N_tgt, out_dim) predicted variances (if requested)
            'prob'  : sigmoid(mean) for binary classification
        """
        self.eval()
        with torch.no_grad():
            mean, var = self.forward(ctx_X, ctx_y, tgt_X)

        result = {"mean": mean, "prob": torch.sigmoid(mean)}
        if return_uncertainty:
            result["var"] = var
        return result
