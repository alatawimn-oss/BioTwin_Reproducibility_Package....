"""
src/meta/maml.py

MAML (Model-Agnostic Meta-Learning) for fast edge adaptation.

Paper spec:
  Setting        : 2-way 5-shot (binary classification, 5 support examples)
  Meta-tasks     : 1000 per epoch
  Inner steps    : 5
  Inner LR       : alpha = 0.01
  Edge adaptation: 23.1 ms on Jetson Nano (empirical; not enforced here)
  Purpose        : Enable new-patient personalization with minimal labeled data

Reference:
  Finn et al., "Model-Agnostic Meta-Learning for Fast Adaptation of Deep
  Networks," ICML 2017. https://arxiv.org/abs/1703.03400
  [NOTE: arXiv cited for reference only; not included in paper references]

[NOT STATED IN PAPER]:
  - Meta outer LR (beta): 1e-3 (standard MAML default)
  - Second-order gradients: disabled (first-order MAML / FOMAML) for
    efficiency on edge hardware
  - N_way: 2 (binary classification matches arrhythmia/sepsis/mortality tasks)
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset


@dataclass
class MAMLTask:
    """
    One meta-learning episode (N-way K-shot task).

    support_X : (K*N, T, F) support set inputs
    support_y : (K*N,)      support set labels
    query_X   : (Q*N, T, F) query set inputs
    query_y   : (Q*N,)      query set labels
    """
    support_X: torch.Tensor
    support_y: torch.Tensor
    query_X:   torch.Tensor
    query_y:   torch.Tensor


class MAML:
    """
    First-order MAML (FOMAML) wrapper for fast adaptation.

    Paper spec: 2-way 5-shot, 5 inner steps, alpha=0.01, 1000 meta-tasks/epoch.

    Usage:
        maml = MAML(model, inner_lr=0.01, inner_steps=5, outer_lr=1e-3)
        # Meta-training loop:
        for epoch in range(n_epochs):
            tasks = sample_tasks(dataset, n_tasks=1000, N=2, K=5)
            meta_loss = maml.meta_train_epoch(tasks, device)
        # Edge adaptation (inference time):
        adapted = maml.adapt(model, support_X, support_y, device)
        preds   = adapted(query_X)
    """

    def __init__(
        self,
        model: nn.Module,
        inner_lr: float    = 0.01,     # alpha in paper
        inner_steps: int   = 5,
        outer_lr: float    = 1e-3,     # beta [NOT STATED IN PAPER]
        first_order: bool  = True,     # FOMAML (second-order off for edge speed)
        device: str | torch.device = "cpu",
    ) -> None:
        self.model       = model
        self.inner_lr    = inner_lr
        self.inner_steps = inner_steps
        self.first_order = first_order
        self.device      = torch.device(device)
        self.outer_opt   = torch.optim.Adam(model.parameters(), lr=outer_lr)

    # ------------------------------------------------------------------
    # Inner loop (task adaptation)
    # ------------------------------------------------------------------

    def _inner_update(
        self,
        fast_model: nn.Module,
        X: torch.Tensor,
        y: torch.Tensor,
    ) -> nn.Module:
        """
        Run inner_steps gradient steps on the fast (copied) model.
        Returns the adapted model.
        """
        fast_model.train()
        for _ in range(self.inner_steps):
            logits = fast_model(X)
            loss   = F.cross_entropy(logits, y.long())
            grads  = torch.autograd.grad(
                loss,
                fast_model.parameters(),
                create_graph=not self.first_order,
                allow_unused=True,
            )
            # Manual SGD update
            with torch.no_grad():
                for param, grad in zip(fast_model.parameters(), grads):
                    if grad is not None:
                        param.sub_(self.inner_lr * grad)
        return fast_model

    # ------------------------------------------------------------------
    # Meta-training
    # ------------------------------------------------------------------

    def meta_train_step(
        self,
        tasks: List[MAMLTask],
    ) -> float:
        """
        One outer-loop update over a batch of tasks.
        Returns mean query loss (float).
        """
        self.outer_opt.zero_grad()
        total_query_loss = torch.tensor(0.0, device=self.device)

        for task in tasks:
            # Clone model for this task's inner loop
            fast_model = deepcopy(self.model).to(self.device)

            sX = task.support_X.to(self.device)
            sy = task.support_y.to(self.device)
            qX = task.query_X.to(self.device)
            qy = task.query_y.to(self.device)

            # Inner adaptation
            fast_model = self._inner_update(fast_model, sX, sy)

            # Evaluate on query set
            fast_model.train()  # keep BN/Dropout active
            q_logits   = fast_model(qX)
            query_loss = F.cross_entropy(q_logits, qy.long())
            total_query_loss = total_query_loss + query_loss

        # Average over tasks; backprop through query losses
        meta_loss = total_query_loss / max(len(tasks), 1)
        meta_loss.backward()
        self.outer_opt.step()

        return meta_loss.item()

    def meta_train_epoch(
        self,
        all_tasks: List[MAMLTask],
        meta_batch_size: int = 4,
    ) -> float:
        """
        Run one full epoch of meta-training (1000 tasks, paper spec).
        Tasks are processed in mini-batches.
        Returns mean query loss over the epoch.
        """
        losses = []
        for start in range(0, len(all_tasks), meta_batch_size):
            batch = all_tasks[start: start + meta_batch_size]
            loss  = self.meta_train_step(batch)
            losses.append(loss)
        return float(sum(losses) / max(len(losses), 1))

    # ------------------------------------------------------------------
    # Edge adaptation (inference / test-time)
    # ------------------------------------------------------------------

    def adapt(
        self,
        model: nn.Module,
        support_X: torch.Tensor,
        support_y: torch.Tensor,
        n_steps: Optional[int] = None,
        device: Optional[str | torch.device] = None,
    ) -> nn.Module:
        """
        Adapt a (possibly INT8-quantized) model to a new patient using
        support examples.  Returns an adapted copy; original unchanged.

        Paper: 23.1 ms on Jetson Nano for 5 inner steps.

        Args:
            model:     Pre-trained StudentLSTM (or any nn.Module)
            support_X: (K, T, F) support set
            support_y: (K,) labels
            n_steps:   Override inner steps (default: self.inner_steps)
            device:    Target device

        Returns:
            Adapted model (copy, not in-place).
        """
        dev = torch.device(device) if device else self.device
        fast = deepcopy(model).to(dev)
        fast.train()

        sX = support_X.to(dev)
        sy = support_y.to(dev)

        steps = n_steps if n_steps is not None else self.inner_steps
        # Use a temporary inner loop (no create_graph at inference)
        orig_first_order = self.first_order
        self.first_order = True
        try:
            fast = self._inner_update(fast, sX, sy)
        finally:
            self.first_order = orig_first_order

        fast.eval()
        return fast

    # ------------------------------------------------------------------
    # Task sampling utilities
    # ------------------------------------------------------------------

    @staticmethod
    def sample_tasks(
        dataset,
        n_tasks: int = 1000,
        N_way: int   = 2,
        K_shot: int  = 5,
        Q_query: int = 15,
        seed: int    = 42,
        device: str | torch.device = "cpu",
    ) -> List[MAMLTask]:
        """
        Sample n_tasks N-way K-shot episodes from a dataset.

        The dataset must support indexing and have a `.y` or labels
        attribute, or labels are drawn directly from __getitem__.

        Args:
            dataset:   PyTorch dataset (MIMIC4Dataset recommended)
            n_tasks:   1000 per paper
            N_way:     2 (binary classification)
            K_shot:    5 support examples per class
            Q_query:   15 query examples per class [NOT STATED IN PAPER]
            seed:      RNG seed

        Returns:
            List of MAMLTask
        """
        import numpy as np
        rng = np.random.default_rng(seed)

        # Gather all labels
        try:
            ys = dataset.labels
        except AttributeError:
            ys = torch.tensor([dataset[i][1] for i in range(len(dataset))])

        ys = ys.numpy() if isinstance(ys, torch.Tensor) else np.array(ys)
        classes = np.unique(ys)

        tasks = []
        for _ in range(n_tasks):
            # Sample N classes (for binary: always classes 0 and 1)
            sampled_classes = rng.choice(classes, size=N_way, replace=False)
            support_xs, support_ys = [], []
            query_xs,   query_ys   = [], []

            for new_label, cls in enumerate(sampled_classes):
                cls_idx = np.where(ys == cls)[0]
                chosen  = rng.choice(cls_idx, size=K_shot + Q_query, replace=False)
                s_idx   = chosen[:K_shot]
                q_idx   = chosen[K_shot:]

                for idx in s_idx:
                    x, _ = dataset[int(idx)]
                    support_xs.append(x)
                    support_ys.append(new_label)
                for idx in q_idx:
                    x, _ = dataset[int(idx)]
                    query_xs.append(x)
                    query_ys.append(new_label)

            tasks.append(MAMLTask(
                support_X = torch.stack(support_xs),
                support_y = torch.tensor(support_ys, dtype=torch.long),
                query_X   = torch.stack(query_xs),
                query_y   = torch.tensor(query_ys, dtype=torch.long),
            ))

        return tasks

    # ------------------------------------------------------------------
    # Checkpointing
    # ------------------------------------------------------------------

    def state_dict(self) -> dict:
        return {
            "model":       self.model.state_dict(),
            "outer_opt":   self.outer_opt.state_dict(),
            "inner_lr":    self.inner_lr,
            "inner_steps": self.inner_steps,
            "first_order": self.first_order,
        }

    def load_state_dict(self, state: dict) -> None:
        self.model.load_state_dict(state["model"])
        self.outer_opt.load_state_dict(state["outer_opt"])
        self.inner_lr    = state["inner_lr"]
        self.inner_steps = state["inner_steps"]
        self.first_order = state["first_order"]
