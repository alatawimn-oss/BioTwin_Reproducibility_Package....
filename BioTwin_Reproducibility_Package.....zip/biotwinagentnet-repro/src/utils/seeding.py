"""
src/utils/seeding.py

Deterministic seeding for all paper experiments.

Paper spec: seed 42 (MIMIC-IV splits, training).
Determinism requires CUBLAS_WORKSPACE_CONFIG=:4096:8 (set in Dockerfile).
"""

import os
import random

import numpy as np
import torch


def set_global_seed(seed: int = 42) -> None:
    """
    Set all RNG seeds for full reproducibility.

    Must be called before any dataset loading, model creation,
    or DataLoader construction.

    Sets:
      Python random, NumPy, PyTorch CPU, PyTorch CUDA (all devices),
      PYTHONHASHSEED, torch.backends.cudnn deterministic mode.
    """
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    # Deterministic cuDNN (required for paper reproducibility)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False

    # PyTorch deterministic algorithms (requires CUBLAS_WORKSPACE_CONFIG env var)
    # Set in Dockerfile: ENV CUBLAS_WORKSPACE_CONFIG=:4096:8
    try:
        torch.use_deterministic_algorithms(True)
    except RuntimeError:
        # Some ops have no deterministic implementation; warn but continue
        torch.use_deterministic_algorithms(True, warn_only=True)
