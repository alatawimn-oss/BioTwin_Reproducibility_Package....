"""
src/utils/logging_utils.py

CSV and TensorBoard logging for all training runs.

Paper requirement: log to CSV and TensorBoard.
"""

import csv
from pathlib import Path
from typing import Any, Dict, Optional


class CSVLogger:
    """
    Appends one row per FL round / epoch to a CSV file.

    Usage:
        logger = CSVLogger("results/reproduced/run_main/metrics.csv")
        logger.log({"round": 1, "train_loss": 0.42, "val_auroc": 0.871})
    """

    def __init__(self, path: str | Path) -> None:
        self.path    = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._header_written = self.path.exists() and self.path.stat().st_size > 0

    def log(self, row: Dict[str, Any]) -> None:
        write_header = not self._header_written
        with open(self.path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(row.keys()))
            if write_header:
                writer.writeheader()
                self._header_written = True
            writer.writerow(row)

    def close(self) -> None:
        pass   # file is closed after each write


def get_tb_writer(log_dir: str | Path, comment: str = ""):
    """
    Return a SummaryWriter for TensorBoard logging.
    Returns a no-op writer if tensorboard is unavailable.
    """
    try:
        from torch.utils.tensorboard import SummaryWriter
        return SummaryWriter(log_dir=str(log_dir), comment=comment)
    except ImportError:
        class _NoOpWriter:
            def add_scalar(self, *a, **kw): pass
            def add_scalars(self, *a, **kw): pass
            def close(self): pass
            def flush(self): pass
        return _NoOpWriter()
