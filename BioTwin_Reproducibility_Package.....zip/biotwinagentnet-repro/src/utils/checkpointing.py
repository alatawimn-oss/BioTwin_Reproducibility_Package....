"""
src/utils/checkpointing.py

Checkpoint save / load for federated rounds and distillation phases.
"""

from pathlib import Path
from typing import Any, Dict, Optional

import torch
import torch.nn as nn


def save_checkpoint(
    path: str | Path,
    model: nn.Module,
    optimizer: Optional[Any] = None,
    round_or_epoch: int = 0,
    metrics: Optional[Dict[str, float]] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Save model state dict and optional optimizer state.

    Args:
        path:            Save path (.pt)
        model:           PyTorch model
        optimizer:       Optimizer (None to skip)
        round_or_epoch:  Current FL round or epoch number
        metrics:         Dict of scalar metrics to store in checkpoint
        extra:           Any additional picklable data
    """
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    payload: Dict[str, Any] = {
        "round":      round_or_epoch,
        "model":      model.state_dict(),
        "metrics":    metrics or {},
    }
    if optimizer is not None:
        payload["optimizer"] = optimizer.state_dict()
    if extra:
        payload.update(extra)
    torch.save(payload, path)


def load_checkpoint(
    path: str | Path,
    model: nn.Module,
    optimizer: Optional[Any] = None,
    device: str | torch.device = "cpu",
    strict: bool = True,
) -> Dict[str, Any]:
    """
    Load checkpoint into model (and optionally optimizer).

    Returns:
        The full checkpoint dict (round, metrics, etc.).
    """
    ckpt = torch.load(path, map_location=device)
    model.load_state_dict(ckpt["model"], strict=strict)
    if optimizer is not None and "optimizer" in ckpt:
        optimizer.load_state_dict(ckpt["optimizer"])
    return ckpt


def latest_checkpoint(directory: str | Path) -> Optional[Path]:
    """Return the most recently modified .pt file in a directory, or None."""
    pts = sorted(Path(directory).glob("*.pt"), key=lambda p: p.stat().st_mtime)
    return pts[-1] if pts else None
