"""
src/models/biotwin_agent.py

BioTwinAgent — top-level wrapper that composes teacher + student with
all BioTwin-AgentNet modules:
  - Differential Privacy (Opacus, Phase 1 & 3)
  - Knowledge Distillation  (Phase 2, eICU)
  - Continual Learning      (EWC + Replay, Phase 3)
  - MAML Meta-Learning      (edge adaptation)
  - Watermarking            (differentiable L2 reg)

This module is the single entry point used by train.py and test.py.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn

from .teacher import TeacherLSTM
from .student import StudentLSTM


class BioTwinAgent(nn.Module):
    """
    Wraps teacher or student with the BioTwin-AgentNet training mode.

    Args:
        mode:         "teacher" (Phase 1) | "student" (Phase 3)
        n_features:   Input feature dimension
        n_classes:    Number of output classes
        teacher_cfg:  Dict of kwargs forwarded to TeacherLSTM
        student_cfg:  Dict of kwargs forwarded to StudentLSTM
    """

    def __init__(
        self,
        mode: str = "teacher",
        n_features: int = 127,
        n_classes: int = 2,
        teacher_cfg: Optional[dict] = None,
        student_cfg: Optional[dict] = None,
    ) -> None:
        super().__init__()
        self.mode = mode

        t_cfg = dict(
            n_features=n_features,
            hidden_size=512,
            num_layers=3,
            n_classes=n_classes,
            dropout=0.3,
            bidirectional=True,
        )
        if teacher_cfg:
            t_cfg.update(teacher_cfg)

        s_cfg = dict(
            n_features=n_features,
            hidden_size=128,
            num_layers=2,
            n_classes=n_classes,
            dropout=0.1,
        )
        if student_cfg:
            s_cfg.update(student_cfg)

        if mode == "teacher":
            self.backbone: nn.Module = TeacherLSTM(**t_cfg)
        elif mode == "student":
            self.backbone = StudentLSTM(**s_cfg)
        else:
            raise ValueError(f"Unknown mode: {mode!r}. Use 'teacher' or 'student'.")

        # Watermark embedding vector — initialised in src/watermark/watermark.py
        # Registered as a buffer so it is saved with state_dict but not updated
        # by the optimizer directly (gradient flows through the L2 reg term).
        self.register_buffer("_wm_pattern", torch.zeros(1))  # resized at runtime

    # ── forward ──────────────────────────────────────────────────────────────

    def forward(
        self, x: torch.Tensor, return_features: bool = False
    ) -> torch.Tensor | tuple:
        return self.backbone(x, return_features=return_features)

    # ── convenience properties ────────────────────────────────────────────────

    @property
    def is_teacher(self) -> bool:
        return self.mode == "teacher"

    @property
    def is_student(self) -> bool:
        return self.mode == "student"

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    # ── FedAvg helpers ────────────────────────────────────────────────────────

    def get_flat_params(self) -> torch.Tensor:
        """Return all trainable parameters as a 1-D tensor (for FedAvg)."""
        return torch.cat([p.data.view(-1) for p in self.parameters()])

    def set_flat_params(self, flat: torch.Tensor) -> None:
        """Load parameters from a 1-D tensor (for FedAvg aggregation)."""
        offset = 0
        for p in self.parameters():
            numel = p.numel()
            p.data.copy_(flat[offset: offset + numel].view_as(p))
            offset += numel
