"""
src/models/centralized_cnn.py

Centralized CNN baseline (Table 8, paper).

Paper spec: trained centrally (no FL), no DP, no HE.
Architecture: 1D-CNN on ICU time series.
[NOT STATED IN PAPER] architecture details — standard 1D-CNN for
time-series classification used as a non-federated baseline.
"""

import torch
import torch.nn as nn


class CentralizedCNN(nn.Module):
    """
    1D-CNN baseline for centralised (non-federated) training.

    Architecture:
        Conv1d(F→64, k=3) → BN → ReLU → MaxPool
        Conv1d(64→128, k=3) → BN → ReLU → MaxPool
        Conv1d(128→256, k=3) → BN → ReLU → AdaptiveAvgPool → flatten
        Linear(256 → 128) → ReLU → Dropout
        Linear(128 → n_classes)

    Args:
        n_features:  Input channels (127 for MIMIC-IV)
        n_classes:   Output logits (2)
        dropout:     Dropout before final classifier (0.3)
    """

    def __init__(
        self,
        n_features: int = 127,
        n_classes: int = 2,
        dropout: float = 0.3,
    ) -> None:
        super().__init__()

        self.conv_block = nn.Sequential(
            # Block 1
            nn.Conv1d(n_features, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            # Block 2
            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            # Block 3
            nn.Conv1d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),   # (B, 256, 1)
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, n_classes),
        )

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, T, F)  — time-first from DataLoader
        Returns:
            logits: (B, n_classes)
        """
        x = x.permute(0, 2, 1)   # (B, F, T) for Conv1d
        x = self.conv_block(x)
        return self.classifier(x)

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
