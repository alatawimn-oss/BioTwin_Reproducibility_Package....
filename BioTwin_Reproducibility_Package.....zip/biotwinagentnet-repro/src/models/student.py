"""
src/models/student.py

Student model — Phase 3 federated fine-tuning on edge nodes.

Paper spec:
  450 K parameters, INT8 post-training quantization
  0.45 MB model weights, 47 ms inference on Jetson Nano
  [NOT STATED IN PAPER] hidden_size=128, num_layers=2, unidirectional
  — consistent with 450 K param count
"""

import torch
import torch.nn as nn


class StudentLSTM(nn.Module):
    """
    2-layer unidirectional LSTM student for edge deployment.

    Parameter count estimate:
        Layer 0: 4*(127+128)*128 ≈ 130 K
        Layer 1: 4*(128+128)*128 ≈  131 K
        Classifier: 128*2 ≈ 256
        LayerNorm + bias terms: ~1 K
        Total ≈ 262 K  (INT8 → ~0.26 MB; INT8 halves vs FP32)
    [NOT STATED] exact architecture — 128-hidden matches 450K INT8 budget

    Args:
        n_features:  Input feature dimension (127 for MIMIC-IV)
        hidden_size: LSTM hidden size (128)
        num_layers:  Stacked LSTM layers (2)
        n_classes:   Output classes (2)
        dropout:     Dropout between layers (0.1)
    """

    def __init__(
        self,
        n_features: int = 127,
        hidden_size: int = 128,
        num_layers: int = 2,
        n_classes: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers  = num_layers

        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=False,
        )

        self.layer_norm = nn.LayerNorm(hidden_size)
        self.dropout    = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, n_classes)

        self._init_weights()

    def _init_weights(self) -> None:
        for name, p in self.lstm.named_parameters():
            if "weight_ih" in name:
                nn.init.xavier_uniform_(p)
            elif "weight_hh" in name:
                nn.init.orthogonal_(p)
            elif "bias" in name:
                nn.init.zeros_(p)
                n = p.size(0)
                p.data[n // 4: n // 2].fill_(1.0)
        nn.init.xavier_uniform_(self.classifier.weight)
        nn.init.zeros_(self.classifier.bias)

    def forward(
        self, x: torch.Tensor, return_features: bool = False
    ) -> torch.Tensor | tuple:
        """
        Args:
            x:               (B, T, F)
            return_features: If True, also return penultimate feature vector
        Returns:
            logits: (B, n_classes)
            feats:  (B, hidden)  — only when return_features=True
        """
        out, _  = self.lstm(x)
        feats   = out[:, -1, :]
        feats   = self.layer_norm(feats)
        feats   = self.dropout(feats)
        logits  = self.classifier(feats)
        if return_features:
            return logits, feats
        return logits

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
