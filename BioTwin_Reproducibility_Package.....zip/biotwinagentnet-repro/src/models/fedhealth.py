"""
src/models/fedhealth.py

FedHealth baseline (Chen et al., 2020).

Reference:
  Chen, Y. et al. "FedHealth: A Federated Transfer Learning Framework
  for Wearable Healthcare." IEEE Intelligent Systems, 2020.
  DOI: 10.1109/MIS.2020.2988604

Paper target (Table 8):
  Sepsis AUROC 0.856 on MIMIC-IV test set.

FedHealth aggregates a shared global model then locally fine-tunes
with an attention-based personalisation layer. We replicate the
personalisation mechanism on top of the shared LSTM backbone.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FedHealthPersonaliser(nn.Module):
    """
    Attention-based personalisation layer (FedHealth, Fig. 2).
    Projects shared features into a client-specific representation.

    Args:
        feature_dim: Dimension of the shared feature vector
        attn_heads:  Number of multi-head attention heads
    """

    def __init__(self, feature_dim: int = 512, attn_heads: int = 4) -> None:
        super().__init__()
        self.attn = nn.MultiheadAttention(
            embed_dim=feature_dim, num_heads=attn_heads, batch_first=True
        )
        self.norm = nn.LayerNorm(feature_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, T, feature_dim)"""
        out, _ = self.attn(x, x, x)
        return self.norm(x + out)


class FedHealthModel(nn.Module):
    """
    FedHealth federated model: shared LSTM + per-client personaliser.

    Args:
        n_features:   Input dimension (127)
        hidden_size:  LSTM hidden size (512 to match teacher capacity)
        num_layers:   LSTM layers (2)
        n_classes:    Output classes (2)
        dropout:      Dropout (0.3)
        personalise:  Whether to attach the personalisation layer
                      (False during global aggregation, True during local fine-tune)
    """

    def __init__(
        self,
        n_features: int = 127,
        hidden_size: int = 512,
        num_layers: int = 2,
        n_classes: int = 2,
        dropout: float = 0.3,
        personalise: bool = True,
    ) -> None:
        super().__init__()
        self.personalise = personalise

        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=False,
        )

        if personalise:
            self.personaliser = FedHealthPersonaliser(
                feature_dim=hidden_size, attn_heads=4
            )

        self.dropout    = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, T, F)"""
        out, _ = self.lstm(x)          # (B, T, H)
        if self.personalise:
            out = self.personaliser(out)
        feat   = out[:, -1, :]
        feat   = self.dropout(feat)
        return self.classifier(feat)

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
