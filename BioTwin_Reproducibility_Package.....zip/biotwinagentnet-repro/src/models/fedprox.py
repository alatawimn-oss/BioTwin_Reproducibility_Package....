"""
src/models/fedprox.py

FedProx baseline (Li et al., 2020).

Reference:
  Li, T. et al. "Federated Optimization in Heterogeneous Networks."
  MLSys, 2020.  arXiv:1812.06127

Paper target (Table 8):
  Sepsis AUROC 0.853, 179 FL rounds to convergence,
  11.4 MB/round, 2.04 GB total communication.

FedProx adds a proximal term to each client's local objective:
    L_prox = L_task + (mu/2) * ||w - w_global||^2
where mu=0.01 (configs/baseline_fedprox.yaml).
"""

import copy
from typing import Optional

import torch
import torch.nn as nn

from .teacher import TeacherLSTM


class FedProxClient(nn.Module):
    """
    FedProx client wrapper around TeacherLSTM backbone.

    The proximal penalty is computed in `proximal_loss()` and added
    to the cross-entropy loss in train.py before calling optimizer.step().

    Args:
        n_features:   Input dimension (127)
        hidden_size:  LSTM hidden (512)
        num_layers:   LSTM layers (3)
        n_classes:    Output classes (2)
        dropout:      Dropout (0.3)
        mu:           Proximal penalty coefficient (0.01, paper default)
    """

    def __init__(
        self,
        n_features: int = 127,
        hidden_size: int = 512,
        num_layers: int = 3,
        n_classes: int = 2,
        dropout: float = 0.3,
        mu: float = 0.01,
    ) -> None:
        super().__init__()
        self.mu = mu
        self.backbone = TeacherLSTM(
            n_features=n_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            n_classes=n_classes,
            dropout=dropout,
            bidirectional=True,
        )
        # Frozen copy of global model weights — updated each round
        self._global_params: Optional[list] = None

    def set_global_params(self, global_state_dict: dict) -> None:
        """
        Called at the start of each FL round.
        Stores a detached copy of the global model parameters.
        """
        self._global_params = [
            p.detach().clone() for p in global_state_dict.values()
            if isinstance(p, torch.Tensor) and p.is_floating_point()
        ]

    def proximal_loss(self) -> torch.Tensor:
        """
        Compute the FedProx proximal term:
            (mu/2) * sum_i ||w_i - w_global_i||^2
        Returns scalar 0 if global params not set yet.
        """
        if self._global_params is None:
            return torch.tensor(0.0, requires_grad=True)

        prox = torch.tensor(0.0, device=next(self.parameters()).device)
        local_params = [
            p for p in self.parameters()
            if p.is_floating_point()
        ]
        for w_local, w_global in zip(local_params, self._global_params):
            w_g = w_global.to(w_local.device)
            prox = prox + torch.sum((w_local - w_g) ** 2)
        return (self.mu / 2.0) * prox

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.backbone(x)

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
