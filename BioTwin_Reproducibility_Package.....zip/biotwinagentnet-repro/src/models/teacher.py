"""
src/models/teacher.py

Teacher model — Phase 1 federated training on cloud/fog nodes.

Paper spec:
  4.2 M parameters, FP32
  Bidirectional 3-layer LSTM, hidden=512
  [NOT STATED IN PAPER] hidden_size=512, num_layers=3, bidirectional=True,
  dropout=0.3 — reasonable defaults consistent with parameter count
"""

import torch
import torch.nn as nn


class TeacherLSTM(nn.Module):
    """
    3-layer bidirectional LSTM teacher for BioTwin-AgentNet.

    Parameter count (paper Table 4): ~4.2 M in FP32.
    With hidden=512, 3 layers, bidir, input=127:
        Layer 0: 4*(127+512)*512*2 = ~1.33 M  (bidir doubles hidden)
        Layers 1-2: 4*(1024+512)*512*2 ≈ 2.52 M
        Classifier: 1024*3 = 3072
        Total ≈ 3.85 M  (close to 4.2 M with layer-norm params)

    Args:
        n_features:  Input feature dimension (127 for MIMIC-IV)
        hidden_size: LSTM hidden size (512, paper default)
        num_layers:  Number of stacked LSTM layers (3)
        n_classes:   Output classes per task (2 for binary)
        dropout:     Dropout between LSTM layers (0.3)
        bidirectional: Use bidirectional LSTM (True)
    """

    def __init__(
        self,
        n_features: int = 127,
        hidden_size: int = 512,
        num_layers: int = 3,
        n_classes: int = 2,
        dropout: float = 0.3,
        bidirectional: bool = True,
    ) -> None:
        super().__init__()
        self.hidden_size   = hidden_size
        self.num_layers    = num_layers
        self.bidirectional = bidirectional
        self.n_directions  = 2 if bidirectional else 1

        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )

        # Layer norm on LSTM output (stabilises federated training)
        self.layer_norm = nn.LayerNorm(hidden_size * self.n_directions)

        self.dropout    = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size * self.n_directions, n_classes)

        self._init_weights()

    def _init_weights(self) -> None:
        for name, p in self.lstm.named_parameters():
            if "weight_ih" in name:
                nn.init.xavier_uniform_(p)
            elif "weight_hh" in name:
                nn.init.orthogonal_(p)
            elif "bias" in name:
                nn.init.zeros_(p)
                # forget-gate bias = 1 (Jozefowicz et al., 2015)
                n = p.size(0)
                p.data[n // 4: n // 2].fill_(1.0)
        nn.init.xavier_uniform_(self.classifier.weight)
        nn.init.zeros_(self.classifier.bias)

    def forward(
        self, x: torch.Tensor, return_features: bool = False
    ) -> torch.Tensor | tuple:
        """
        Args:
            x:               (B, T, F)
            return_features: If True, also return the penultimate feature vector
                             (used by knowledge distillation)
        Returns:
            logits: (B, n_classes)
            feats:  (B, hidden*n_dir)  — only when return_features=True
        """
        out, _ = self.lstm(x)             # (B, T, H*n_dir)
        feats   = out[:, -1, :]           # last time step
        feats   = self.layer_norm(feats)
        feats   = self.dropout(feats)
        logits  = self.classifier(feats)
        if return_features:
            return logits, feats
        return logits

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
