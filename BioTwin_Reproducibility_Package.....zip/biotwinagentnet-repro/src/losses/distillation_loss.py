"""
src/losses/distillation_loss.py

Knowledge distillation loss (Hinton et al., 2015).

Paper spec (Phase 2, eICU):
  Temperature T = 4
  alpha = 0.3   (weight of KD soft-target loss)
  Student AUROC improvement: +0.079 over training from scratch

  L = alpha * L_KD(soft) + (1 - alpha) * L_CE(hard)
  L_KD = KLDiv(softmax(s/T), softmax(t/T)) * T^2
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class DistillationLoss(nn.Module):
    """
    Combined hard-label cross-entropy + soft-target KL divergence loss.

    Args:
        temperature: Softmax temperature T (4.0, paper default)
        alpha:       Weight on the soft KD term (0.3, paper default)
        reduction:   'mean' or 'sum'
    """

    def __init__(
        self,
        temperature: float = 4.0,
        alpha: float = 0.3,
        reduction: str = "mean",
    ) -> None:
        super().__init__()
        if not (0.0 <= alpha <= 1.0):
            raise ValueError(f"alpha must be in [0,1], got {alpha}")
        self.T         = temperature
        self.alpha     = alpha
        self.reduction = reduction
        self.ce        = nn.CrossEntropyLoss(reduction=reduction)
        self.kl        = nn.KLDivLoss(reduction="batchmean")

    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        labels: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            student_logits: (B, C) raw student logits
            teacher_logits: (B, C) raw teacher logits (detached)
            labels:         (B,)   ground-truth hard labels

        Returns:
            Scalar combined loss.
        """
        # Hard-label cross-entropy
        loss_ce = self.ce(student_logits, labels)

        # Soft-target KL divergence
        s_soft = F.log_softmax(student_logits / self.T, dim=-1)
        t_soft = F.softmax(teacher_logits.detach() / self.T, dim=-1)
        loss_kd = self.kl(s_soft, t_soft) * (self.T ** 2)

        return self.alpha * loss_kd + (1.0 - self.alpha) * loss_ce
