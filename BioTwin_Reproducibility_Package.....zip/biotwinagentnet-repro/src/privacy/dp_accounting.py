"""
src/privacy/dp_accounting.py

Differential privacy accounting via Opacus RDP composition.

Paper spec:
  Library   : Opacus v1.4
  Mechanism : Gaussian (RDP accountant)
  sigma     = 1.12   (noise multiplier)
  C         = 1.0    (max gradient norm)
  delta     = 1e-5
  q         = 1.0    (sampling rate — full-batch per client)
  eps @ 142 rounds = 105.9
  eps @ 200 rounds = 138.3   (Table 5)

The DP engine is attached to the model optimizer in train.py via
opacus.PrivacyEngine.make_private_with_epsilon() or
make_private() with explicit noise_multiplier.
"""

from __future__ import annotations

from typing import Tuple

import torch
import torch.nn as nn


class DPAccountant:
    """
    Tracks epsilon expenditure across FL rounds using Opacus RDP accounting.

    Usage in train.py:
        accountant = DPAccountant(sigma=1.12, C=1.0, delta=1e-5, q=1.0)
        privacy_engine = accountant.attach(model, optimizer, data_loader)
        # after each round:
        eps = accountant.epsilon(rounds_so_far)

    Paper targets:
        eps(142) = 105.9
        eps(200) = 138.3
    """

    def __init__(
        self,
        noise_multiplier: float = 1.12,
        max_grad_norm: float = 1.0,
        delta: float = 1e-5,
        sample_rate: float = 1.0,
    ) -> None:
        self.noise_multiplier = noise_multiplier
        self.max_grad_norm    = max_grad_norm
        self.delta            = delta
        self.sample_rate      = sample_rate
        self._engine          = None

    def attach(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        data_loader,
        poisson_sampling: bool = False,
    ):
        """
        Attach Opacus PrivacyEngine to model + optimizer.

        Args:
            model:             PyTorch model (must be on a single device)
            optimizer:         Adam or SGD optimizer
            data_loader:       Training DataLoader
            poisson_sampling:  Use Poisson subsampling (False = deterministic
                               batch, q=1.0 matches paper spec)

        Returns:
            (model, optimizer, data_loader) — Opacus-wrapped versions
        """
        try:
            from opacus import PrivacyEngine
        except ImportError as e:
            raise ImportError(
                "opacus is required for DP training. "
                "Install with: pip install opacus==1.4.0"
            ) from e

        engine = PrivacyEngine(accountant="rdp")
        model, optimizer, data_loader = engine.make_private(
            module=model,
            optimizer=optimizer,
            data_loader=data_loader,
            noise_multiplier=self.noise_multiplier,
            max_grad_norm=self.max_grad_norm,
            poisson_sampling=poisson_sampling,
        )
        self._engine = engine
        return model, optimizer, data_loader

    def epsilon(self, steps: int | None = None) -> float:
        """
        Return current epsilon. If steps given, compute analytically
        without a live engine (useful for pre-flight budget checks).
        """
        if self._engine is not None:
            return self._engine.get_epsilon(self.delta)

        if steps is None:
            raise ValueError("Provide steps when no engine is attached.")

        # Analytical RDP composition via opacus accountant
        try:
            from opacus.accountants.utils import get_noise_multiplier
            from opacus.accountants import RDPAccountant
        except ImportError:
            raise ImportError("opacus required for epsilon computation.")

        acc = RDPAccountant()
        for _ in range(steps):
            acc.step(
                noise_multiplier=self.noise_multiplier,
                sample_rate=self.sample_rate,
            )
        return acc.get_epsilon(self.delta)

    def budget_check(self) -> dict:
        """
        Verify that projected epsilon at 200 rounds matches paper.
        Returns dict with projected values and pass/fail flags.
        """
        try:
            eps_142 = self.epsilon(steps=142)
            eps_200 = self.epsilon(steps=200)
        except Exception:
            eps_142 = float("nan")
            eps_200 = float("nan")

        return {
            "eps_142_rounds":    eps_142,
            "eps_200_rounds":    eps_200,
            "paper_eps_142":     105.9,
            "paper_eps_200":     138.3,
            "delta":             self.delta,
            "noise_multiplier":  self.noise_multiplier,
            "max_grad_norm":     self.max_grad_norm,
        }
