"""
src/privacy/he_encryption.py

Threshold CKKS homomorphic encryption for federated aggregation.

Paper spec:
  Library        : TenSEAL v0.3.14 (Python) + MS SEAL C++ v3.7
  Scheme         : CKKS (approximate arithmetic)
  Threshold      : Shamir secret sharing, t=3, K=5 (3-of-5 decryption)
  Decryption     : Lagrange interpolation over partial decryption shares
  Use case       : Encrypt local model updates before fog aggregation;
                   fog nodes sum ciphertexts; cloud decrypts with
                   threshold shares from t=3 fog coordinators.

[NOT STATED IN PAPER] CKKS parameter defaults (chosen for model-weight
precision, typical research settings):
  poly_modulus_degree : 8192
  coeff_mod_bit_sizes : [60, 40, 40, 60]
  scale               : 2^40

Shamir sharing uses a prime field large enough for the secret size.
Since CKKS partial decryption is expensive to implement from scratch
without a full SEAL threshold extension, the production path delegates
to TenSEAL; the fallback (no TenSEAL) uses a simulation mode that
exercises the same API surface with plaintext arithmetic so the rest
of the pipeline can be tested without the C++ extension.
"""

from __future__ import annotations

import hashlib
import os
import struct
from typing import List, Optional, Tuple

import numpy as np
import torch


# ---------------------------------------------------------------------------
# Shamir secret sharing helpers (pure Python, works without TenSEAL)
# ---------------------------------------------------------------------------

# A large prime for field arithmetic (256-bit Mersenne-ish prime)
_PRIME = (1 << 256) - 189  # 2^256 - 189


def _poly_eval(coeffs: List[int], x: int, prime: int) -> int:
    """Evaluate polynomial with given coefficients at x, mod prime."""
    result = 0
    for c in reversed(coeffs):
        result = (result * x + c) % prime
    return result


def _lagrange_interpolate_at_zero(
    x_coords: List[int], y_coords: List[int], prime: int
) -> int:
    """
    Lagrange interpolation to recover f(0) from t (x,y) share pairs.
    All arithmetic in GF(prime).
    """
    n = len(x_coords)
    secret = 0
    for i in range(n):
        xi, yi = x_coords[i], y_coords[i]
        numerator   = 1
        denominator = 1
        for j in range(n):
            if i == j:
                continue
            xj = x_coords[j]
            numerator   = (numerator   *  (-xj)       ) % prime
            denominator = (denominator * (xi - xj)) % prime
        # Modular inverse via Fermat's little theorem
        inv_denom = pow(denominator, prime - 2, prime)
        secret = (secret + yi * numerator * inv_denom) % prime
    return secret


class ShamirSecretSharer:
    """
    Shamir (t, K) secret sharing over a prime field.

    Paper: t=3, K=5 (any 3 of 5 fog coordinators can decrypt).
    """

    def __init__(self, t: int = 3, K: int = 5, prime: int = _PRIME) -> None:
        if t > K:
            raise ValueError(f"Threshold t={t} must be <= K={K}")
        self.t     = t
        self.K     = K
        self.prime = prime

    def share(self, secret: int, seed: Optional[int] = None) -> List[Tuple[int, int]]:
        """
        Split secret into K shares. Returns list of (x_i, y_i) pairs.
        x_i = party index (1-indexed), y_i = share value.
        """
        rng = np.random.default_rng(seed)
        # Random polynomial of degree t-1 with secret as constant term
        coeffs = [secret % self.prime] + [
            int(rng.integers(0, self.prime)) for _ in range(self.t - 1)
        ]
        shares = [
            (i + 1, _poly_eval(coeffs, i + 1, self.prime))
            for i in range(self.K)
        ]
        return shares

    def reconstruct(self, shares: List[Tuple[int, int]]) -> int:
        """
        Reconstruct secret from >= t shares using Lagrange interpolation.
        """
        if len(shares) < self.t:
            raise ValueError(
                f"Need at least t={self.t} shares; got {len(shares)}"
            )
        xs, ys = zip(*shares[: self.t])
        return _lagrange_interpolate_at_zero(list(xs), list(ys), self.prime)


# ---------------------------------------------------------------------------
# CKKS context helpers
# ---------------------------------------------------------------------------

def _build_tenseal_context(
    poly_modulus_degree: int = 8192,
    coeff_mod_bit_sizes: Optional[List[int]] = None,
    scale: float = 2 ** 40,
    generate_galois_keys: bool = True,
    generate_relin_keys: bool = True,
):
    """
    Build and return a TenSEAL CKKS context.
    Raises ImportError if tenseal is unavailable.
    """
    try:
        import tenseal as ts
    except ImportError as e:
        raise ImportError(
            "tenseal is required for CKKS encryption. "
            "Install with: pip install tenseal==0.3.14"
        ) from e

    if coeff_mod_bit_sizes is None:
        coeff_mod_bit_sizes = [60, 40, 40, 60]

    ctx = ts.context(
        ts.SCHEME_TYPE.CKKS,
        poly_modulus_degree=poly_modulus_degree,
        coeff_mod_bit_sizes=coeff_mod_bit_sizes,
    )
    ctx.global_scale = scale
    if generate_galois_keys:
        ctx.generate_galois_keys()
    if generate_relin_keys:
        ctx.generate_relin_keys()
    return ctx


# ---------------------------------------------------------------------------
# ThresholdCKKS — main public class
# ---------------------------------------------------------------------------

class ThresholdCKKS:
    """
    Threshold CKKS encryption for federated model-update aggregation.

    Usage (3-of-5 scenario, paper spec):

        he = ThresholdCKKS(t=3, K=5)
        ctx = he.build_context()

        # On each fog node:
        ct = he.encrypt(local_update_flat_tensor, ctx)
        ct_bytes = he.serialize_ciphertext(ct)

        # On fog aggregator (sums ciphertexts homomorphically):
        agg_ct = he.aggregate([ct1, ct2, ..., ctN], ctx)

        # Threshold decryption:
        partial_decrypts = [he.partial_decrypt(agg_ct, sk_i) for sk_i in party_sks]
        result = he.combine_partial_decrypts(partial_decrypts, ctx)

    Simulation mode (no TenSEAL installed):
        he = ThresholdCKKS(simulate=True)
        # All encrypt/decrypt ops work in plaintext; Shamir sharing still exercised.
    """

    # Paper constants
    PAPER_T = 3
    PAPER_K = 5

    def __init__(
        self,
        t: int = PAPER_T,
        K: int = PAPER_K,
        poly_modulus_degree: int = 8192,
        coeff_mod_bit_sizes: Optional[List[int]] = None,
        scale: float = 2 ** 40,
        simulate: bool = False,
    ) -> None:
        self.t                    = t
        self.K                    = K
        self.poly_modulus_degree  = poly_modulus_degree
        self.coeff_mod_bit_sizes  = coeff_mod_bit_sizes or [60, 40, 40, 60]
        self.scale                = scale
        self.simulate             = simulate
        self.sharer               = ShamirSecretSharer(t=t, K=K)

        if not simulate:
            try:
                import tenseal  # noqa: F401
            except ImportError:
                import warnings
                warnings.warn(
                    "tenseal not found; falling back to simulation mode. "
                    "Install tenseal==0.3.14 for real CKKS encryption.",
                    stacklevel=2,
                )
                self.simulate = True

    # ------------------------------------------------------------------
    # Context management
    # ------------------------------------------------------------------

    def build_context(self):
        """
        Build a TenSEAL context (or return a dict stub in simulate mode).
        """
        if self.simulate:
            return {
                "scheme": "CKKS-sim",
                "poly_modulus_degree": self.poly_modulus_degree,
                "scale": self.scale,
            }
        return _build_tenseal_context(
            poly_modulus_degree=self.poly_modulus_degree,
            coeff_mod_bit_sizes=self.coeff_mod_bit_sizes,
            scale=self.scale,
        )

    # ------------------------------------------------------------------
    # Encrypt / decrypt
    # ------------------------------------------------------------------

    def encrypt(self, tensor: torch.Tensor, ctx) -> object:
        """
        Encrypt a 1-D float tensor as a CKKS ciphertext.

        Args:
            tensor:  1-D torch.Tensor (model update flat vector)
            ctx:     TenSEAL context from build_context()

        Returns:
            CKKSVector (or plaintext dict in simulate mode)
        """
        vec = tensor.detach().cpu().float().numpy().tolist()
        if self.simulate:
            return {"__sim__": True, "data": vec}

        import tenseal as ts
        return ts.ckks_vector(ctx, vec)

    def decrypt(self, ciphertext, ctx=None) -> np.ndarray:
        """
        Decrypt a CKKS ciphertext to a numpy array.
        """
        if isinstance(ciphertext, dict) and ciphertext.get("__sim__"):
            return np.array(ciphertext["data"], dtype=np.float32)

        # Real TenSEAL decryption
        return np.array(ciphertext.decrypt(), dtype=np.float32)

    def encrypt_tensor(self, tensor: torch.Tensor, ctx) -> object:
        """Alias for encrypt — encrypts flattened model parameters."""
        return self.encrypt(tensor.flatten(), ctx)

    def decrypt_to_tensor(
        self, ciphertext, ctx, shape: Optional[Tuple] = None
    ) -> torch.Tensor:
        """Decrypt and optionally reshape."""
        arr = self.decrypt(ciphertext, ctx)
        t = torch.from_numpy(arr)
        if shape is not None:
            t = t.reshape(shape)
        return t

    # ------------------------------------------------------------------
    # Homomorphic aggregation
    # ------------------------------------------------------------------

    def aggregate(self, ciphertexts: List, ctx=None):
        """
        Homomorphically sum a list of ciphertexts (FedAvg aggregation step).
        Returns a single ciphertext containing the element-wise sum.
        """
        if not ciphertexts:
            raise ValueError("Empty ciphertext list.")
        if isinstance(ciphertexts[0], dict) and ciphertexts[0].get("__sim__"):
            total = np.sum(
                [np.array(c["data"], dtype=np.float64) for c in ciphertexts], axis=0
            )
            return {"__sim__": True, "data": total.tolist()}

        result = ciphertexts[0].copy()
        for ct in ciphertexts[1:]:
            result += ct
        return result

    def scale_ciphertext(self, ciphertext, scale: float):
        """
        Multiply a ciphertext by a plaintext scalar (e.g. 1/N for FedAvg).
        """
        if isinstance(ciphertext, dict) and ciphertext.get("__sim__"):
            return {
                "__sim__": True,
                "data": (np.array(ciphertext["data"]) * scale).tolist(),
            }
        return ciphertext * scale

    # ------------------------------------------------------------------
    # Threshold (Shamir) decryption helpers
    # ------------------------------------------------------------------

    def share_secret_key_bytes(
        self, secret_key_bytes: bytes, seed: Optional[int] = None
    ) -> List[Tuple[int, int]]:
        """
        Split a secret key (as bytes) into K Shamir shares.
        Each byte is shared independently and stored in a compact encoding.

        Returns K tuples of (party_index, bytes_blob).
        """
        # Convert key bytes to integer
        secret_int = int.from_bytes(secret_key_bytes, byteorder="big")
        shares_int  = self.sharer.share(secret_int, seed=seed)
        # Encode y_i as big-endian 33 bytes (256-bit prime + margin)
        shares_bytes = [
            (x, y.to_bytes(33, byteorder="big")) for x, y in shares_int
        ]
        return shares_bytes

    def reconstruct_secret_key_bytes(
        self, shares: List[Tuple[int, bytes]], key_len: int
    ) -> bytes:
        """
        Reconstruct secret key bytes from >= t (party_index, bytes_blob) shares.
        """
        int_shares = [(x, int.from_bytes(y, byteorder="big")) for x, y in shares]
        secret_int = self.sharer.reconstruct(int_shares)
        return secret_int.to_bytes(key_len, byteorder="big")

    def partial_decrypt(self, ciphertext, partial_sk: bytes) -> dict:
        """
        Produce a partial decryption of ciphertext using one party's
        secret key share.  In simulate mode, returns plaintext directly.

        [NOT STATED IN PAPER]: Full threshold CKKS partial decryption
        requires SEAL threshold extension (libseal_threshold); this
        implementation uses the simulate path that returns unencrypted
        partial contributions, exercising the Lagrange combine path.
        """
        if isinstance(ciphertext, dict) and ciphertext.get("__sim__"):
            # Simulate: each party returns a noisy share of the plaintext
            rng_seed = int.from_bytes(
                hashlib.sha256(partial_sk).digest()[:4], "big"
            )
            noise = np.random.default_rng(rng_seed).normal(
                0, 1e-6, len(ciphertext["data"])
            )
            return {
                "__partial__": True,
                "data": (np.array(ciphertext["data"]) + noise).tolist(),
                "party_id": int.from_bytes(partial_sk[:2], "big") % self.K + 1,
            }
        raise NotImplementedError(
            "Real SEAL threshold partial decryption requires libseal_threshold. "
            "Use simulate=True for pipeline testing without the C++ extension."
        )

    def combine_partial_decrypts(
        self, partial_decrypts: List[dict], ctx=None
    ) -> np.ndarray:
        """
        Combine >= t partial decryptions via Lagrange interpolation to
        recover the plaintext aggregate.
        """
        if len(partial_decrypts) < self.t:
            raise ValueError(
                f"Need at least t={self.t} partial decrypts; "
                f"got {len(partial_decrypts)}"
            )
        # In simulate mode: average the partial decrypts (noise averages out)
        if partial_decrypts[0].get("__partial__"):
            arrays = [np.array(p["data"]) for p in partial_decrypts[: self.t]]
            return np.mean(arrays, axis=0).astype(np.float32)
        raise NotImplementedError(
            "Real SEAL threshold combine not implemented without libseal_threshold."
        )

    # ------------------------------------------------------------------
    # Serialization helpers
    # ------------------------------------------------------------------

    def serialize_ciphertext(self, ciphertext) -> bytes:
        """Serialize ciphertext to bytes for network transmission."""
        if isinstance(ciphertext, dict):
            import json
            return json.dumps(ciphertext).encode()
        return ciphertext.serialize()

    def deserialize_ciphertext(self, data: bytes, ctx):
        """Deserialize ciphertext bytes."""
        if data[:1] == b"{":
            import json
            return json.loads(data.decode())
        import tenseal as ts
        return ts.lazy_ckks_vector_from(data)
