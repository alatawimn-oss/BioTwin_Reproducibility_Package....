"""
src/continual/ewc.py

Elastic Weight Consolidation (EWC) for federated continual learning.

Paper spec:
  lambda    = 5000   (EWC regularization strength)
  n_tasks   = 6
  Prevents catastrophic forgetting when model sequentially learns
  arrhythmia -> sepsis -> mortality -> (3 synthetic tasks).

Reference:
  Kirkpatrick et al., "Overcoming catastrophic forgetting in neural
  networks," PNAS 2017. DOI: 10.1073/pnas.1611835114
"""

from __future__ import annotations

from copy import deepcopy
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader


class EWC:
    """
    Online EWC: accumulates Fisher information across tasks.

    Usage:
        ewc = EWC(model, lambda_ewc=5000)
        # After training task k, register it:
        ewc.register_task(model, task_dataloader, device)
        # During training on task k+1, add penalty to loss:
        loss = ce_loss + ewc.penalty(model)
    """

    def __init__(
        self,
        model: nn.Module,
        lambda_ewc: float = 5000.0,
        device: str | torch.device = "cpu",
        online: bool = True,
        gamma: float = 1.0,
    ) -> None:
        """
        Args:
            model:       The model being trained continually.
            lambda_ewc:  Paper spec: 5000.
            device:      Compute device.
            online:      True = online EWC (accumulate Fisher across tasks);
                         False = vanilla EWC (store per-task parameters).
            gamma:       Online EWC forgetting factor (1.0 = no decay).
        """
        self.model      = model
        self.lambda_ewc = lambda_ewc
        self.device     = torch.device(device)
        self.online     = online
        self.gamma      = gamma

        # Accumulated Fisher (online) or list of per-task Fishers (vanilla)
        self._fisher:  Dict[str, torch.Tensor] = {}
        self._params:  Dict[str, torch.Tensor] = {}  # θ* after each task
        self._n_tasks_registered               = 0

    # ------------------------------------------------------------------
    # Fisher estimation
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _zero_fisher(self) -> Dict[str, torch.Tensor]:
        return {
            name: torch.zeros_like(param)
            for name, param in self.model.named_parameters()
            if param.requires_grad
        }

    def _estimate_fisher(
        self,
        model: nn.Module,
        dataloader: DataLoader,
        n_samples: int = 1000,
    ) -> Dict[str, torch.Tensor]:
        """
        Estimate diagonal Fisher using empirical Fisher (squared gradient).
        Uses at most n_samples examples to keep cost bounded.
        """
        model.eval()
        fisher = self._zero_fisher()
        total  = 0

        for X, y in dataloader:
            if total >= n_samples:
                break
            X = X.to(self.device)
            y = y.to(self.device)

            model.zero_grad()
            logits = model(X)
            # Use log-likelihood (CE) as the loss for Fisher estimation
            loss = nn.functional.cross_entropy(logits, y.long())
            loss.backward()

            for name, param in model.named_parameters():
                if param.requires_grad and param.grad is not None:
                    fisher[name] += param.grad.detach() ** 2

            total += X.size(0)

        # Normalize
        n = max(total, 1)
        for name in fisher:
            fisher[name] /= n

        return fisher

    # ------------------------------------------------------------------
    # Task registration
    # ------------------------------------------------------------------

    def register_task(
        self,
        model: nn.Module,
        dataloader: DataLoader,
        device: Optional[str | torch.device] = None,
        n_samples: int = 1000,
    ) -> None:
        """
        Register the current task after training is complete.
        Estimates Fisher and stores optimal parameters θ*.

        Call once per task, after the final training step.
        """
        dev = torch.device(device) if device else self.device

        new_fisher = self._estimate_fisher(model, dataloader, n_samples)

        if self.online and self._n_tasks_registered > 0:
            # Online EWC: accumulate Fisher with decay
            for name in new_fisher:
                self._fisher[name] = (
                    self.gamma * self._fisher[name] + new_fisher[name]
                )
        else:
            self._fisher = new_fisher

        # Store θ* (optimal parameters after current task)
        self._params = {
            name: param.detach().clone().to(dev)
            for name, param in model.named_parameters()
            if param.requires_grad
        }

        self._n_tasks_registered += 1

    # ------------------------------------------------------------------
    # EWC penalty
    # ------------------------------------------------------------------

    def penalty(self, model: nn.Module) -> torch.Tensor:
        """
        Compute EWC regularization penalty:
            L_EWC = (lambda/2) * sum_i F_i * (theta_i - theta_i*)^2

        Returns scalar tensor; add to task loss during training.
        """
        if self._n_tasks_registered == 0:
            return torch.tensor(0.0, requires_grad=True)

        penalty = torch.tensor(0.0, device=self.device)

        for name, param in model.named_parameters():
            if name not in self._fisher:
                continue
            fisher = self._fisher[name].to(param.device)
            theta_star = self._params[name].to(param.device)
            penalty = penalty + (fisher * (param - theta_star) ** 2).sum()

        return (self.lambda_ewc / 2.0) * penalty

    # ------------------------------------------------------------------
    # State (for checkpointing across FL rounds)
    # ------------------------------------------------------------------

    def state_dict(self) -> dict:
        return {
            "fisher": self._fisher,
            "params": self._params,
            "n_tasks": self._n_tasks_registered,
            "lambda_ewc": self.lambda_ewc,
            "online": self.online,
            "gamma": self.gamma,
        }

    def load_state_dict(self, state: dict) -> None:
        self._fisher               = state["fisher"]
        self._params               = state["params"]
        self._n_tasks_registered   = state["n_tasks"]
        self.lambda_ewc            = state["lambda_ewc"]
        self.online                = state["online"]
        self.gamma                 = state["gamma"]
