"""
src/continual/replay.py

Reservoir experience replay for federated continual learning.

Paper spec:
  Buffer size    : 2000 samples per task
  n_tasks        : 6
  Strategy       : Reservoir sampling (each sample has equal probability
                   of being retained regardless of stream position)

Reservoir sampling guarantees uniform coverage of the full stream,
which is the standard choice for class-incremental scenarios.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset


class ExperienceReplay:
    """
    Reservoir-based experience replay buffer for continual learning.

    Maintains a fixed-size buffer per task. At training time, samples
    from past tasks are mixed with the current batch.

    Paper spec: 2000 samples per task, 6 tasks → 12,000 max buffer.

    Usage:
        replay = ExperienceReplay(buffer_size_per_task=2000, n_tasks=6)
        # After each task:
        replay.add_task(task_id=0, X=X_train, y=y_train)
        # During training on later tasks:
        X_replay, y_replay = replay.sample(batch_size=32, exclude_task=1)
        mixed_X = torch.cat([X_batch, X_replay])
        mixed_y = torch.cat([y_batch, y_replay])
    """

    def __init__(
        self,
        buffer_size_per_task: int = 2000,
        n_tasks: int = 6,
        seed: int = 42,
    ) -> None:
        self.buffer_size_per_task = buffer_size_per_task
        self.n_tasks              = n_tasks
        self.rng                  = np.random.default_rng(seed)

        # Per-task storage: dict[task_id] -> (X: Tensor, y: Tensor)
        self._buffer: dict[int, Tuple[torch.Tensor, torch.Tensor]] = {}
        # Stream counters for reservoir sampling
        self._stream_counts: dict[int, int] = {}

    # ------------------------------------------------------------------
    # Adding data
    # ------------------------------------------------------------------

    def add_task(
        self,
        task_id: int,
        X: torch.Tensor,
        y: torch.Tensor,
    ) -> None:
        """
        Add all training examples for a completed task to the buffer via
        reservoir sampling.

        Args:
            task_id:  Integer task identifier (0-indexed).
            X:        (N, T, F) tensor
            y:        (N,) tensor
        """
        N = X.size(0)
        cap = self.buffer_size_per_task

        if task_id not in self._buffer:
            # First batch for this task: take first cap samples directly
            idx = np.arange(min(N, cap))
            self._buffer[task_id] = (X[idx].cpu(), y[idx].cpu())
            self._stream_counts[task_id] = min(N, cap)
            remaining_start = cap
        else:
            remaining_start = 0

        # Reservoir sampling for remaining examples
        for i in range(remaining_start, N):
            self._stream_counts[task_id] += 1
            count = self._stream_counts[task_id]
            j = int(self.rng.integers(0, count))
            if j < cap:
                buf_X, buf_y = self._buffer[task_id]
                buf_X_new = buf_X.clone()
                buf_y_new = buf_y.clone()
                buf_X_new[j] = X[i].cpu()
                buf_y_new[j] = y[i].cpu()
                self._buffer[task_id] = (buf_X_new, buf_y_new)

    def add_from_dataloader(
        self,
        task_id: int,
        dataloader: DataLoader,
        max_samples: Optional[int] = None,
    ) -> None:
        """
        Fill buffer from a DataLoader, up to max_samples (or buffer_size_per_task).
        """
        limit = max_samples or self.buffer_size_per_task
        xs, ys = [], []
        total  = 0
        for X, y in dataloader:
            xs.append(X)
            ys.append(y)
            total += X.size(0)
            if total >= limit:
                break
        if xs:
            self.add_task(
                task_id,
                torch.cat(xs, dim=0)[:limit],
                torch.cat(ys, dim=0)[:limit],
            )

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    def sample(
        self,
        batch_size: int,
        exclude_task: Optional[int] = None,
        device: str | torch.device = "cpu",
    ) -> Optional[Tuple[torch.Tensor, torch.Tensor]]:
        """
        Sample batch_size examples uniformly from all stored tasks
        (optionally excluding the current task).

        Returns None if buffer is empty.
        """
        task_ids = [tid for tid in self._buffer if tid != exclude_task]
        if not task_ids:
            return None

        # Pool all buffered samples
        all_X = torch.cat([self._buffer[tid][0] for tid in task_ids], dim=0)
        all_y = torch.cat([self._buffer[tid][1] for tid in task_ids], dim=0)

        n = all_X.size(0)
        if n == 0:
            return None

        idx = self.rng.choice(n, size=min(batch_size, n), replace=False)
        idx_t = torch.from_numpy(idx).long()
        return all_X[idx_t].to(device), all_y[idx_t].to(device)

    def replay_dataloader(
        self,
        exclude_task: Optional[int] = None,
        batch_size: int = 32,
        shuffle: bool = True,
    ) -> Optional[DataLoader]:
        """
        Return a DataLoader over the entire replay buffer (excluding current task).
        Useful for a full replay pass at the end of each FL round.
        """
        task_ids = [tid for tid in self._buffer if tid != exclude_task]
        if not task_ids:
            return None

        all_X = torch.cat([self._buffer[tid][0] for tid in task_ids], dim=0)
        all_y = torch.cat([self._buffer[tid][1] for tid in task_ids], dim=0)

        ds = TensorDataset(all_X, all_y)
        return DataLoader(ds, batch_size=batch_size, shuffle=shuffle)

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    @property
    def n_tasks_stored(self) -> int:
        return len(self._buffer)

    def buffer_sizes(self) -> dict:
        return {tid: self._buffer[tid][0].size(0) for tid in self._buffer}

    def total_samples(self) -> int:
        return sum(v.size(0) for v, _ in self._buffer.values())

    # ------------------------------------------------------------------
    # Checkpointing
    # ------------------------------------------------------------------

    def state_dict(self) -> dict:
        return {
            "buffer":          self._buffer,
            "stream_counts":   self._stream_counts,
            "buffer_size_per_task": self.buffer_size_per_task,
            "n_tasks":         self.n_tasks,
        }

    def load_state_dict(self, state: dict) -> None:
        self._buffer              = state["buffer"]
        self._stream_counts       = state["stream_counts"]
        self.buffer_size_per_task = state["buffer_size_per_task"]
        self.n_tasks              = state["n_tasks"]
