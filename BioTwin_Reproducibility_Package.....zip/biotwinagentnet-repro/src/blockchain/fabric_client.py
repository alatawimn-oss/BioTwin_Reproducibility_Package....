"""
src/blockchain/fabric_client.py

Hyperledger Fabric v2.5 client for FL round auditability.

Paper spec:
  Platform       : Hyperledger Fabric v2.5
  Network        : 5-organization permissioned blockchain
  Latency        : 2 ms per round commit
  Purpose        : Immutable audit log of FL round model hashes,
                   aggregation metadata, and DP epsilon expenditure

This module provides:
  1. FabricClient  — interface to a live Fabric network (via hfc-py or
     a REST gateway). Falls back to MockFabricClient when hfc is absent
     so the rest of the pipeline can run without a Fabric deployment.
  2. FLRoundRecord — dataclass for the data committed per FL round.
  3. MockFabricClient — in-memory ledger for testing and CI.

Production deployment requires a running Fabric network with:
  - 5 orgs, 1 peer each
  - Endorsement policy: 3-of-5
  - Chaincode: fl_audit (simple key-value put/get)

[NOT STATED IN PAPER]:
  Channel name  : "fl-channel"
  Chaincode     : "fl_audit"
  REST gateway  : http://localhost:7051 (Fabric peer gRPC → REST proxy)
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Data record committed per FL round
# ---------------------------------------------------------------------------

@dataclass
class FLRoundRecord:
    """
    Immutable record committed to the blockchain after each FL round.

    Fields match the paper's auditability requirements:
    model aggregation hash, DP epsilon, participating clients, timestamp.
    """
    round_id:          int
    global_model_hash: str    # SHA-256 of serialized global model weights
    n_clients:         int    # Clients that participated in this round
    epsilon_spent:     float  # Cumulative DP epsilon after this round
    delta:             float  # DP delta
    aggregation_algo:  str    # "FedAvg" | "FedProx" | ...
    timestamp:         float  = field(default_factory=time.time)
    extra:             Dict   = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)

    @classmethod
    def from_json(cls, s: str) -> "FLRoundRecord":
        d = json.loads(s)
        return cls(**d)


# ---------------------------------------------------------------------------
# Utility: SHA-256 hash of model weights
# ---------------------------------------------------------------------------

def hash_model_weights(model) -> str:
    """
    Compute SHA-256 of all model parameters concatenated as bytes.
    Provides a reproducible fingerprint for each global model version.
    """
    import torch
    import io
    buf = io.BytesIO()
    for name, param in sorted(model.named_parameters()):
        torch.save(param.detach().cpu(), buf)
    return hashlib.sha256(buf.getvalue()).hexdigest()


# ---------------------------------------------------------------------------
# Mock Fabric client (in-memory ledger; no Fabric deployment needed)
# ---------------------------------------------------------------------------

class MockFabricClient:
    """
    In-memory mock of a Hyperledger Fabric ledger.
    API-compatible with FabricClient.

    Use for testing and reproducibility without a Fabric network.
    Simulates the 2 ms/round commit latency reported in the paper.
    """

    PAPER_COMMIT_LATENCY_MS = 2.0

    def __init__(self, simulate_latency: bool = False) -> None:
        self._ledger: Dict[str, str] = {}   # key -> JSON record
        self._history: List[FLRoundRecord]  = []
        self._simulate_latency = simulate_latency

    def commit_round(self, record: FLRoundRecord) -> str:
        """
        Commit an FL round record. Returns transaction ID (mocked).
        Simulates 2 ms commit if simulate_latency=True.
        """
        if self._simulate_latency:
            time.sleep(self.PAPER_COMMIT_LATENCY_MS / 1000.0)

        key   = f"round_{record.round_id:06d}"
        value = record.to_json()
        self._ledger[key] = value
        self._history.append(record)

        # Mock transaction ID: SHA-256 of key + value
        tx_id = hashlib.sha256(f"{key}{value}".encode()).hexdigest()[:16]
        return tx_id

    def get_round(self, round_id: int) -> Optional[FLRoundRecord]:
        key = f"round_{round_id:06d}"
        if key not in self._ledger:
            return None
        return FLRoundRecord.from_json(self._ledger[key])

    def get_all_rounds(self) -> List[FLRoundRecord]:
        return list(self._history)

    def audit_epsilon(self) -> List[Dict]:
        """Return per-round epsilon accounting for the full audit trail."""
        return [
            {"round_id": r.round_id, "epsilon": r.epsilon_spent, "ts": r.timestamp}
            for r in self._history
        ]

    @property
    def n_committed(self) -> int:
        return len(self._history)


# ---------------------------------------------------------------------------
# Real Fabric client (requires hfc or fabric-sdk-py)
# ---------------------------------------------------------------------------

class FabricClient:
    """
    Hyperledger Fabric v2.5 client via REST gateway (Fabric peer gateway API).

    Falls back to MockFabricClient if the fabric SDK or gateway is unavailable,
    so the training pipeline runs in environments without a Fabric deployment.

    Paper spec: 5-org permissioned network, 2 ms/round commit, audit log.

    Args:
        gateway_url:  REST gateway URL (e.g. "http://localhost:7051")
        channel:      Fabric channel name (default: "fl-channel")
        chaincode:    Chaincode name (default: "fl_audit")
        tls_cert:     Path to TLS certificate (None for insecure local testing)
        mock:         Force mock mode regardless of SDK availability
    """

    CHANNEL   = "fl-channel"     # [NOT STATED IN PAPER]
    CHAINCODE = "fl_audit"       # [NOT STATED IN PAPER]

    def __init__(
        self,
        gateway_url: str           = "http://localhost:7051",
        channel: str               = CHANNEL,
        chaincode: str             = CHAINCODE,
        tls_cert: Optional[str]    = None,
        mock: bool                 = False,
    ) -> None:
        self.gateway_url = gateway_url
        self.channel     = channel
        self.chaincode   = chaincode
        self.tls_cert    = tls_cert
        self._mock_client: Optional[MockFabricClient] = None

        if mock:
            self._mock_client = MockFabricClient()
            return

        # Attempt to connect to real gateway
        try:
            self._connect()
        except Exception as exc:
            import warnings
            warnings.warn(
                f"Fabric gateway unavailable ({exc}). "
                "Falling back to mock in-memory ledger. "
                "Set mock=True to suppress this warning.",
                stacklevel=2,
            )
            self._mock_client = MockFabricClient()

    def _connect(self) -> None:
        """
        Probe the Fabric REST gateway with a lightweight health check.
        Raises ConnectionError if unreachable.
        """
        import urllib.request
        health_url = self.gateway_url.rstrip("/") + "/health"
        try:
            req = urllib.request.Request(health_url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                if resp.status not in (200, 204):
                    raise ConnectionError(
                        f"Fabric gateway health check returned HTTP {resp.status}"
                    )
        except Exception as e:
            raise ConnectionError(str(e)) from e

    def _invoke(self, function: str, args: List[str]) -> str:
        """
        Invoke a chaincode transaction (write).
        Returns transaction ID on success.
        """
        if self._mock_client:
            # Should not happen; commit_round handles mock path
            raise RuntimeError("In mock mode; use commit_round directly.")

        import urllib.request
        payload = json.dumps({
            "function": f"{self.chaincode}:{function}",
            "args":     args,
        }).encode()
        url = (
            f"{self.gateway_url}/channels/{self.channel}"
            f"/chaincodes/{self.chaincode}"
        )
        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = json.loads(resp.read().decode())
                return body.get("transactionID", "unknown")
        except Exception as e:
            raise RuntimeError(f"Fabric invoke failed: {e}") from e

    def _query(self, function: str, args: List[str]) -> str:
        """Query a chaincode function (read-only)."""
        if self._mock_client:
            raise RuntimeError("In mock mode.")

        import urllib.request
        url = (
            f"{self.gateway_url}/channels/{self.channel}"
            f"/chaincodes/{self.chaincode}"
            f"?function={function}&args={','.join(args)}"
        )
        with urllib.request.urlopen(url, timeout=10) as resp:
            return resp.read().decode()

    # ------------------------------------------------------------------
    # Public API (matches MockFabricClient)
    # ------------------------------------------------------------------

    def commit_round(self, record: FLRoundRecord) -> str:
        """
        Commit an FL round record to the blockchain.
        Returns transaction ID (hex string).
        """
        if self._mock_client:
            return self._mock_client.commit_round(record)

        key   = f"round_{record.round_id:06d}"
        value = record.to_json()
        return self._invoke("PutRecord", [key, value])

    def get_round(self, round_id: int) -> Optional[FLRoundRecord]:
        if self._mock_client:
            return self._mock_client.get_round(round_id)

        key  = f"round_{round_id:06d}"
        raw  = self._query("GetRecord", [key])
        if not raw or raw.strip() == "null":
            return None
        return FLRoundRecord.from_json(raw)

    def get_all_rounds(self) -> List[FLRoundRecord]:
        if self._mock_client:
            return self._mock_client.get_all_rounds()
        # Enumerate up to 300 rounds [NOT STATED IN PAPER: heuristic]
        records = []
        for rid in range(300):
            r = self.get_round(rid)
            if r is None:
                break
            records.append(r)
        return records

    def audit_epsilon(self) -> List[Dict]:
        return [
            {"round_id": r.round_id, "epsilon": r.epsilon_spent, "ts": r.timestamp}
            for r in self.get_all_rounds()
        ]

    @property
    def is_mock(self) -> bool:
        return self._mock_client is not None
