"""
src/watermark/watermark.py

Differentiable model watermarking for IP protection.

Paper spec:
  Method         : Differentiable L2 regularization toward CSPRNG pattern
  lambda_w       : 0.01       (watermark loss weight)
  tau            : 0.1        (target weight magnitude; sign carries pattern)
  d              : 45,000     (number of watermarked weights, ~10% of params)
  Pattern        : CSPRNG generated from WATERMARK_SECRET_SEED env var
  Bit agreement  : 98.7% post-INT8 quantization
  Threshold theta: 0.80       (hypothesis test for ownership verification)
  Privacy        : Seed MUST come from WATERMARK_SECRET_SEED env var,
                   NEVER hardcoded.

Loss term added during Phase 1 FL training:
  L_total = L_task + lambda_w * L_watermark
  L_watermark = (1/d) * sum_i ||w_i - tau*p_i||^2
where p_i in {-1, +1} is the CSPRNG bit pattern.

Verification (post-deployment):
  Given a suspect model, extract the d watermarked weights,
  compute bit agreement with the reference pattern, and apply
  hypothesis test at threshold theta=0.80.
"""

from __future__ import annotations

import hashlib
import os
import struct
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn


def _load_secret_seed() -> int:
    """
    Load watermark secret seed from WATERMARK_SECRET_SEED environment variable.
    Raises RuntimeError if the variable is not set.
    NEVER hardcode this seed.
    """
    seed_str = os.environ.get("WATERMARK_SECRET_SEED")
    if not seed_str:
        raise RuntimeError(
            "WATERMARK_SECRET_SEED environment variable is not set. "
            "Export it before training: "
            "export WATERMARK_SECRET_SEED=<your-secret-integer>"
        )
    try:
        return int(seed_str)
    except ValueError:
        # Accept hex strings
        return int(seed_str, 16)


def _csprng_pattern(d: int, seed: int) -> np.ndarray:
    """
    Generate a deterministic ±1 bit pattern of length d using a
    CSPRNG seeded with the secret.

    Uses SHA-256-based expansion (not numpy.random, which is not a CSPRNG).
    Each bit of the pattern is derived from successive SHA-256 digests
    of (seed || counter).
    """
    bits = np.empty(d, dtype=np.int8)
    seed_bytes = seed.to_bytes(8, byteorder="big", signed=False)
    idx = 0
    counter = 0
    while idx < d:
        h = hashlib.sha256(seed_bytes + counter.to_bytes(4, "big")).digest()
        for byte in h:
            for shift in range(8):
                if idx >= d:
                    break
                bits[idx] = 1 if (byte >> shift) & 1 else -1
                idx += 1
        counter += 1
    return bits  # shape (d,), values in {-1, +1}


def _select_watermark_indices(
    model: nn.Module, d: int, seed: int
) -> np.ndarray:
    """
    Deterministically select d parameter indices from a flattened
    view of all model weights using a seeded RNG.

    Parameters are flattened to 1-D in named_parameters order.

    Returns:
        indices: np.ndarray of shape (d,), dtype int64
    """
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    if d > total_params:
        raise ValueError(
            f"Requested d={d} watermark weights but model has only "
            f"{total_params} trainable parameters."
        )
    rng = np.random.default_rng(seed)
    return rng.choice(total_params, size=d, replace=False)


class ModelWatermark:
    """
    Differentiable watermarking for BioTwin-AgentNet.

    Usage — training:
        wm = ModelWatermark(model, d=45000, lambda_w=0.01, tau=0.1)
        # During each training step:
        loss_total = loss_task + wm.loss(model)

    Usage — verification:
        result = wm.verify(suspect_model, theta=0.80)
        print(result["bit_agreement"], result["is_watermarked"])
    """

    # Paper constants
    PAPER_D        = 45_000
    PAPER_LAMBDA_W = 0.01
    PAPER_TAU      = 0.1
    PAPER_THETA    = 0.80
    PAPER_BIT_AGR  = 0.987   # post-INT8 target

    def __init__(
        self,
        model: nn.Module,
        d: int            = PAPER_D,
        lambda_w: float   = PAPER_LAMBDA_W,
        tau: float        = PAPER_TAU,
        seed: Optional[int] = None,
    ) -> None:
        """
        Args:
            model:    The model to watermark.
            d:        Number of weights to embed pattern into (paper: 45,000).
            lambda_w: Watermark loss weight (paper: 0.01).
            tau:      Target weight magnitude (paper: 0.1).
            seed:     Secret seed. If None, loads from WATERMARK_SECRET_SEED.
                      NEVER pass a hardcoded integer in production code;
                      set the environment variable instead.
        """
        self.d        = d
        self.lambda_w = lambda_w
        self.tau      = tau
        self._seed    = seed if seed is not None else _load_secret_seed()

        # Generate pattern and indices
        self._pattern = _csprng_pattern(d, self._seed)       # (d,) in {-1,+1}
        self._indices = _select_watermark_indices(model, d, self._seed)

        # Register as buffer in model for checkpointing (no gradient)
        pattern_t = torch.from_numpy(self._pattern).float()
        indices_t = torch.from_numpy(self._indices).long()

        # Try to register buffers on the model; fall back to plain attrs
        try:
            model.register_buffer("_wm_pattern", pattern_t, persistent=True)
            model.register_buffer("_wm_indices", indices_t, persistent=True)
        except AttributeError:
            pass   # model does not inherit nn.Module

    # ------------------------------------------------------------------
    # Training: watermark loss
    # ------------------------------------------------------------------

    def loss(self, model: nn.Module) -> torch.Tensor:
        """
        Compute watermark regularization loss:
            L_wm = (1/d) * sum_i ||w_i - tau * p_i||^2

        Args:
            model: Current model (must have same architecture as __init__)

        Returns:
            Scalar loss tensor (differentiable w.r.t. model parameters).
        """
        flat_params = self._get_flat_params(model)
        # Select watermarked weights
        wm_weights  = flat_params[self._indices]

        # Target: tau * pattern
        target = torch.from_numpy(
            self.tau * self._pattern
        ).float().to(wm_weights.device)

        loss = ((wm_weights - target) ** 2).mean()
        return self.lambda_w * loss

    # ------------------------------------------------------------------
    # Verification: ownership test
    # ------------------------------------------------------------------

    @torch.no_grad()
    def verify(
        self,
        model: nn.Module,
        theta: float = PAPER_THETA,
    ) -> dict:
        """
        Verify model ownership via watermark bit agreement.

        Paper: theta = 0.80, post-INT8 bit agreement = 98.7%.

        Returns dict with:
            bit_agreement : float, fraction of bits matching pattern
            is_watermarked: bool, True if bit_agreement >= theta
            theta         : threshold used
            d             : number of bits tested
        """
        flat_params = self._get_flat_params(model)
        wm_weights  = flat_params[self._indices].cpu().numpy()

        # Extracted bits: sign of watermarked weights
        extracted_bits = np.sign(wm_weights).astype(np.int8)
        # Handle exact zeros
        extracted_bits[extracted_bits == 0] = 1

        agreement = float(np.mean(extracted_bits == self._pattern))

        return {
            "bit_agreement":  agreement,
            "is_watermarked": agreement >= theta,
            "theta":          theta,
            "d":              self.d,
            "paper_target":   self.PAPER_BIT_AGR,
        }

    @torch.no_grad()
    def verify_int8(
        self,
        fp32_model: nn.Module,
        int8_model: nn.Module,
        theta: float = PAPER_THETA,
    ) -> dict:
        """
        Verify bit agreement is maintained after INT8 quantization.

        Paper: 98.7% bit agreement post-INT8.
        """
        result_fp32 = self.verify(fp32_model, theta)
        result_int8 = self.verify(int8_model, theta)
        return {
            "fp32_bit_agreement":   result_fp32["bit_agreement"],
            "int8_bit_agreement":   result_int8["bit_agreement"],
            "int8_is_watermarked":  result_int8["is_watermarked"],
            "paper_target":         self.PAPER_BIT_AGR,
            "theta":                theta,
        }

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _get_flat_params(model: nn.Module) -> torch.Tensor:
        """Return all trainable parameters as a single 1-D tensor."""
        parts = [
            p.detach().reshape(-1)
            for p in model.parameters()
            if p.requires_grad
        ]
        if not parts:
            raise ValueError("Model has no trainable parameters.")
        return torch.cat(parts)

    def embed_pattern(self, model: nn.Module) -> None:
        """
        Directly embed the watermark pattern into the model weights
        (useful for initialization before training).
        Not needed during differentiable training.
        """
        flat_params = self._get_flat_params(model)
        with torch.no_grad():
            target = torch.from_numpy(
                self.tau * self._pattern
            ).float().to(flat_params.device)

            # Write back to model parameters
            offset = 0
            idx_set = set(self._indices.tolist())
            for param in model.parameters():
                if not param.requires_grad:
                    continue
                n = param.numel()
                flat_view = param.data.reshape(-1)
                for local_i in range(n):
                    global_i = offset + local_i
                    if global_i in idx_set:
                        pos_in_wm = int(np.where(self._indices == global_i)[0][0])
                        flat_view[local_i] = target[pos_in_wm]
                offset += n

    def watermark_state(self) -> dict:
        """Return serializable watermark state (no secret seed)."""
        return {
            "d":        self.d,
            "lambda_w": self.lambda_w,
            "tau":      self.tau,
            "theta":    self.PAPER_THETA,
        }
