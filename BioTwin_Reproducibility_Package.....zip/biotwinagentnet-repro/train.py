"""
train.py

BioTwin-AgentNet three-phase federated training orchestration.

Paper training phases:
  Phase 1 — Teacher FL  : FedAvg, 200 rounds, 100 clients, 5 local epochs,
                          batch=32, Adam, cosine annealing + 10-round warmup,
                          DP (sigma=1.12, C=1.0, delta=1e-5), watermark,
                          EWC + experience replay (6 continual tasks),
                          blockchain audit log
  Phase 2 — KD          : TeacherLSTM → StudentLSTM on eICU,
                          T=4, alpha=0.3, 50 epochs
  Phase 3 — Student FL  : FedAvg, 200 rounds, 100 clients, INT8 student,
                          MAML adaptation module

Usage:
    python train.py --phase 1 --config configs/main.yaml
    python train.py --phase 2 --config configs/main.yaml
    python train.py --phase 3 --config configs/main.yaml
    python train.py --phase all --config configs/main.yaml
"""

from __future__ import annotations

import argparse
import copy
import os
import random
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
import yaml
from torch.utils.data import DataLoader, Subset

# Internal imports
from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
from src.datasets.eicu_dataset import eICUDataset
from src.models.teacher import TeacherLSTM
from src.models.student import StudentLSTM
from src.models.quantization import quantize_model
from src.losses.distillation_loss import DistillationLoss
from src.privacy.dp_accounting import DPAccountant
from src.continual.ewc import EWC
from src.continual.replay import ExperienceReplay
from src.watermark.watermark import ModelWatermark
from src.blockchain.fabric_client import FabricClient, FLRoundRecord, hash_model_weights
from src.distillation.kd import KnowledgeDistillation
from src.meta.maml import MAML
from src.utils.seeding import set_global_seed
from src.utils.logging_utils import CSVLogger, get_tb_writer
from src.utils.checkpointing import save_checkpoint, load_checkpoint, latest_checkpoint
from src.metrics.evaluation import EvaluationSuite


# ---------------------------------------------------------------------------
# Configuration loader
# ---------------------------------------------------------------------------

def load_config(path: str) -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    return cfg


# ---------------------------------------------------------------------------
# FedAvg aggregation
# ---------------------------------------------------------------------------

def fedavg_aggregate(
    global_model: nn.Module,
    client_state_dicts: List[Dict],
    client_weights: Optional[List[float]] = None,
) -> nn.Module:
    """
    FedAvg: weighted average of client state dicts.
    client_weights defaults to uniform (1/N).
    """
    n = len(client_state_dicts)
    if client_weights is None:
        client_weights = [1.0 / n] * n

    global_sd = copy.deepcopy(global_model.state_dict())

    for key in global_sd:
        global_sd[key] = torch.zeros_like(global_sd[key], dtype=torch.float32)

    for sd, w in zip(client_state_dicts, client_weights):
        for key in global_sd:
            global_sd[key] += w * sd[key].float()

    global_model.load_state_dict(global_sd)
    return global_model


# ---------------------------------------------------------------------------
# Cosine annealing with linear warmup LR scheduler
# ---------------------------------------------------------------------------

class WarmupCosineScheduler:
    """
    Linear warmup for warmup_rounds, then cosine annealing.
    Paper spec: 10-round warmup, cosine over 200 rounds.
    """
    def __init__(
        self,
        optimizer: torch.optim.Optimizer,
        warmup_rounds: int  = 10,
        total_rounds:  int  = 200,
        eta_min:       float = 1e-6,
    ) -> None:
        self.opt           = optimizer
        self.warmup_rounds = warmup_rounds
        self.total_rounds  = total_rounds
        self.eta_min       = eta_min
        self._base_lrs     = [g["lr"] for g in optimizer.param_groups]

    def step(self, round_idx: int) -> None:
        if round_idx < self.warmup_rounds:
            factor = (round_idx + 1) / max(self.warmup_rounds, 1)
        else:
            progress = (round_idx - self.warmup_rounds) / max(
                self.total_rounds - self.warmup_rounds, 1
            )
            factor = self.eta_min + 0.5 * (1 - self.eta_min) * (
                1 + np.cos(np.pi * progress)
            )
        for base_lr, group in zip(self._base_lrs, self.opt.param_groups):
            group["lr"] = base_lr * factor


# ---------------------------------------------------------------------------
# Phase 1: Teacher Federated Learning
# ---------------------------------------------------------------------------

def phase1_teacher_fl(cfg: dict, args) -> nn.Module:
    """
    Phase 1: TeacherLSTM federated training with:
      - FedAvg aggregation
      - Differential privacy (Opacus)
      - EWC + experience replay
      - Model watermarking
      - Blockchain audit
    """
    print("\n" + "=" * 70)
    print("Phase 1: Teacher Federated Learning")
    print("=" * 70)

    fl_cfg   = cfg["federated_learning"]
    dp_cfg   = cfg["privacy"]["differential_privacy"]
    task_cfg = cfg["training"]
    model_cfg = cfg["model"]["teacher"]

    n_rounds    = fl_cfg["n_rounds"]           # 200
    n_clients   = fl_cfg["n_clients"]          # 100
    local_epochs = fl_cfg["local_epochs"]      # 5
    batch_size  = fl_cfg["batch_size"]         # 32
    base_lr     = task_cfg["learning_rate"]    # 1e-3
    n_features  = cfg["data"]["mimic4"]["n_features"]    # 127
    seq_len     = cfg["data"]["mimic4"]["seq_len"]       # 48
    tasks       = ["arrhythmia", "sepsis", "mortality"]
    n_cl_tasks  = cfg["training"]["n_continual_tasks"]   # 6
    device      = torch.device(args.device)

    out_dir = Path(args.output_dir) / "phase1"
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_logger = CSVLogger(out_dir / "metrics.csv")
    tb         = get_tb_writer(out_dir / "tb", comment="phase1")

    # --- Global model ---
    global_model = TeacherLSTM(
        n_features   = n_features,
        hidden_size  = model_cfg["hidden_size"],
        num_layers   = model_cfg["num_layers"],
        n_classes    = model_cfg["n_classes"],
        dropout      = model_cfg["dropout"],
        bidirectional = model_cfg["bidirectional"],
    ).to(device)

    # --- Watermark ---
    watermark = ModelWatermark(
        global_model,
        d        = cfg["watermark"]["d"],
        lambda_w = cfg["watermark"]["lambda_w"],
        tau      = cfg["watermark"]["tau"],
    )

    # --- Blockchain ---
    blockchain = FabricClient(mock=True)

    # --- EWC + replay ---
    ewc    = EWC(global_model, lambda_ewc=cfg["training"]["ewc_lambda"], device=device)
    replay = ExperienceReplay(
        buffer_size_per_task = cfg["training"]["replay_buffer_size"],
        n_tasks              = n_cl_tasks,
        seed                 = cfg["experiment"]["seed"],
    )

    # --- Dataset: MIMIC-IV ---
    data_root = Path(cfg["data"]["mimic4"]["processed_dir"])
    train_ids = load_split_ids("data/splits/mimic4_train_ids.txt")
    val_ids   = load_split_ids("data/splits/mimic4_val_ids.txt")

    # Pre-build per-client index ranges (IID partition for reproducibility)
    n_train      = len(train_ids)
    client_size  = n_train // n_clients
    rng_np       = np.random.default_rng(cfg["experiment"]["seed"])
    shuffled_idx = rng_np.permutation(n_train)

    # Evaluation suite
    eval_suite = EvaluationSuite()

    # --- Resume ---
    start_round = 0
    ckpt_path   = latest_checkpoint(out_dir)
    if ckpt_path and not args.no_resume:
        ckpt        = load_checkpoint(ckpt_path, global_model, device=device)
        start_round = ckpt.get("round", 0) + 1
        print(f"[Phase 1] Resumed from round {start_round - 1}")

    # === FL rounds ===
    for rnd in range(start_round, n_rounds):
        t0 = time.time()
        global_model.eval()

        # Sample n_clients_per_round clients (paper: all 100 each round)
        active_clients = list(range(n_clients))

        client_state_dicts = []
        client_losses      = []

        for cid in active_clients:
            # --- Client local dataset ---
            lo  = cid * client_size
            hi  = lo + client_size
            idx = shuffled_idx[lo:hi].tolist()

            # Cycle through continual tasks (6 tasks over 200 rounds)
            task_idx = (rnd * n_clients + cid) % n_cl_tasks
            task_name = tasks[task_idx % len(tasks)]

            client_model = copy.deepcopy(global_model).to(device)

            # Build data loader for this client
            # (In full run, MIMIC4Dataset is loaded from HDF5)
            # Using synthetic data stub if HDF5 not found
            try:
                client_ds     = MIMIC4Dataset(
                    hdf5_path  = str(data_root / "train.h5"),
                    split_ids  = [train_ids[i] for i in idx],
                    task       = task_name,
                    client_id  = cid,
                    n_clients  = n_clients,
                    seed       = cfg["experiment"]["seed"],
                )
                client_loader = DataLoader(
                    client_ds, batch_size=batch_size, shuffle=True,
                    num_workers=0, drop_last=True,
                )
            except FileNotFoundError:
                # Synthetic stub for CI/testing without real data
                X_syn = torch.randn(batch_size * 4, seq_len, n_features)
                y_syn = torch.randint(0, 2, (batch_size * 4,))
                client_loader = DataLoader(
                    list(zip(X_syn, y_syn)), batch_size=batch_size, shuffle=True
                )

            # --- Client optimizer ---
            optimizer = torch.optim.Adam(
                client_model.parameters(), lr=base_lr,
                betas=(0.9, 0.999), weight_decay=1e-4,
            )
            scheduler = WarmupCosineScheduler(
                optimizer,
                warmup_rounds = fl_cfg["warmup_rounds"],
                total_rounds  = n_rounds,
            )
            scheduler.step(rnd)

            loss_fn = nn.CrossEntropyLoss()

            # --- Attach DP engine ---
            dp_accountant = DPAccountant(
                noise_multiplier = dp_cfg["noise_multiplier"],
                max_grad_norm    = dp_cfg["max_grad_norm"],
                delta            = dp_cfg["delta"],
                sample_rate      = dp_cfg["sample_rate"],
            )
            if args.use_dp:
                try:
                    client_model, optimizer, client_loader = dp_accountant.attach(
                        client_model, optimizer, client_loader
                    )
                except Exception as e:
                    if args.verbose:
                        print(f"  [DP] attach failed on client {cid}: {e}")

            # --- Local training ---
            client_model.train()
            ep_loss = 0.0
            for ep in range(local_epochs):
                for X, y in client_loader:
                    X = X.to(device)
                    y = y.to(device)
                    optimizer.zero_grad()
                    logits = client_model(X)
                    loss   = loss_fn(logits, y.long())
                    # EWC penalty
                    loss   = loss + ewc.penalty(client_model)
                    # Watermark loss
                    loss   = loss + watermark.loss(client_model)
                    loss.backward()
                    nn.utils.clip_grad_norm_(client_model.parameters(), dp_cfg["max_grad_norm"])
                    optimizer.step()
                    ep_loss += loss.item()

            # Replay (mix with past tasks)
            replay_batch = replay.sample(batch_size, exclude_task=task_idx, device=device)
            if replay_batch is not None:
                Xr, yr = replay_batch
                client_model.train()
                optimizer.zero_grad()
                logits = client_model(Xr)
                loss_r = loss_fn(logits, yr.long())
                loss_r.backward()
                optimizer.step()

            client_state_dicts.append(copy.deepcopy(client_model.state_dict()))
            client_losses.append(ep_loss)

        # --- FedAvg aggregation ---
        global_model = fedavg_aggregate(global_model, client_state_dicts)

        # --- Update EWC Fisher (every 10 rounds on representative client) ---
        if rnd > 0 and rnd % 10 == 0:
            try:
                ewc.register_task(
                    global_model,
                    DataLoader(
                        list(zip(
                            torch.randn(200, seq_len, n_features),
                            torch.randint(0, 2, (200,)),
                        )),
                        batch_size=32,
                    ),
                    device=device,
                )
            except Exception:
                pass

        # --- Blockchain commit ---
        eps_now = 0.0
        if args.use_dp:
            try:
                eps_now = dp_accountant.epsilon()
            except Exception:
                eps_now = 0.0

        tx_id = blockchain.commit_round(FLRoundRecord(
            round_id          = rnd,
            global_model_hash = hash_model_weights(global_model),
            n_clients         = len(active_clients),
            epsilon_spent     = eps_now,
            delta             = dp_cfg["delta"],
            aggregation_algo  = "FedAvg",
        ))

        # --- Logging ---
        mean_loss = float(np.mean(client_losses)) if client_losses else 0.0
        elapsed   = time.time() - t0
        row = {
            "round":      rnd,
            "mean_loss":  mean_loss,
            "epsilon":    eps_now,
            "tx_id":      tx_id,
            "time_s":     elapsed,
        }
        csv_logger.log(row)
        tb.add_scalar("phase1/mean_loss", mean_loss, rnd)
        tb.add_scalar("phase1/epsilon",   eps_now,   rnd)

        if rnd % 10 == 0 or rnd == n_rounds - 1:
            print(
                f"  Round {rnd:3d}/{n_rounds} | loss={mean_loss:.4f} "
                f"| eps={eps_now:.2f} | {elapsed:.1f}s"
            )
            save_checkpoint(
                out_dir / f"teacher_round_{rnd:03d}.pt",
                global_model,
                round_or_epoch = rnd,
                metrics        = row,
            )

    # Save final teacher
    save_checkpoint(out_dir / "teacher_final.pt", global_model,
                    round_or_epoch=n_rounds - 1)

    # Watermark verification
    wm_result = watermark.verify(global_model)
    print(f"\n[Phase 1] Watermark bit agreement: {wm_result['bit_agreement']:.4f} "
          f"(threshold={wm_result['theta']})")

    tb.close()
    print("[Phase 1] Complete.")
    return global_model


# ---------------------------------------------------------------------------
# Phase 2: Knowledge Distillation
# ---------------------------------------------------------------------------

def phase2_distillation(
    cfg: dict,
    args,
    teacher: Optional[nn.Module] = None,
) -> nn.Module:
    """
    Phase 2: Teacher → Student KD on eICU.
    Returns trained StudentLSTM.
    """
    print("\n" + "=" * 70)
    print("Phase 2: Knowledge Distillation (teacher → student on eICU)")
    print("=" * 70)

    model_cfg = cfg["model"]
    kd_cfg    = cfg["knowledge_distillation"]
    device    = torch.device(args.device)

    # Load teacher from Phase 1 checkpoint if not passed in
    if teacher is None:
        teacher = TeacherLSTM(
            n_features    = cfg["data"]["mimic4"]["n_features"],
            hidden_size   = model_cfg["teacher"]["hidden_size"],
            num_layers    = model_cfg["teacher"]["num_layers"],
            n_classes     = model_cfg["teacher"]["n_classes"],
            dropout       = model_cfg["teacher"]["dropout"],
            bidirectional = model_cfg["teacher"]["bidirectional"],
        )
        ckpt_path = Path(args.output_dir) / "phase1" / "teacher_final.pt"
        if ckpt_path.exists():
            load_checkpoint(ckpt_path, teacher, device=device)
            print(f"[Phase 2] Loaded teacher from {ckpt_path}")
        else:
            print(f"[Phase 2] Warning: teacher checkpoint not found at {ckpt_path}")

    student = StudentLSTM(
        n_features  = cfg["data"]["mimic4"]["n_features"],
        hidden_size = model_cfg["student"]["hidden_size"],
        num_layers  = model_cfg["student"]["num_layers"],
        n_classes   = model_cfg["student"]["n_classes"],
        dropout     = model_cfg["student"]["dropout"],
    )

    out_dir = Path(args.output_dir) / "phase2"

    # Build eICU dataloader
    try:
        eicu_ds     = eICUDataset(
            hdf5_path   = str(Path(cfg["data"]["eicu"]["processed_dir"]) / "distillation.h5"),
            max_samples = None,
        )
        eicu_loader = DataLoader(
            eicu_ds,
            batch_size  = cfg["federated_learning"]["batch_size"],
            shuffle     = True,
            num_workers = 0,
        )
    except FileNotFoundError:
        print("[Phase 2] eICU HDF5 not found; using synthetic stub.")
        seq_len    = cfg["data"]["mimic4"]["seq_len"]
        n_features = cfg["data"]["mimic4"]["n_features"]
        X_syn = torch.randn(1000, seq_len, n_features)
        y_syn = torch.randint(0, 2, (1000,))
        eicu_loader = DataLoader(
            list(zip(X_syn, y_syn)),
            batch_size=cfg["federated_learning"]["batch_size"],
            shuffle=True,
        )

    kd = KnowledgeDistillation(
        teacher     = teacher,
        student     = student,
        temperature = kd_cfg["temperature"],
        alpha       = kd_cfg["alpha"],
        device      = device,
    )

    kd.train(
        train_loader = eicu_loader,
        n_epochs     = 50,          # [NOT STATED IN PAPER]
        lr           = 1e-3,
        output_dir   = str(out_dir),
        resume       = not args.no_resume,
    )

    kd.load_best_student(str(out_dir))
    print("[Phase 2] Complete.")
    return student


# ---------------------------------------------------------------------------
# Phase 3: Student Federated Learning
# ---------------------------------------------------------------------------

def phase3_student_fl(
    cfg: dict,
    args,
    student: Optional[nn.Module] = None,
) -> nn.Module:
    """
    Phase 3: StudentLSTM federated training on edge clients.
    INT8 quantization applied before deployment.
    MAML adaptation module trained.
    """
    print("\n" + "=" * 70)
    print("Phase 3: Student Federated Learning (edge)")
    print("=" * 70)

    fl_cfg    = cfg["federated_learning"]
    model_cfg = cfg["model"]["student"]
    device    = torch.device(args.device)

    n_rounds     = fl_cfg["n_rounds"]
    n_clients    = fl_cfg["n_clients"]
    local_epochs = fl_cfg["local_epochs"]
    batch_size   = fl_cfg["batch_size"]
    base_lr      = cfg["training"]["learning_rate"]
    n_features   = cfg["data"]["mimic4"]["n_features"]
    seq_len      = cfg["data"]["mimic4"]["seq_len"]

    out_dir = Path(args.output_dir) / "phase3"
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_logger = CSVLogger(out_dir / "metrics.csv")
    tb         = get_tb_writer(out_dir / "tb", comment="phase3")

    # Load or build student
    if student is None:
        student = StudentLSTM(
            n_features  = n_features,
            hidden_size = model_cfg["hidden_size"],
            num_layers  = model_cfg["num_layers"],
            n_classes   = model_cfg["n_classes"],
            dropout     = model_cfg["dropout"],
        )
        ckpt_path = Path(args.output_dir) / "phase2" / "best_student.pt"
        if ckpt_path.exists():
            load_checkpoint(ckpt_path, student, device=device)
            print(f"[Phase 3] Loaded student from {ckpt_path}")

    global_model = student.to(device)

    # MAML for edge adaptation
    maml = MAML(
        model       = copy.deepcopy(global_model),
        inner_lr    = cfg["meta_learning"]["inner_lr"],
        inner_steps = cfg["meta_learning"]["inner_steps"],
        outer_lr    = 1e-3,
        device      = device,
    )

    train_ids = load_split_ids("data/splits/mimic4_train_ids.txt")
    n_train   = len(train_ids)
    client_size = n_train // n_clients
    rng_np    = np.random.default_rng(cfg["experiment"]["seed"])
    shuffled_idx = rng_np.permutation(n_train)

    data_root = Path(cfg["data"]["mimic4"]["processed_dir"])

    start_round = 0
    ckpt_path   = latest_checkpoint(out_dir)
    if ckpt_path and not args.no_resume:
        ckpt        = load_checkpoint(ckpt_path, global_model, device=device)
        start_round = ckpt.get("round", 0) + 1

    for rnd in range(start_round, n_rounds):
        t0 = time.time()
        global_model.eval()
        client_state_dicts = []
        client_losses      = []

        for cid in range(n_clients):
            lo  = cid * client_size
            hi  = lo + client_size
            idx = shuffled_idx[lo:hi].tolist()

            client_model = copy.deepcopy(global_model).to(device)
            optimizer    = torch.optim.Adam(
                client_model.parameters(), lr=base_lr,
                weight_decay=1e-4,
            )
            loss_fn = nn.CrossEntropyLoss()

            # Build loader
            try:
                client_ds = MIMIC4Dataset(
                    hdf5_path = str(data_root / "train.h5"),
                    split_ids = [train_ids[i] for i in idx],
                    task      = "arrhythmia",
                    client_id = cid,
                    n_clients = n_clients,
                    seed      = cfg["experiment"]["seed"],
                )
                client_loader = DataLoader(
                    client_ds, batch_size=batch_size, shuffle=True,
                    num_workers=0, drop_last=True,
                )
            except FileNotFoundError:
                X_syn = torch.randn(batch_size * 4, seq_len, n_features)
                y_syn = torch.randint(0, 2, (batch_size * 4,))
                client_loader = DataLoader(
                    list(zip(X_syn, y_syn)), batch_size=batch_size, shuffle=True
                )

            client_model.train()
            ep_loss = 0.0
            for ep in range(local_epochs):
                for X, y in client_loader:
                    X = X.to(device)
                    y = y.to(device)
                    optimizer.zero_grad()
                    logits = client_model(X)
                    loss   = loss_fn(logits, y.long())
                    loss.backward()
                    nn.utils.clip_grad_norm_(client_model.parameters(), 1.0)
                    optimizer.step()
                    ep_loss += loss.item()

            client_state_dicts.append(copy.deepcopy(client_model.state_dict()))
            client_losses.append(ep_loss)

        global_model = fedavg_aggregate(global_model, client_state_dicts)

        mean_loss = float(np.mean(client_losses))
        elapsed   = time.time() - t0
        row = {"round": rnd, "mean_loss": mean_loss, "time_s": elapsed}
        csv_logger.log(row)
        tb.add_scalar("phase3/mean_loss", mean_loss, rnd)

        if rnd % 10 == 0 or rnd == n_rounds - 1:
            print(f"  Round {rnd:3d}/{n_rounds} | loss={mean_loss:.4f} | {elapsed:.1f}s")
            save_checkpoint(
                out_dir / f"student_round_{rnd:03d}.pt",
                global_model,
                round_or_epoch = rnd,
                metrics        = row,
            )

    # Quantize to INT8 for edge deployment
    int8_model = quantize_model(global_model, inplace=False)
    torch.save(int8_model, out_dir / "student_int8.pt")
    print(f"[Phase 3] INT8 student saved to {out_dir / 'student_int8.pt'}")

    # Save final FP32 student
    save_checkpoint(out_dir / "student_fp32_final.pt", global_model,
                    round_or_epoch=n_rounds - 1)

    tb.close()
    print("[Phase 3] Complete.")
    return global_model


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="BioTwin-AgentNet training")
    parser.add_argument("--phase",      type=str, default="all",
                        choices=["1", "2", "3", "all"],
                        help="Training phase to run")
    parser.add_argument("--config",     type=str, default="configs/main.yaml")
    parser.add_argument("--output_dir", type=str, default="checkpoints")
    parser.add_argument("--device",     type=str, default="cpu")
    parser.add_argument("--use_dp",     action="store_true", default=False,
                        help="Enable differential privacy (requires Opacus)")
    parser.add_argument("--no_resume",  action="store_true", default=False,
                        help="Start training from scratch")
    parser.add_argument("--seed",       type=int, default=42)
    parser.add_argument("--verbose",    action="store_true", default=False)
    return parser.parse_args()


def main():
    args = parse_args()
    set_global_seed(args.seed)

    cfg = load_config(args.config)
    # Allow CLI seed to override config
    cfg["experiment"]["seed"] = args.seed

    teacher = student = None

    if args.phase in ("1", "all"):
        teacher = phase1_teacher_fl(cfg, args)

    if args.phase in ("2", "all"):
        student = phase2_distillation(cfg, args, teacher=teacher)

    if args.phase in ("3", "all"):
        phase3_student_fl(cfg, args, student=student)

    print("\nTraining complete.")
    print(f"Checkpoints saved to: {args.output_dir}/")


if __name__ == "__main__":
    main()
