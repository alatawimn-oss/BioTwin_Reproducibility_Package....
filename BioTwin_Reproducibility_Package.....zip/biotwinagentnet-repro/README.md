# BioTwin-AgentNet: Reproducibility Package

**Privacy-Preserving Multi-Agent Medical Digital Twin for Edge-Fog-Cloud Predictive Health Analytics**

Fawwad Hassan Jaskani — Department of Computer Systems Engineering, Islamia University of Bahawalpur

---

## Overview

This repository contains the full reproducibility package for BioTwin-AgentNet. Every experimental result — datasets, preprocessing, all models, training, evaluation, ablation studies, and figures — can be reproduced from this code.

The system achieves:

- Arrhythmia AUROC 0.943, Sepsis AUROC 0.876 (6.2 h early warning), Mortality AUROC 0.901
- Differential privacy: ε = 138.3 at 200 FL rounds (σ = 1.12, C = 1.0, δ = 1e-5)
- Edge inference: 47 ms, 112 mJ, 0.45 MB on NVIDIA Jetson Nano (INT8 student)
- Watermark bit agreement 98.7% post-INT8 quantisation

---

## Repository Structure

```
biotwinagentnet-repro/
├── configs/                   YAML hyperparameters (main + baselines + ablations)
├── data/                      Download, extract, and preprocess scripts
│   ├── download.py
│   ├── extract.py
│   ├── preprocess.py
│   └── splits/                Patient ID split files (train/val/test)
├── src/
│   ├── datasets/              PyTorch Dataset classes (MIMIC-IV, PhysioNet, eICU)
│   ├── models/                All model architectures
│   ├── losses/                Knowledge distillation loss
│   ├── metrics/               AUROC, AUPRC, Wilson CI
│   ├── utils/                 Seeding, logging, checkpointing
│   ├── privacy/               DP accounting, homomorphic encryption
│   ├── continual/             EWC + experience replay
│   ├── meta/                  MAML, neural process
│   ├── distillation/          KD training loop
│   ├── watermark/             Differentiable L2 watermarking
│   └── blockchain/            Hyperledger Fabric client
├── train.py                   Three-phase FL training orchestration
├── test.py                    Evaluation, privacy attacks, watermark verification
├── evaluate_all.py            Full table generation (main + baselines + ablations)
├── compare_results.py         PASS/FAIL comparison against paper tables
├── figures/make_figures.py    All IEEE paper figures (matplotlib, 800 dpi)
├── scripts/
│   ├── run_all.sh             Master 8-step pipeline
│   ├── run_main.sh            Main model only
│   ├── run_baselines.sh       Four baselines
│   └── run_ablation.sh        Seven ablation variants
├── tests/
│   ├── test_data_pipeline.py
│   ├── test_model_forward.py
│   └── test_metrics.py
├── checkpoints/
│   └── download_checkpoints.py
├── results/
│   └── expected/paper_results.csv
├── requirements.txt
├── environment.yml
└── Dockerfile
```

---

## Requirements

**Python 3.10+, CUDA 11.8+ (optional)**

Install with conda (recommended):

```bash
conda env create -f environment.yml
conda activate biotwin
```

Or with pip:

```bash
pip install -r requirements.txt --break-system-packages
```

Key dependencies: PyTorch 2.1, Opacus 1.4, TenSEAL 0.3.14, `learn2learn` (MAML), `avalanche-lib` (continual learning).

---

## Datasets

This paper uses three clinical datasets. Access requires credentialed PhysioNet registration.

**MIMIC-IV** (primary training and evaluation)
- Source: https://physionet.org/content/mimiciv/2.2/
- DOI: 10.13026/6mm1-ek67
- After credentialed download, place the CSV files under `data/raw/mimic4/`.

**PhysioNet Challenge 2019** (sepsis labels)
- Source: https://physionet.org/content/challenge-2019/1.0.0/
- DOI: 10.13026/v0kw-7n94
- Place under `data/raw/physionet2019/`.

**eICU Collaborative Research Database** (knowledge distillation only)
- Source: https://physionet.org/content/eicu-crd/2.0/
- DOI: 10.13026/C2WM1R
- Place under `data/raw/eicu/`.

Preprocessing (z-score normalisation, 1-hour resampling, 48-step sequences, 80/10/10 split, seed 42):

```bash
python data/download.py        # generates download instructions
python data/extract.py         # decompresses archives
python data/preprocess.py      # outputs HDF5 files and split ID lists
```

---

## Reproducing All Results

### Full pipeline

```bash
export WATERMARK_SECRET_SEED="your_secret_seed_here"
bash scripts/run_all.sh --device cuda --seed 42
```

This runs all eight pipeline steps: preprocessing, Phase 1 (teacher FL), Phase 2 (KD), Phase 3 (student FL), baseline training, ablation training, evaluation, and figure generation. Final comparison against paper tables is printed to stdout with PASS/FAIL per metric.

### Main model only

```bash
export WATERMARK_SECRET_SEED="your_secret_seed_here"
bash scripts/run_main.sh --device cuda --phase all
```

### Baselines only

```bash
bash scripts/run_baselines.sh --device cuda
```

### Ablations only

```bash
export WATERMARK_SECRET_SEED="your_secret_seed_here"
bash scripts/run_ablation.sh --device cuda
```

### Individual training phases

```bash
export WATERMARK_SECRET_SEED="your_secret_seed_here"

# Phase 1: teacher federated learning (200 rounds, DP, HE)
python train.py --phase 1 --config configs/main.yaml --device cuda --use_dp

# Phase 2: knowledge distillation on eICU
python train.py --phase 2 --config configs/main.yaml --device cuda

# Phase 3: student federated learning
python train.py --phase 3 --config configs/main.yaml --device cuda
```

---

## Evaluation

```bash
# Full evaluation: main model + baselines + ablations
python evaluate_all.py --config configs/main.yaml --device cuda

# Single-model evaluation with privacy attacks and watermark verification
python test.py \
    --model teacher \
    --checkpoint checkpoints/phase1/teacher_final.pt \
    --config configs/main.yaml \
    --device cuda \
    --run_privacy_eval
```

Compare against paper tables (exit code 0 = all pass, 1 = failures, 2 = missing results):

```bash
python compare_results.py --results_dir results/reproduced
```

---

## Figures

Regenerate all paper figures from evaluation CSVs:

```bash
python figures/make_figures.py --results_dir results/reproduced --out_dir figures/output
```

Individual figures can be generated with `--fig fig2`, `--fig fig3`, etc.

---

## Running Tests

```bash
# All tests (requires h5py)
pytest tests/ -v

# Skip tests that need real data
pytest tests/ -v -k "not hdf5"

# Individual test suites
pytest tests/test_data_pipeline.py -v
pytest tests/test_model_forward.py -v
pytest tests/test_metrics.py -v
```

---

## Checkpoint Management

Pretrained weights are not publicly redistributable due to MIMIC-IV data licensing. Train from scratch with the pipeline above, or generate synthetic stubs for CI testing:

```bash
# Verify locally trained checkpoints
python checkpoints/download_checkpoints.py --verify

# Generate random-weight stubs for smoke testing (not paper weights)
python checkpoints/download_checkpoints.py --generate_stubs
```

---

## Key Hyperparameters

All hyperparameters are in `configs/main.yaml`. Key values:

| Parameter | Value |
|---|---|
| FL rounds | 200 |
| Clients | 100 |
| Local epochs | 5 |
| Batch size | 32 |
| Teacher hidden | 512, 3 layers, bidir |
| Student hidden | 128, 2 layers |
| DP σ | 1.12 |
| DP C | 1.0 |
| DP δ | 1e-5 |
| KD temperature T | 4 |
| KD α | 0.3 |
| EWC λ | 5000 |
| Replay buffer | 2000 / task |
| Watermark d | 45000 (10% of weights) |
| Watermark τ | 0.1 |
| Watermark θ | 0.80 |
| Seq length | 48 (1-hr steps) |
| Features | 127 (MIMIC-IV) |
| Seed | 42 |

---

## Privacy Notes

- The `WATERMARK_SECRET_SEED` environment variable must be set before running any training or watermark verification. It is never hardcoded.
- Differential privacy uses Opacus v1.4 with RDP accounting. The reported ε = 138.3 is computed at δ = 1e-5 over 200 rounds.
- Homomorphic encryption uses TenSEAL v0.3.14 with threshold CKKS and Shamir secret sharing (t = 3, K = 5).

---

## Citation

If you use this code, please cite the paper (DOI to be added upon publication).

---

## License

MIT License. See LICENSE for details.

This software is provided for research reproducibility. The clinical datasets (MIMIC-IV, PhysioNet Challenge 2019, eICU) are subject to their own credentialed-access agreements and are not included in this repository.
