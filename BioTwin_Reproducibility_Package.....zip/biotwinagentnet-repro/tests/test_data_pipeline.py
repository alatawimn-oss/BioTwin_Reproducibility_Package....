"""
tests/test_data_pipeline.py

Pytest unit tests for the data loading and preprocessing pipeline.

Tests are designed to run without the real MIMIC-IV / PhysioNet / eICU HDF5
files. They use small synthetic tensors to verify pipeline correctness —
shapes, dtypes, normalisation, split disjointness, determinism.

Run:
    pytest tests/test_data_pipeline.py -v
    pytest tests/test_data_pipeline.py -v --tb=short
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest
import torch

# Allow imports from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def synthetic_hdf5(tmp_path_factory):
    """
    Create a minimal synthetic HDF5 file mimicking MIMIC-IV preprocessing output.
    Shape: (200, 48, 127) features + (200,) labels.
    """
    h5py = pytest.importorskip("h5py")
    rng  = np.random.default_rng(42)
    n, t, f = 200, 48, 127

    tmp_dir = tmp_path_factory.mktemp("data")
    path    = str(tmp_dir / "mimic4_synthetic.h5")

    with h5py.File(path, "w") as hf:
        hf.create_dataset("features", data=rng.standard_normal((n, t, f)).astype(np.float32))
        hf.create_dataset("labels",   data=rng.integers(0, 2, size=(n,)).astype(np.int64))
        ids = np.array([f"p{i:06d}" for i in range(n)], dtype="S8")
        hf.create_dataset("patient_ids", data=ids)

    return path, (n, t, f)


@pytest.fixture(scope="module")
def split_id_files(tmp_path_factory, synthetic_hdf5):
    """Write three split ID files (train 60%, val 20%, test 20%)."""
    path, (n, t, f) = synthetic_hdf5
    ids = [f"p{i:06d}" for i in range(n)]
    rng = np.random.default_rng(42)
    perm = rng.permutation(n)
    n_train, n_val = int(0.6 * n), int(0.2 * n)

    split_dir = tmp_path_factory.mktemp("splits")
    for split_name, indices in [
        ("train", perm[:n_train]),
        ("val",   perm[n_train:n_train + n_val]),
        ("test",  perm[n_train + n_val:]),
    ]:
        p = split_dir / f"mimic4_{split_name}_ids.txt"
        p.write_text("\n".join(ids[i] for i in indices) + "\n")

    return str(split_dir)


# ---------------------------------------------------------------------------
# Tests: MIMIC-IV dataset
# ---------------------------------------------------------------------------

class TestMIMIC4Dataset:

    def test_import(self):
        from src.datasets.mimic4_dataset import MIMIC4Dataset
        assert MIMIC4Dataset is not None

    def test_load_split_ids(self, split_id_files):
        from src.datasets.mimic4_dataset import load_split_ids
        ids = load_split_ids(split_id_files, "train")
        assert len(ids) > 0
        assert all(isinstance(x, str) for x in ids)

    def test_dataset_len(self, synthetic_hdf5, split_id_files):
        h5py = pytest.importorskip("h5py")
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)
        assert len(ds) == len(ids)

    def test_item_shape(self, synthetic_hdf5, split_id_files):
        h5py = pytest.importorskip("h5py")
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)
        x, y = ds[0]
        assert x.shape == (t, f), f"Expected ({t}, {f}), got {x.shape}"
        assert x.dtype == torch.float32
        assert y.dtype == torch.long

    def test_label_binary(self, synthetic_hdf5, split_id_files):
        h5py = pytest.importorskip("h5py")
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)
        for _, y in ds:
            assert y.item() in {0, 1}

    def test_splits_disjoint(self, split_id_files):
        from src.datasets.mimic4_dataset import load_split_ids
        train = set(load_split_ids(split_id_files, "train"))
        val   = set(load_split_ids(split_id_files, "val"))
        test  = set(load_split_ids(split_id_files, "test"))
        assert len(train & val)  == 0, "Train/val overlap"
        assert len(train & test) == 0, "Train/test overlap"
        assert len(val & test)   == 0, "Val/test overlap"

    def test_splits_cover_all(self, synthetic_hdf5, split_id_files):
        from src.datasets.mimic4_dataset import load_split_ids
        path, (n, t, f) = synthetic_hdf5
        all_ids = {f"p{i:06d}" for i in range(n)}
        union   = (set(load_split_ids(split_id_files, "train")) |
                   set(load_split_ids(split_id_files, "val"))   |
                   set(load_split_ids(split_id_files, "test")))
        assert union == all_ids, "Splits do not cover all patients"

    def test_dataloader_batch(self, synthetic_hdf5, split_id_files):
        h5py = pytest.importorskip("h5py")
        from torch.utils.data import DataLoader
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids    = load_split_ids(split_id_files, "train")
        ds     = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)
        loader = DataLoader(ds, batch_size=8, shuffle=False)
        x, y   = next(iter(loader))
        assert x.shape == (8, t, f)
        assert y.shape == (8,)

    def test_deterministic_order(self, synthetic_hdf5, split_id_files):
        """Same seed → same first batch every time."""
        h5py = pytest.importorskip("h5py")
        from torch.utils.data import DataLoader
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        from src.utils.seeding import set_global_seed
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)

        def first_labels(seed):
            set_global_seed(seed)
            g = torch.Generator(); g.manual_seed(seed)
            loader = DataLoader(ds, batch_size=16, shuffle=True, generator=g)
            _, y   = next(iter(loader))
            return y.tolist()

        assert first_labels(42) == first_labels(42)
        assert first_labels(42) != first_labels(99)


# ---------------------------------------------------------------------------
# Tests: Normalisation / preprocessing
# ---------------------------------------------------------------------------

class TestNormalisation:

    def test_no_nan_after_fillna(self, synthetic_hdf5, split_id_files):
        """Dataset items must not contain NaN after preprocessing."""
        h5py = pytest.importorskip("h5py")
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)
        for i in range(min(10, len(ds))):
            x, _ = ds[i]
            assert not torch.isnan(x).any(), f"NaN found in sample {i}"
            assert not torch.isinf(x).any(), f"Inf found in sample {i}"

    def test_feature_count(self, synthetic_hdf5, split_id_files):
        """Each item must have exactly n_features=127 features (paper spec)."""
        h5py = pytest.importorskip("h5py")
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=t, n_features=f)
        x, _ = ds[0]
        assert x.shape[-1] == 127

    def test_seq_len(self, synthetic_hdf5, split_id_files):
        """Sequence length must be exactly 48 (paper spec: 1-hour resampling * 48h)."""
        h5py = pytest.importorskip("h5py")
        from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
        path, (n, t, f) = synthetic_hdf5
        ids = load_split_ids(split_id_files, "train")
        ds  = MIMIC4Dataset(hdf5_path=path, patient_ids=ids, seq_len=48, n_features=f)
        x, _ = ds[0]
        assert x.shape[0] == 48


# ---------------------------------------------------------------------------
# Tests: Seeding utility
# ---------------------------------------------------------------------------

class TestSeeding:

    def test_set_global_seed_reproducible(self):
        from src.utils.seeding import set_global_seed
        set_global_seed(42)
        a = torch.randn(5)
        set_global_seed(42)
        b = torch.randn(5)
        assert torch.allclose(a, b)

    def test_different_seeds_differ(self):
        from src.utils.seeding import set_global_seed
        set_global_seed(42)
        a = torch.randn(5)
        set_global_seed(99)
        b = torch.randn(5)
        assert not torch.allclose(a, b)

    def test_numpy_determinism(self):
        from src.utils.seeding import set_global_seed
        set_global_seed(42)
        a = np.random.randn(5)
        set_global_seed(42)
        b = np.random.randn(5)
        np.testing.assert_array_equal(a, b)
