"""
tests/test_metrics.py

Pytest unit tests for metrics, loss functions, and privacy accounting.

Covers:
  EvaluationSuite — AUROC, AUPRC, Wilson CI, early-warning hours
  DistillationLoss — KL + CE combination, temperature scaling
  DPAccountant    — RDP to (eps, delta) conversion, sigma/C paper targets
  WatermarkModule — bit agreement, threshold, CSPRNG pattern

Run:
    pytest tests/test_metrics.py -v
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pytest
import torch
import torch.nn as nn

sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# EvaluationSuite
# ---------------------------------------------------------------------------

class TestEvaluationSuite:

    def _make_scores(self, n: int = 500, auroc_target: float = 0.85, seed: int = 42):
        """Generate (y_true, y_score) with approximately the target AUROC."""
        rng = np.random.default_rng(seed)
        a   = 1 + 6 * (auroc_target - 0.5)
        pos = rng.beta(a, 1, n // 2)
        neg = rng.beta(1, a, n // 2)
        y_score = np.concatenate([pos, neg])
        y_true  = np.concatenate([np.ones(n // 2), np.zeros(n // 2)])
        return y_true, y_score

    def test_import(self):
        from src.metrics.evaluation import EvaluationSuite
        assert EvaluationSuite is not None

    def test_auroc_range(self):
        from src.metrics.evaluation import EvaluationSuite
        y_true, y_score = self._make_scores(auroc_target=0.90)
        suite   = EvaluationSuite()
        metrics = suite.compute(y_true, y_score)
        assert "auroc" in metrics
        assert 0.80 <= metrics["auroc"] <= 1.00

    def test_auprc_range(self):
        from src.metrics.evaluation import EvaluationSuite
        y_true, y_score = self._make_scores()
        suite   = EvaluationSuite()
        metrics = suite.compute(y_true, y_score)
        assert "auprc" in metrics
        assert 0.0 <= metrics["auprc"] <= 1.0

    def test_auroc_perfect(self):
        """Perfect classifier → AUROC ≈ 1.0."""
        from src.metrics.evaluation import EvaluationSuite
        n       = 200
        y_true  = np.concatenate([np.ones(n), np.zeros(n)])
        y_score = np.concatenate([np.ones(n), np.zeros(n)])
        suite   = EvaluationSuite()
        metrics = suite.compute(y_true, y_score)
        assert metrics["auroc"] > 0.99

    def test_auroc_random(self):
        """Random classifier → AUROC ≈ 0.5 ± 0.1."""
        from src.metrics.evaluation import EvaluationSuite
        rng     = np.random.default_rng(42)
        n       = 2000
        y_true  = rng.integers(0, 2, n)
        y_score = rng.uniform(0, 1, n)
        suite   = EvaluationSuite()
        metrics = suite.compute(y_true, y_score)
        assert 0.40 <= metrics["auroc"] <= 0.60, (
            f"Random classifier AUROC should be ~0.5, got {metrics['auroc']:.3f}"
        )

    def test_wilson_ci_width(self):
        """95% Wilson CI should be narrower with more samples."""
        from src.metrics.evaluation import EvaluationSuite
        y_true, y_score = self._make_scores(n=200)
        suite = EvaluationSuite()
        m200  = suite.compute(y_true, y_score)
        y_true, y_score = self._make_scores(n=2000)
        m2000 = suite.compute(y_true, y_score)
        w200  = m200.get("auroc_ci_hi",  1.0) - m200.get("auroc_ci_lo",  0.0)
        w2000 = m2000.get("auroc_ci_hi", 1.0) - m2000.get("auroc_ci_lo", 0.0)
        assert w2000 < w200, "Larger sample should give narrower CI"

    def test_paper_targets_achievable(self):
        """
        Paper AUROC targets — arrhythmia 0.943, sepsis 0.876, mortality 0.901 —
        must be achievable by this metric implementation (not a correctness check
        of the model, only of the metric).
        """
        from src.metrics.evaluation import EvaluationSuite
        suite = EvaluationSuite()
        for target in [0.943, 0.876, 0.901]:
            y_true, y_score = self._make_scores(n=5000, auroc_target=target)
            m = suite.compute(y_true, y_score)
            assert abs(m["auroc"] - target) < 0.05, (
                f"Metric diverged too much from target {target}: got {m['auroc']:.3f}"
            )


# ---------------------------------------------------------------------------
# DistillationLoss
# ---------------------------------------------------------------------------

class TestDistillationLoss:

    def test_import(self):
        from src.losses.distillation_loss import DistillationLoss
        assert DistillationLoss is not None

    def test_output_is_scalar(self):
        from src.losses.distillation_loss import DistillationLoss
        criterion = DistillationLoss(temperature=4.0, alpha=0.3)
        logits_s  = torch.randn(8, 2)
        logits_t  = torch.randn(8, 2)
        targets   = torch.randint(0, 2, (8,))
        loss = criterion(logits_s, logits_t, targets)
        assert loss.dim() == 0, "Loss must be a scalar"

    def test_loss_non_negative(self):
        from src.losses.distillation_loss import DistillationLoss
        criterion = DistillationLoss(temperature=4.0, alpha=0.3)
        logits_s  = torch.randn(8, 2)
        logits_t  = torch.randn(8, 2)
        targets   = torch.randint(0, 2, (8,))
        loss = criterion(logits_s, logits_t, targets)
        assert loss.item() >= 0.0

    def test_alpha_0_equals_ce(self):
        """alpha=0 → pure CE loss (no KL term)."""
        from src.losses.distillation_loss import DistillationLoss
        criterion_kd = DistillationLoss(temperature=4.0, alpha=0.0)
        criterion_ce = nn.CrossEntropyLoss()
        logits_s  = torch.randn(8, 2)
        logits_t  = torch.randn(8, 2)
        targets   = torch.randint(0, 2, (8,))
        loss_kd = criterion_kd(logits_s, logits_t, targets)
        loss_ce = criterion_ce(logits_s, targets)
        assert abs(loss_kd.item() - loss_ce.item()) < 1e-5

    def test_alpha_1_no_ce(self):
        """alpha=1 → pure KL divergence loss."""
        from src.losses.distillation_loss import DistillationLoss
        criterion = DistillationLoss(temperature=4.0, alpha=1.0)
        # Same logits → KL = 0
        logits = torch.ones(8, 2)
        targets = torch.zeros(8, dtype=torch.long)
        loss = criterion(logits, logits, targets)
        assert loss.item() < 1e-5

    def test_temperature_effect(self):
        """Higher temperature → softer distributions → lower KL."""
        from src.losses.distillation_loss import DistillationLoss
        rng      = torch.Generator(); rng.manual_seed(42)
        logits_s = torch.randn(32, 2, generator=rng)
        logits_t = torch.randn(32, 2, generator=rng)
        targets  = torch.randint(0, 2, (32,))
        loss_t4  = DistillationLoss(temperature=4.0,  alpha=0.9)(logits_s, logits_t, targets)
        loss_t1  = DistillationLoss(temperature=1.0,  alpha=0.9)(logits_s, logits_t, targets)
        # T=4 → softer → smaller KL divergence
        assert loss_t4.item() <= loss_t1.item() + 0.5

    def test_backward(self):
        """Loss must be differentiable w.r.t. student logits."""
        from src.losses.distillation_loss import DistillationLoss
        criterion = DistillationLoss(temperature=4.0, alpha=0.3)
        logits_s  = torch.randn(8, 2, requires_grad=True)
        logits_t  = torch.randn(8, 2)
        targets   = torch.randint(0, 2, (8,))
        loss = criterion(logits_s, logits_t, targets)
        loss.backward()
        assert logits_s.grad is not None
        assert not torch.isnan(logits_s.grad).any()


# ---------------------------------------------------------------------------
# DP Accounting
# ---------------------------------------------------------------------------

class TestDPAccounting:

    def test_import(self):
        from src.privacy.dp_accounting import DPAccountant
        assert DPAccountant is not None

    def test_epsilon_increases_with_rounds(self):
        """More FL rounds → larger ε (more privacy budget spent)."""
        from src.privacy.dp_accounting import DPAccountant
        acc = DPAccountant(sigma=1.12, C=1.0, delta=1e-5, q=1.0)
        eps_100 = acc.get_epsilon(steps=100)
        eps_200 = acc.get_epsilon(steps=200)
        assert eps_200 > eps_100

    def test_paper_epsilon_200_rounds(self):
        """
        Paper claims ε=138.3 at 200 rounds (sigma=1.12, C=1.0, delta=1e-5, q=1.0).
        Allow ±20 tolerance — exact value depends on RDP accounting library version.
        """
        from src.privacy.dp_accounting import DPAccountant
        acc = DPAccountant(sigma=1.12, C=1.0, delta=1e-5, q=1.0)
        eps = acc.get_epsilon(steps=200)
        assert 100.0 <= eps <= 180.0, (
            f"ε at 200 rounds: expected ~138.3, got {eps:.2f}"
        )

    def test_paper_epsilon_142_rounds(self):
        """Paper also reports ε=105.9 at 142 rounds."""
        from src.privacy.dp_accounting import DPAccountant
        acc = DPAccountant(sigma=1.12, C=1.0, delta=1e-5, q=1.0)
        eps = acc.get_epsilon(steps=142)
        assert 80.0 <= eps <= 140.0, (
            f"ε at 142 rounds: expected ~105.9, got {eps:.2f}"
        )

    def test_larger_sigma_smaller_epsilon(self):
        """Higher noise → lower ε (better privacy)."""
        from src.privacy.dp_accounting import DPAccountant
        eps_lo = DPAccountant(sigma=1.12, C=1.0, delta=1e-5, q=1.0).get_epsilon(100)
        eps_hi = DPAccountant(sigma=2.00, C=1.0, delta=1e-5, q=1.0).get_epsilon(100)
        assert eps_hi < eps_lo


# ---------------------------------------------------------------------------
# Watermark
# ---------------------------------------------------------------------------

class TestWatermark:

    @pytest.fixture(autouse=True)
    def set_seed_env(self, monkeypatch):
        monkeypatch.setenv("WATERMARK_SECRET_SEED", "test_secret_42")

    def test_import(self):
        from src.watermark.watermark import WatermarkModule
        assert WatermarkModule is not None

    def test_bit_agreement_with_self(self):
        """Verifying a watermarked model against its own pattern → 100% agreement."""
        from src.watermark.watermark import WatermarkModule
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(
            n_features=127, hidden_size=64, num_layers=1,
            n_classes=2, dropout=0.0, bidirectional=False,
        )
        wm    = WatermarkModule(model=model, d=1000, lambda_w=0.01, tau=0.1)
        result = wm.verify(model)
        assert result["bit_agreement"] > 0.95

    def test_bit_agreement_different_model(self):
        """A different (unrelated) model should have low bit agreement."""
        from src.watermark.watermark import WatermarkModule
        from src.models.teacher import TeacherLSTM
        model1 = TeacherLSTM(
            n_features=127, hidden_size=64, num_layers=1,
            n_classes=2, dropout=0.0, bidirectional=False,
        )
        model2 = TeacherLSTM(
            n_features=127, hidden_size=64, num_layers=1,
            n_classes=2, dropout=0.0, bidirectional=False,
        )
        # Randomise model2 weights
        for p in model2.parameters():
            nn.init.normal_(p)

        wm     = WatermarkModule(model=model1, d=1000, lambda_w=0.01, tau=0.1)
        result = wm.verify(model2)
        # Random model → bit agreement near 0.5; well below threshold
        assert result["bit_agreement"] < 0.80

    def test_threshold(self):
        """Verify accept/reject against paper threshold theta=0.80."""
        from src.watermark.watermark import WatermarkModule
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(
            n_features=127, hidden_size=64, num_layers=1,
            n_classes=2, dropout=0.0, bidirectional=False,
        )
        wm = WatermarkModule(model=model, d=1000, lambda_w=0.01, tau=0.1, theta=0.80)
        result = wm.verify(model)
        assert result["verified"] is True

    def test_watermark_loss_term(self):
        """WatermarkModule must return a differentiable scalar loss term."""
        from src.watermark.watermark import WatermarkModule
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(
            n_features=127, hidden_size=64, num_layers=1,
            n_classes=2, dropout=0.0, bidirectional=False,
        )
        wm   = WatermarkModule(model=model, d=500, lambda_w=0.01, tau=0.1)
        loss = wm.loss()
        assert loss.dim() == 0
        assert loss.item() >= 0.0
        loss.backward()
