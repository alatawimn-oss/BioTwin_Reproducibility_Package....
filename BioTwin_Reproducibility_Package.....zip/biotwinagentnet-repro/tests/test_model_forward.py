"""
tests/test_model_forward.py

Pytest unit tests for model forward passes.

Checks output shapes, dtypes, parameter counts, and INT8 quantisation
for all models used in the paper:
  TeacherLSTM, StudentLSTM, BioTwinAgent,
  CentralizedCNN, FedHealthModel, FedProxModel

Run:
    pytest tests/test_model_forward.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch
import torch.nn as nn

sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Constants matching paper architecture specs
# ---------------------------------------------------------------------------

SEQ_LEN    = 48
N_FEATURES = 127
N_CLASSES  = 2
BATCH      = 4

# Teacher: 4.2M params, hidden=512, 3 layers, bidir
TEACHER_CFG = dict(
    n_features    = N_FEATURES,
    hidden_size   = 512,
    num_layers    = 3,
    n_classes     = N_CLASSES,
    dropout       = 0.3,
    bidirectional = True,
)

# Student: 450K params, hidden=128, 2 layers
STUDENT_CFG = dict(
    n_features  = N_FEATURES,
    hidden_size = 128,
    num_layers  = 2,
    n_classes   = N_CLASSES,
    dropout     = 0.1,
)


def _dummy_batch():
    return torch.randn(BATCH, SEQ_LEN, N_FEATURES)


# ---------------------------------------------------------------------------
# TeacherLSTM
# ---------------------------------------------------------------------------

class TestTeacherLSTM:

    def test_import(self):
        from src.models.teacher import TeacherLSTM
        assert TeacherLSTM is not None

    def test_output_shape(self):
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert out.shape == (BATCH, N_CLASSES), f"Got {out.shape}"

    def test_output_dtype(self):
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert out.dtype == torch.float32

    def test_param_count_approx(self):
        """Paper states 4.2M parameters ± 20%."""
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        n = sum(p.numel() for p in model.parameters())
        assert 3_360_000 <= n <= 5_040_000, (
            f"Expected ~4.2M params, got {n:,}"
        )

    def test_no_nan_output(self):
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert not torch.isnan(out).any()
        assert not torch.isinf(out).any()

    def test_gradient_flows(self):
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        model.train()
        x    = _dummy_batch()
        y    = torch.randint(0, N_CLASSES, (BATCH,))
        out  = model(x)
        loss = nn.CrossEntropyLoss()(out, y)
        loss.backward()
        for name, p in model.named_parameters():
            if p.requires_grad:
                assert p.grad is not None, f"No gradient for {name}"

    def test_batch_size_1(self):
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        model.eval()
        with torch.no_grad():
            out = model(torch.randn(1, SEQ_LEN, N_FEATURES))
        assert out.shape == (1, N_CLASSES)

    def test_eval_inference_no_grad(self):
        """Inference in eval mode must not raise errors."""
        from src.models.teacher import TeacherLSTM
        model = TeacherLSTM(**TEACHER_CFG)
        model.eval()
        with torch.no_grad():
            for _ in range(5):
                model(_dummy_batch())


# ---------------------------------------------------------------------------
# StudentLSTM
# ---------------------------------------------------------------------------

class TestStudentLSTM:

    def test_import(self):
        from src.models.student import StudentLSTM
        assert StudentLSTM is not None

    def test_output_shape(self):
        from src.models.student import StudentLSTM
        model = StudentLSTM(**STUDENT_CFG)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert out.shape == (BATCH, N_CLASSES)

    def test_param_count_approx(self):
        """Paper states 450K parameters ± 20%."""
        from src.models.student import StudentLSTM
        model = StudentLSTM(**STUDENT_CFG)
        n = sum(p.numel() for p in model.parameters())
        assert 360_000 <= n <= 540_000, (
            f"Expected ~450K params, got {n:,}"
        )

    def test_no_nan_output(self):
        from src.models.student import StudentLSTM
        model = StudentLSTM(**STUDENT_CFG)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert not torch.isnan(out).any()

    def test_gradient_flows(self):
        from src.models.student import StudentLSTM
        model = StudentLSTM(**STUDENT_CFG)
        model.train()
        x    = _dummy_batch()
        y    = torch.randint(0, N_CLASSES, (BATCH,))
        loss = nn.CrossEntropyLoss()(model(x), y)
        loss.backward()
        for name, p in model.named_parameters():
            if p.requires_grad:
                assert p.grad is not None, f"No gradient for {name}"


# ---------------------------------------------------------------------------
# INT8 quantisation
# ---------------------------------------------------------------------------

class TestINT8Quantisation:

    def test_dynamic_quantisation(self):
        from src.models.student import StudentLSTM
        from src.models.quantization import quantize_model_dynamic
        model = StudentLSTM(**STUDENT_CFG)
        model.eval()
        int8_model = quantize_model_dynamic(model)
        with torch.no_grad():
            out = int8_model(_dummy_batch())
        assert out.shape == (BATCH, N_CLASSES)

    def test_int8_smaller_than_fp32(self):
        """INT8 model must have fewer bytes than FP32 (edge deployment requirement)."""
        from src.models.student import StudentLSTM
        from src.models.quantization import quantize_model_dynamic
        import io
        model    = StudentLSTM(**STUDENT_CFG)
        int8_mdl = quantize_model_dynamic(model)

        def model_bytes(m):
            buf = io.BytesIO()
            torch.save(m.state_dict(), buf)
            return buf.tell()

        fp32_sz = model_bytes(model)
        int8_sz = model_bytes(int8_mdl)
        # INT8 is not always strictly smaller after serialisation headers,
        # but should be <= FP32
        assert int8_sz <= fp32_sz * 1.05, (
            f"INT8 ({int8_sz}) not smaller than FP32 ({fp32_sz})"
        )

    def test_int8_model_size_target(self):
        """
        Paper target: 0.45 MB for INT8 student.
        Allow 2× tolerance for environment differences.
        """
        from src.models.student import StudentLSTM
        from src.models.quantization import quantize_model_dynamic
        model    = StudentLSTM(**STUDENT_CFG)
        int8_mdl = quantize_model_dynamic(model)
        n_params = sum(p.numel() for p in model.parameters())
        # INT8 = 1 byte/param; FP32 = 4 bytes/param
        int8_mb = n_params * 1 / 1e6
        assert int8_mb <= 0.90, f"INT8 size {int8_mb:.3f} MB exceeds 2× paper target"


# ---------------------------------------------------------------------------
# CentralizedCNN baseline
# ---------------------------------------------------------------------------

class TestCentralizedCNN:

    def test_output_shape(self):
        from src.models.centralized_cnn import CentralizedCNN
        model = CentralizedCNN(n_features=N_FEATURES, seq_len=SEQ_LEN, n_classes=N_CLASSES)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert out.shape == (BATCH, N_CLASSES)

    def test_no_nan(self):
        from src.models.centralized_cnn import CentralizedCNN
        model = CentralizedCNN(n_features=N_FEATURES, seq_len=SEQ_LEN, n_classes=N_CLASSES)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert not torch.isnan(out).any()


# ---------------------------------------------------------------------------
# FedHealth and FedProx baselines
# ---------------------------------------------------------------------------

class TestFedHealthModel:

    def test_output_shape(self):
        from src.models.fedhealth import FedHealthModel
        model = FedHealthModel(n_features=N_FEATURES, seq_len=SEQ_LEN, n_classes=N_CLASSES)
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert out.shape == (BATCH, N_CLASSES)


class TestFedProxModel:

    def test_output_shape(self):
        from src.models.fedprox import FedProxModel
        model = FedProxModel(
            n_features=N_FEATURES, hidden_size=512, num_layers=3,
            n_classes=N_CLASSES, dropout=0.3, bidirectional=True, mu=0.01,
        )
        model.eval()
        with torch.no_grad():
            out = model(_dummy_batch())
        assert out.shape == (BATCH, N_CLASSES)

    def test_proximal_term_positive(self):
        """FedProx proximal term must be non-negative."""
        from src.models.fedprox import FedProxModel
        model  = FedProxModel(
            n_features=N_FEATURES, hidden_size=256, num_layers=2,
            n_classes=N_CLASSES, dropout=0.1, bidirectional=False, mu=0.01,
        )
        global_params = {n: p.clone() for n, p in model.named_parameters()}
        # Perturb local model
        with torch.no_grad():
            for p in model.parameters():
                p.add_(torch.randn_like(p) * 0.1)
        prox = model.proximal_term(global_params)
        assert prox.item() >= 0.0


# ---------------------------------------------------------------------------
# BioTwinAgent
# ---------------------------------------------------------------------------

class TestBioTwinAgent:

    def test_import(self):
        from src.models.biotwin_agent import BioTwinAgent
        assert BioTwinAgent is not None

    def test_forward_returns_dict_or_tensor(self):
        from src.models.biotwin_agent import BioTwinAgent
        agent = BioTwinAgent(
            n_features    = N_FEATURES,
            teacher_hidden = 512,
            student_hidden = 128,
            n_classes      = N_CLASSES,
        )
        agent.eval()
        x = _dummy_batch()
        with torch.no_grad():
            out = agent(x)
        # Accept either a tensor or a dict with 'logits' key
        if isinstance(out, dict):
            assert "logits" in out
            assert out["logits"].shape == (BATCH, N_CLASSES)
        else:
            assert out.shape == (BATCH, N_CLASSES)
