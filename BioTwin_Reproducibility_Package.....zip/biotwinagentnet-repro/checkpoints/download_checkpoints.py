#!/usr/bin/env python3
"""
checkpoints/download_checkpoints.py

Download and verify pretrained BioTwin-AgentNet checkpoints.

NOTE: The models in this paper require training on credentialed PhysioNet
datasets (MIMIC-IV, PhysioNet Challenge 2019) and cannot be redistributed
publicly. This script provides:

  1. A verification utility for locally trained checkpoints.
  2. Hooks for a future hosted release (URLs marked [UNVERIFIED] until
     the authors publish official weights).
  3. A synthetic-weight stub generator for CI/smoke testing without
     real data.

Usage:
    # Verify locally trained checkpoints
    python checkpoints/download_checkpoints.py --verify

    # Generate smoke-test stubs
    python checkpoints/download_checkpoints.py --generate_stubs

    # Download (requires official release URL — currently [UNVERIFIED])
    python checkpoints/download_checkpoints.py --download
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Checkpoint registry
# ---------------------------------------------------------------------------
# URLs are marked [UNVERIFIED] until official weights are publicly released.
# Replace with verified DOI-linked URLs when available.
# ---------------------------------------------------------------------------

CHECKPOINTS: dict[str, dict] = {
    "teacher_final": {
        "path":        "checkpoints/phase1/teacher_final.pt",
        "description": "Teacher BiLSTM (4.2M FP32) — Phase 1 FL, 200 rounds, DP sigma=1.12",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~65",
    },
    "student_final_fp32": {
        "path":        "checkpoints/phase3/student_final.pt",
        "description": "Student LSTM (450K FP32) — Phase 3 student FL after KD",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~7",
    },
    "student_final_int8": {
        "path":        "checkpoints/phase3/student_int8.pt",
        "description": "Student LSTM (450K INT8) — quantised; edge deployment (Jetson Nano)",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~1.8",
    },
    "baseline_centralized_cnn": {
        "path":        "checkpoints/baselines/centralized_cnn_final.pt",
        "description": "CentralizedCNN baseline",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~15",
    },
    "baseline_fedavg": {
        "path":        "checkpoints/baselines/fedavg_final.pt",
        "description": "FedAvg baseline (vanilla, no DP/HE/CL)",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~65",
    },
    "baseline_fedhealth": {
        "path":        "checkpoints/baselines/fedhealth_final.pt",
        "description": "FedHealth baseline (Chen et al. 2020)",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~65",
    },
    "baseline_fedprox": {
        "path":        "checkpoints/baselines/fedprox_final.pt",
        "description": "FedProx baseline (Li et al. 2020), mu=0.01",
        "url":         "[UNVERIFIED]",
        "sha256":      "[UNVERIFIED]",
        "size_mb":     "~65",
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def _size_mb(path: str | Path) -> float:
    return os.path.getsize(path) / 1e6


def _status_line(key: str, entry: dict, root: Path) -> str:
    p = root / entry["path"]
    if p.exists():
        mb  = _size_mb(p)
        sha = sha256_file(p)[:16]
        return f"  [FOUND]   {key:<35} {mb:6.1f} MB  sha256:{sha}..."
    else:
        return f"  [MISSING] {key:<35} expected at {entry['path']}"


# ---------------------------------------------------------------------------
# Verify
# ---------------------------------------------------------------------------

def cmd_verify(root: Path) -> None:
    print("=" * 70)
    print(" BioTwin-AgentNet — Checkpoint Verification")
    print("=" * 70)
    print(f" Root: {root}\n")
    n_found = n_missing = 0
    for key, entry in CHECKPOINTS.items():
        line = _status_line(key, entry, root)
        print(line)
        if "[FOUND]" in line:
            n_found += 1
            # If a known SHA is registered, verify it
            if entry["sha256"] not in {"[UNVERIFIED]", ""}:
                actual = sha256_file(root / entry["path"])
                if actual != entry["sha256"]:
                    print(f"  [ERROR]   sha256 mismatch for {key}")
                    print(f"            Expected: {entry['sha256']}")
                    print(f"            Actual:   {actual}")
                else:
                    print(f"  [OK]      sha256 verified for {key}")
        else:
            n_missing += 1

    print()
    print(f" Found: {n_found}  Missing: {n_missing}  Total: {len(CHECKPOINTS)}")
    if n_missing > 0:
        print()
        print(" To generate smoke-test stubs (synthetic weights, not paper weights):")
        print("   python checkpoints/download_checkpoints.py --generate_stubs")
        print()
        print(" To train from scratch (requires MIMIC-IV / PhysioNet credentials):")
        print("   bash scripts/run_all.sh")
    print("=" * 70)


# ---------------------------------------------------------------------------
# Generate synthetic stubs (for CI / smoke tests)
# ---------------------------------------------------------------------------

def cmd_generate_stubs(root: Path) -> None:
    """
    Create placeholder checkpoints with randomly initialised weights.
    These are ONLY for testing that the pipeline code runs end-to-end;
    they will NOT reproduce the paper's performance numbers.
    """
    from src.models.teacher import TeacherLSTM
    from src.models.student import StudentLSTM
    from src.models.centralized_cnn import CentralizedCNN
    from src.models.fedhealth import FedHealthModel
    from src.models.fedprox import FedProxModel
    from src.models.quantization import quantize_model_dynamic
    from src.utils.checkpointing import save_checkpoint
    from src.utils.seeding import set_global_seed

    set_global_seed(42)
    print("Generating synthetic stub checkpoints (random weights)...")
    print("WARNING: These are NOT the paper weights.")

    n_features, seq_len, n_classes = 127, 48, 2

    teacher = TeacherLSTM(
        n_features=n_features, hidden_size=512, num_layers=3,
        n_classes=n_classes, dropout=0.3, bidirectional=True,
    )
    student = StudentLSTM(
        n_features=n_features, hidden_size=128, num_layers=2,
        n_classes=n_classes, dropout=0.1,
    )
    student_int8 = quantize_model_dynamic(
        StudentLSTM(n_features=n_features, hidden_size=128, num_layers=2,
                    n_classes=n_classes, dropout=0.1)
    )
    cnn = CentralizedCNN(n_features=n_features, seq_len=seq_len, n_classes=n_classes)
    fh  = FedHealthModel(n_features=n_features, seq_len=seq_len, n_classes=n_classes)
    fp  = FedProxModel(
        n_features=n_features, hidden_size=512, num_layers=3,
        n_classes=n_classes, dropout=0.3, bidirectional=True, mu=0.01,
    )

    stubs = {
        "checkpoints/phase1/teacher_final.pt":          (teacher, "STUB_teacher_phase1"),
        "checkpoints/phase3/student_final.pt":           (student, "STUB_student_fp32"),
        "checkpoints/phase3/student_int8.pt":            (student_int8, "STUB_student_int8"),
        "checkpoints/baselines/centralized_cnn_final.pt":(cnn, "STUB_centralized_cnn"),
        "checkpoints/baselines/fedavg_final.pt":         (teacher, "STUB_fedavg"),
        "checkpoints/baselines/fedhealth_final.pt":      (fh, "STUB_fedhealth"),
        "checkpoints/baselines/fedprox_final.pt":        (fp, "STUB_fedprox"),
    }

    for rel_path, (model, tag) in stubs.items():
        out = root / rel_path
        out.parent.mkdir(parents=True, exist_ok=True)
        opt = torch.optim.Adam(
            [p for p in model.parameters() if p.requires_grad],
            lr=0.001,
        ) if any(p.requires_grad for p in model.parameters()) else None
        save_checkpoint(
            str(out), model, opt, epoch=0,
            extra={"stub": True, "tag": tag, "WARNING": "SYNTHETIC_WEIGHTS_NOT_PAPER"},
        )
        print(f"  Written: {rel_path}  ({_size_mb(out):.1f} MB)")

    print("\nAll stubs written.")
    print("Run `python checkpoints/download_checkpoints.py --verify` to confirm.")


# ---------------------------------------------------------------------------
# Download (requires future official release)
# ---------------------------------------------------------------------------

def cmd_download(root: Path) -> None:
    unverified = [k for k, v in CHECKPOINTS.items() if v["url"] == "[UNVERIFIED]"]
    if unverified:
        print("=" * 70)
        print(" NOTICE: Official pretrained weights have not been publicly released.")
        print(" The following checkpoint URLs are marked [UNVERIFIED]:")
        for k in unverified:
            print(f"   {k}")
        print()
        print(" Reason: MIMIC-IV and PhysioNet data are credentialed; models trained")
        print(" on them cannot be freely redistributed without author approval.")
        print()
        print(" Options:")
        print("   1. Train from scratch: bash scripts/run_all.sh")
        print("   2. Generate smoke stubs: python checkpoints/download_checkpoints.py --generate_stubs")
        print("   3. Contact the authors if official weights are released.")
        print("=" * 70)
        return

    # If URLs are verified in a future release, use this block:
    import urllib.request
    for key, entry in CHECKPOINTS.items():
        url = entry["url"]
        if url == "[UNVERIFIED]":
            continue
        out = root / entry["path"]
        out.parent.mkdir(parents=True, exist_ok=True)
        print(f"  Downloading {key} → {out}")
        urllib.request.urlretrieve(url, out)
        if entry["sha256"] not in {"[UNVERIFIED]", ""}:
            actual = sha256_file(out)
            if actual != entry["sha256"]:
                print(f"  [ERROR] sha256 mismatch for {key}")
                out.unlink()
                raise RuntimeError(f"Checksum failed for {key}")
            print(f"  [OK] sha256 verified")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="BioTwin-AgentNet checkpoint manager"
    )
    parser.add_argument("--verify",         action="store_true",
                        help="Verify existing checkpoints")
    parser.add_argument("--generate_stubs", action="store_true",
                        help="Generate synthetic stub checkpoints for CI/smoke tests")
    parser.add_argument("--download",       action="store_true",
                        help="Download official pretrained checkpoints (requires release)")
    parser.add_argument("--root", default=".",
                        help="Project root directory (default: .)")
    args = parser.parse_args()

    root = Path(args.root).resolve()

    if not any([args.verify, args.generate_stubs, args.download]):
        # Default: verify
        cmd_verify(root)
        return

    if args.download:
        cmd_download(root)
    if args.generate_stubs:
        cmd_generate_stubs(root)
    if args.verify:
        cmd_verify(root)


if __name__ == "__main__":
    main()
