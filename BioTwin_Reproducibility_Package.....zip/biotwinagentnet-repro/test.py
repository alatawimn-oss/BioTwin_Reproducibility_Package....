"""
test.py

BioTwin-AgentNet inference and evaluation on held-out test sets.

Loads trained checkpoints and evaluates:
  1. Teacher LSTM — arrhythmia, sepsis, mortality on MIMIC-IV test split
  2. Student LSTM (FP32 and INT8) — same tasks
  3. Privacy attacks — MI attack (Table 5) and attribute inference
  4. Watermark verification — bit agreement pre/post INT8

Paper targets (Table 3 / Table 5):
  arrhythmia AUROC  : 0.943
  sepsis AUROC      : 0.876  (6.2h early warning)
  mortality AUROC   : 0.901
  MI attack acc     : 52.3%  (95% Wilson CI 50.9–53.7%)
  attr inference    : 11.3% above random

Usage:
    python test.py --config configs/main.yaml
    python test.py --model teacher --task arrhythmia
    python test.py --model student_int8 --task all
    python test.py --eval privacy
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import yaml
from torch.utils.data import DataLoader

from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
from src.models.teacher import TeacherLSTM
from src.models.student import StudentLSTM
from src.metrics.evaluation import EvaluationSuite
from src.utils.seeding import set_global_seed
from src.utils.checkpointing import load_checkpoint
from src.watermark.watermark import ModelWatermark


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Model loading helpers
# ---------------------------------------------------------------------------

def load_teacher(cfg: dict, ckpt_path: str, device: torch.device) -> nn.Module:
    mc = cfg["model"]["teacher"]
    model = TeacherLSTM(
        n_features    = cfg["data"]["mimic4"]["n_features"],
        hidden_size   = mc["hidden_size"],
        num_layers    = mc["num_layers"],
        n_classes     = mc["n_classes"],
        dropout       = 0.0,            # eval mode
        bidirectional = mc["bidirectional"],
    )
    if ckpt_path and Path(ckpt_path).exists():
        load_checkpoint(ckpt_path, model, device=device)
        print(f"Loaded teacher from {ckpt_path}")
    else:
        print(f"[Warning] checkpoint not found: {ckpt_path}. Using random weights.")
    model.eval()
    return model.to(device)


def load_student(cfg: dict, ckpt_path: str, device: torch.device) -> nn.Module:
    mc = cfg["model"]["student"]
    model = StudentLSTM(
        n_features  = cfg["data"]["mimic4"]["n_features"],
        hidden_size = mc["hidden_size"],
        num_layers  = mc["num_layers"],
        n_classes   = mc["n_classes"],
        dropout     = 0.0,
    )
    if ckpt_path and Path(ckpt_path).exists():
        load_checkpoint(ckpt_path, model, device=device)
        print(f"Loaded student from {ckpt_path}")
    else:
        print(f"[Warning] checkpoint not found: {ckpt_path}. Using random weights.")
    model.eval()
    return model.to(device)


def load_int8_student(ckpt_path: str, device: torch.device) -> nn.Module:
    """Load INT8-quantized student saved as full model (torch.save)."""
    if not Path(ckpt_path).exists():
        print(f"[Warning] INT8 checkpoint not found: {ckpt_path}.")
        return None
    model = torch.load(ckpt_path, map_location=device)
    model.eval()
    print(f"Loaded INT8 student from {ckpt_path}")
    return model


# ---------------------------------------------------------------------------
# Test data loader
# ---------------------------------------------------------------------------

def build_test_loader(
    cfg: dict,
    task: str,
    batch_size: int = 64,
    seed: int = 42,
) -> DataLoader:
    """Build MIMIC-IV test DataLoader for a given task."""
    data_root = Path(cfg["data"]["mimic4"]["processed_dir"])
    test_ids  = load_split_ids("data/splits/mimic4_test_ids.txt")

    try:
        ds = MIMIC4Dataset(
            hdf5_path  = str(data_root / "test.h5"),
            split_ids  = test_ids,
            task       = task,
            client_id  = 0,
            n_clients  = 1,
            seed       = seed,
        )
        return DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=0)
    except FileNotFoundError:
        # Synthetic stub: 5000 samples matching paper test split size
        n_features = cfg["data"]["mimic4"]["n_features"]
        seq_len    = cfg["data"]["mimic4"]["seq_len"]
        rng = np.random.default_rng(seed)
        X   = torch.from_numpy(rng.standard_normal((5000, seq_len, n_features)).astype(np.float32))
        y   = torch.from_numpy(rng.integers(0, 2, size=(5000,)).astype(np.int64))
        print(f"[Stub] Using synthetic test data for task='{task}' (HDF5 not found).")
        return DataLoader(list(zip(X, y)), batch_size=batch_size, shuffle=False)


# ---------------------------------------------------------------------------
# Core evaluation loop
# ---------------------------------------------------------------------------

@torch.no_grad()
def run_evaluation(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    task: str = "arrhythmia",
) -> Dict:
    """
    Run inference and compute all metrics via EvaluationSuite.

    Returns dict with AUROC, AUPRC, Wilson CI, and timing.
    """
    model.eval()
    all_probs = []
    all_labels = []
    inference_times_ms = []

    for X, y in loader:
        X = X.to(device)
        y = y.to(device)

        t0 = time.perf_counter()
        logits = model(X)
        elapsed = (time.perf_counter() - t0) * 1000.0  # ms

        probs = torch.softmax(logits, dim=-1)[:, 1]  # positive class
        all_probs.append(probs.cpu().numpy())
        all_labels.append(y.cpu().numpy())
        inference_times_ms.append(elapsed / X.shape[0])  # per sample

    y_score = np.concatenate(all_probs)
    y_true  = np.concatenate(all_labels)

    suite   = EvaluationSuite()
    metrics = suite.compute(y_true, y_score, task=task)

    # Timing stats
    metrics["mean_inference_ms"] = float(np.mean(inference_times_ms))
    metrics["p95_inference_ms"]  = float(np.percentile(inference_times_ms, 95))
    metrics["n_samples"]         = len(y_true)

    return metrics


# ---------------------------------------------------------------------------
# Privacy evaluation: membership inference attack
# ---------------------------------------------------------------------------

def membership_inference_attack(
    model: nn.Module,
    train_loader: DataLoader,
    test_loader: DataLoader,
    device: torch.device,
    n_attack_samples: int = 1000,
    seed: int = 42,
) -> Dict:
    """
    Threshold-based membership inference attack.

    Paper (Table 5): MI attack accuracy = 52.3%,
    95% Wilson CI = [50.9%, 53.7%].

    Attack: use loss magnitude as membership signal.
    Train members have lower loss than non-members.
    Threshold set at the median loss over the combined set.

    Returns accuracy, Wilson CI, and AUC of the attack.
    """
    model.eval()
    loss_fn = nn.CrossEntropyLoss(reduction="none")
    rng     = np.random.default_rng(seed)

    def collect_losses(loader, label: int, max_n: int) -> Tuple[np.ndarray, np.ndarray]:
        losses  = []
        labels  = []
        count   = 0
        with torch.no_grad():
            for X, y in loader:
                if count >= max_n:
                    break
                X = X.to(device)
                y = y.to(device)
                logits = model(X)
                per_sample_loss = loss_fn(logits, y.long()).cpu().numpy()
                losses.append(per_sample_loss)
                labels.extend([label] * len(per_sample_loss))
                count += len(per_sample_loss)
        losses = np.concatenate(losses)[:max_n]
        labels = np.array(labels)[:max_n]
        return losses, labels

    half = n_attack_samples // 2
    member_losses,     member_labels     = collect_losses(train_loader, label=1, max_n=half)
    nonmember_losses,  nonmember_labels  = collect_losses(test_loader,  label=0, max_n=half)

    all_losses = np.concatenate([member_losses, nonmember_losses])
    all_labels = np.concatenate([member_labels, nonmember_labels])

    # Threshold: predict member if loss < median
    threshold    = np.median(all_losses)
    predictions  = (all_losses < threshold).astype(int)
    accuracy     = float(np.mean(predictions == all_labels))

    # Wilson score interval (paper reports 95%)
    n, p = len(all_labels), accuracy
    z    = 1.959964  # 97.5th percentile of standard normal (two-sided 95%)
    denom   = 1 + z**2 / n
    center  = (p + z**2 / (2 * n)) / denom
    half_w  = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / denom
    ci_lo   = max(0.0, center - half_w)
    ci_hi   = min(1.0, center + half_w)

    # Attack AUROC (treat lower loss = higher confidence of membership)
    from src.metrics.evaluation import EvaluationSuite
    suite = EvaluationSuite()
    # Flip sign: higher "score" should mean predicted member
    mi_score = -all_losses
    mi_metrics = suite.compute(all_labels, (mi_score - mi_score.min()) / (mi_score.ptp() + 1e-9))

    return {
        "mi_accuracy":          accuracy,
        "mi_accuracy_pct":      accuracy * 100,
        "wilson_ci_lo":         ci_lo,
        "wilson_ci_hi":         ci_hi,
        "wilson_ci_lo_pct":     ci_lo * 100,
        "wilson_ci_hi_pct":     ci_hi * 100,
        "mi_auroc":             mi_metrics.get("auroc", float("nan")),
        "threshold":            float(threshold),
        "n_members":            int(len(member_losses)),
        "n_nonmembers":         int(len(nonmember_losses)),
        # Paper targets
        "paper_mi_accuracy_pct": 52.3,
        "paper_ci_lo_pct":       50.9,
        "paper_ci_hi_pct":       53.7,
    }


# ---------------------------------------------------------------------------
# Privacy evaluation: attribute inference
# ---------------------------------------------------------------------------

def attribute_inference_attack(
    model: nn.Module,
    test_loader: DataLoader,
    device: torch.device,
    target_feature_idx: int = 0,
    n_samples: int = 500,
    seed: int = 42,
) -> Dict:
    """
    Attribute inference: infer a sensitive feature from model internals.

    Paper (Table 5): attribute inference accuracy = 11.3% above random.
    Random baseline for binary attribute = 50.0% → reported = 61.3%.

    Method: use penultimate-layer activations as features for a simple
    logistic regression that predicts whether the target feature is above
    its median value. Compare against 50% random baseline.

    Returns accuracy above random, raw accuracy, and paper target.
    """
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import cross_val_score
    except ImportError:
        return {"error": "scikit-learn not installed; skipping attribute inference."}

    model.eval()
    rng = np.random.default_rng(seed)

    # Register hook on penultimate layer to capture activations
    activations: List[np.ndarray] = []
    attribute_labels: List[int]   = []

    def _hook(module, input, output):
        if isinstance(output, (tuple, list)):
            out = output[0]
        else:
            out = output
        # Mean-pool over time dimension if 3-D
        if out.dim() == 3:
            out = out.mean(dim=1)
        activations.append(out.detach().cpu().numpy())

    # Attach to last LSTM layer (varies by model; fall back to any Linear)
    hook_handle = None
    for name, module in reversed(list(model.named_modules())):
        if isinstance(module, (nn.LSTM, nn.Linear)):
            hook_handle = module.register_forward_hook(_hook)
            break

    count = 0
    with torch.no_grad():
        for X, y in test_loader:
            if count >= n_samples:
                break
            X_dev = X.to(device)
            model(X_dev)
            # Binary attribute label: is feature 0 above its batch median?
            feat_vals = X[:, 0, target_feature_idx].numpy()  # (B,)
            median    = np.median(feat_vals)
            attr_lab  = (feat_vals >= median).astype(int)
            attribute_labels.extend(attr_lab.tolist())
            count += len(attr_lab)

    if hook_handle:
        hook_handle.remove()

    if not activations:
        return {"error": "No activations captured."}

    act_array   = np.concatenate(activations, axis=0)[:n_samples]
    label_array = np.array(attribute_labels)[:n_samples]

    # 5-fold CV logistic regression
    clf     = LogisticRegression(max_iter=200, random_state=seed)
    scores  = cross_val_score(clf, act_array, label_array, cv=5, scoring="accuracy")
    acc     = float(scores.mean())
    random_baseline = 0.50
    above_random    = (acc - random_baseline) * 100  # percentage points

    return {
        "attr_inference_acc":         acc,
        "attr_inference_acc_pct":     acc * 100,
        "random_baseline_pct":        random_baseline * 100,
        "above_random_pct":           above_random,
        "paper_above_random_pct":     11.3,
        "n_samples":                  int(len(label_array)),
        "target_feature_idx":         target_feature_idx,
    }


# ---------------------------------------------------------------------------
# Watermark verification
# ---------------------------------------------------------------------------

def verify_watermark(
    cfg: dict,
    teacher_fp32: nn.Module,
    student_int8: Optional[nn.Module] = None,
) -> Dict:
    """
    Verify watermark bit agreement on teacher (FP32) and student (INT8).
    Paper: 98.7% bit agreement post-INT8.
    """
    try:
        wm = ModelWatermark(
            teacher_fp32,
            d        = cfg["watermark"]["d"],
            lambda_w = cfg["watermark"]["lambda_w"],
            tau      = cfg["watermark"]["tau"],
        )
    except RuntimeError as e:
        return {"error": str(e)}

    result = {"fp32": wm.verify(teacher_fp32)}

    if student_int8 is not None:
        try:
            result["int8_vs_fp32"] = wm.verify_int8(teacher_fp32, student_int8)
        except Exception as e:
            result["int8_error"] = str(e)

    result["paper_bit_agreement"] = ModelWatermark.PAPER_BIT_AGR
    result["paper_theta"]         = ModelWatermark.PAPER_THETA
    return result


# ---------------------------------------------------------------------------
# Results reporting
# ---------------------------------------------------------------------------

PAPER_TARGETS = {
    "arrhythmia": {"auroc": 0.943},
    "sepsis":     {"auroc": 0.876, "early_warning_hours": 6.2},
    "mortality":  {"auroc": 0.901},
}


def print_results(results: Dict, model_name: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"Model: {model_name}")
    print(f"{'=' * 60}")
    for task, metrics in results.items():
        if task == "privacy":
            continue
        target = PAPER_TARGETS.get(task, {})
        auroc  = metrics.get("auroc", float("nan"))
        auprc  = metrics.get("auprc", float("nan"))
        ci_lo  = metrics.get("auroc_ci_lo", float("nan"))
        ci_hi  = metrics.get("auroc_ci_hi", float("nan"))
        paper  = target.get("auroc", float("nan"))
        delta  = auroc - paper if not np.isnan(auroc) and not np.isnan(paper) else float("nan")

        print(f"\n  Task: {task}")
        print(f"    AUROC  : {auroc:.4f}  (paper: {paper:.3f}, Δ={delta:+.4f})")
        print(f"    AUPRC  : {auprc:.4f}")
        print(f"    95% CI : [{ci_lo:.4f}, {ci_hi:.4f}]")
        if "early_warning_hours" in metrics:
            print(f"    Early warning: {metrics['early_warning_hours']:.1f}h  "
                  f"(paper: {target.get('early_warning_hours', '—')}h)")
        print(f"    n_samples : {metrics.get('n_samples', '?')}")
        print(f"    Mean latency: {metrics.get('mean_inference_ms', float('nan')):.2f} ms/sample")


def print_privacy_results(priv: Dict) -> None:
    print(f"\n{'=' * 60}")
    print("Privacy Evaluation (Table 5)")
    print(f"{'=' * 60}")

    mi = priv.get("mi_attack", {})
    if "error" not in mi:
        print(f"\n  Membership Inference Attack:")
        print(f"    Accuracy : {mi.get('mi_accuracy_pct', float('nan')):.1f}%  "
              f"(paper: {mi.get('paper_mi_accuracy_pct', '?')}%)")
        print(f"    Wilson CI: [{mi.get('wilson_ci_lo_pct', float('nan')):.1f}%, "
              f"{mi.get('wilson_ci_hi_pct', float('nan')):.1f}%]  "
              f"(paper: [{mi.get('paper_ci_lo_pct', '?')}%, {mi.get('paper_ci_hi_pct', '?')}%])")

    ai = priv.get("attribute_inference", {})
    if "error" not in ai:
        print(f"\n  Attribute Inference:")
        print(f"    Accuracy   : {ai.get('attr_inference_acc_pct', float('nan')):.1f}%")
        print(f"    Above random: {ai.get('above_random_pct', float('nan')):.1f} pp  "
              f"(paper: {ai.get('paper_above_random_pct', '?')} pp)")

    wm = priv.get("watermark", {})
    if wm and "error" not in wm:
        fp32 = wm.get("fp32", {})
        int8 = wm.get("int8_vs_fp32", {})
        print(f"\n  Watermark Verification:")
        print(f"    FP32 bit agreement : {fp32.get('bit_agreement', float('nan')):.4f}  "
              f"(pass={fp32.get('is_watermarked', '?')}, θ={fp32.get('theta', '?')})")
        if int8:
            print(f"    INT8 bit agreement : {int8.get('int8_bit_agreement', float('nan')):.4f}  "
                  f"(paper target: {wm.get('paper_bit_agreement', '?')})")


# ---------------------------------------------------------------------------
# Main evaluation entry points
# ---------------------------------------------------------------------------

def evaluate_model(
    model: nn.Module,
    model_name: str,
    cfg: dict,
    tasks: List[str],
    device: torch.device,
    batch_size: int,
    seed: int,
) -> Dict:
    results = {}
    for task in tasks:
        loader  = build_test_loader(cfg, task, batch_size=batch_size, seed=seed)
        metrics = run_evaluation(model, loader, device, task=task)
        results[task] = metrics
    return results


def evaluate_privacy(
    teacher_fp32: nn.Module,
    student_int8: Optional[nn.Module],
    cfg: dict,
    device: torch.device,
    batch_size: int,
    seed: int,
) -> Dict:
    # Reuse arrhythmia loaders for MI attack (train vs test membership)
    train_loader = build_test_loader(cfg, "arrhythmia", batch_size=batch_size, seed=seed)
    test_loader  = build_test_loader(cfg, "arrhythmia", batch_size=batch_size, seed=seed + 1)

    mi_result = membership_inference_attack(
        teacher_fp32, train_loader, test_loader, device, seed=seed
    )
    ai_result = attribute_inference_attack(
        teacher_fp32, test_loader, device, seed=seed
    )
    wm_result = verify_watermark(cfg, teacher_fp32, student_int8)

    return {
        "mi_attack":           mi_result,
        "attribute_inference": ai_result,
        "watermark":           wm_result,
    }


# ---------------------------------------------------------------------------
# Argument parsing and main
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="BioTwin-AgentNet evaluation")
    parser.add_argument("--config",      type=str, default="configs/main.yaml")
    parser.add_argument("--output_dir",  type=str, default="checkpoints")
    parser.add_argument("--results_dir", type=str, default="results/reproduced")
    parser.add_argument("--device",      type=str, default="cpu")
    parser.add_argument("--seed",        type=int, default=42)
    parser.add_argument("--batch_size",  type=int, default=64)
    parser.add_argument(
        "--model",
        type=str,
        default="all",
        choices=["teacher", "student_fp32", "student_int8", "all"],
    )
    parser.add_argument(
        "--task",
        type=str,
        default="all",
        choices=["arrhythmia", "sepsis", "mortality", "all"],
    )
    parser.add_argument(
        "--eval",
        type=str,
        default="all",
        choices=["performance", "privacy", "all"],
    )
    return parser.parse_args()


def main():
    args   = parse_args()
    cfg    = load_config(args.config)
    device = torch.device(args.device)
    seed   = args.seed
    set_global_seed(seed)

    out_dir = Path(args.output_dir)
    res_dir = Path(args.results_dir)
    res_dir.mkdir(parents=True, exist_ok=True)

    tasks = (
        ["arrhythmia", "sepsis", "mortality"]
        if args.task == "all"
        else [args.task]
    )

    # Load models
    teacher_fp32 = None
    student_fp32 = None
    student_int8 = None

    need_teacher = args.model in ("teacher", "all") or args.eval in ("privacy", "all")
    need_student = args.model in ("student_fp32", "student_int8", "all")

    if need_teacher:
        teacher_fp32 = load_teacher(
            cfg,
            ckpt_path = str(out_dir / "phase1" / "teacher_final.pt"),
            device    = device,
        )

    if need_student:
        student_fp32 = load_student(
            cfg,
            ckpt_path = str(out_dir / "phase3" / "student_fp32_final.pt"),
            device    = device,
        )
        student_int8 = load_int8_student(
            str(out_dir / "phase3" / "student_int8.pt"),
            device,
        )

    all_results = {}

    # ----------------------------------------------------------------
    # Performance evaluation
    # ----------------------------------------------------------------
    if args.eval in ("performance", "all"):

        if teacher_fp32 is not None and args.model in ("teacher", "all"):
            teacher_results = evaluate_model(
                teacher_fp32, "teacher_fp32", cfg, tasks, device,
                args.batch_size, seed,
            )
            print_results(teacher_results, "Teacher LSTM (FP32)")
            all_results["teacher_fp32"] = teacher_results

        if student_fp32 is not None and args.model in ("student_fp32", "all"):
            student_results = evaluate_model(
                student_fp32, "student_fp32", cfg, tasks, device,
                args.batch_size, seed,
            )
            print_results(student_results, "Student LSTM (FP32)")
            all_results["student_fp32"] = student_results

        if student_int8 is not None and args.model in ("student_int8", "all"):
            int8_results = evaluate_model(
                student_int8, "student_int8", cfg, tasks, device,
                args.batch_size, seed,
            )
            print_results(int8_results, "Student LSTM (INT8)")
            all_results["student_int8"] = int8_results

    # ----------------------------------------------------------------
    # Privacy evaluation
    # ----------------------------------------------------------------
    if args.eval in ("privacy", "all") and teacher_fp32 is not None:
        priv_results = evaluate_privacy(
            teacher_fp32, student_int8, cfg, device, args.batch_size, seed
        )
        print_privacy_results(priv_results)
        all_results["privacy"] = priv_results

    # ----------------------------------------------------------------
    # Save results
    # ----------------------------------------------------------------
    results_file = res_dir / "test_results.json"

    # Convert non-serialisable floats (nan/inf) to strings
    def _clean(obj):
        if isinstance(obj, dict):
            return {k: _clean(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_clean(v) for v in obj]
        if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
            return str(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.integer):
            return int(obj)
        return obj

    with open(results_file, "w") as f:
        json.dump(_clean(all_results), f, indent=2)

    print(f"\nResults saved to {results_file}")
    print("\nDone.")


if __name__ == "__main__":
    main()
