"""
evaluate_all.py

Run every evaluation in the paper — main model, all baselines,
all ablations — and write a consolidated results CSV.

Outputs (written to results/reproduced/):
  all_results.csv      : one row per (model, task), all metrics
  privacy_results.csv  : MI attack, attribute inference, watermark
  timing_results.csv   : latency, energy, model size

Usage:
    python evaluate_all.py --config configs/main.yaml
    python evaluate_all.py --only baselines
    python evaluate_all.py --only ablations
    python evaluate_all.py --only main
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
import yaml
from torch.utils.data import DataLoader

# Internal imports
from src.datasets.mimic4_dataset import MIMIC4Dataset, load_split_ids
from src.models.teacher import TeacherLSTM
from src.models.student import StudentLSTM
from src.models.centralized_cnn import CentralizedCNN
from src.models.fedhealth import FedHealthModel
from src.models.fedprox import FedProxModel
from src.metrics.evaluation import EvaluationSuite
from src.utils.seeding import set_global_seed
from src.utils.checkpointing import load_checkpoint
from test import (
    load_teacher,
    load_student,
    load_int8_student,
    build_test_loader,
    run_evaluation,
    evaluate_privacy,
    PAPER_TARGETS,
)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Model registry: maps name → (loader_fn, checkpoint_path, config_key)
# ---------------------------------------------------------------------------

def build_model_registry(cfg: dict, out_dir: Path, device: torch.device) -> Dict:
    """
    Returns a dict: model_name → nn.Module (or None if checkpoint missing).
    Models are loaded in eval mode.
    """
    registry = {}

    # Main model — teacher
    registry["biotwinagentnet_teacher"] = load_teacher(
        cfg,
        ckpt_path = str(out_dir / "phase1" / "teacher_final.pt"),
        device    = device,
    )

    # Main model — student FP32
    registry["biotwinagentnet_student_fp32"] = load_student(
        cfg,
        ckpt_path = str(out_dir / "phase3" / "student_fp32_final.pt"),
        device    = device,
    )

    # Main model — student INT8
    int8 = load_int8_student(str(out_dir / "phase3" / "student_int8.pt"), device)
    registry["biotwinagentnet_student_int8"] = int8

    # Baselines
    baseline_names = [
        "centralized_cnn",
        "fedavg",
        "fedhealth",
        "fedprox",
    ]
    for bname in baseline_names:
        ckpt = out_dir / "baselines" / f"{bname}_final.pt"
        model = _load_baseline(cfg, bname, str(ckpt), device)
        registry[f"baseline_{bname}"] = model

    # Ablations
    ablation_names = [
        "no_fl", "no_dp", "no_he", "no_cl", "no_ml", "no_kd", "no_blockchain"
    ]
    for aname in ablation_names:
        ckpt  = out_dir / "ablations" / f"{aname}_final.pt"
        model = _load_ablation(cfg, aname, str(ckpt), device)
        registry[f"ablation_{aname}"] = model

    return registry


def _load_baseline(cfg: dict, name: str, ckpt_path: str, device: torch.device) -> Optional[nn.Module]:
    """Load a baseline model from its checkpoint."""
    n_features = cfg["data"]["mimic4"]["n_features"]
    seq_len    = cfg["data"]["mimic4"]["seq_len"]

    if name == "centralized_cnn":
        model = CentralizedCNN(n_features=n_features, seq_len=seq_len, n_classes=2)
    elif name == "fedavg":
        # FedAvg uses same teacher architecture (untreated federation)
        mc    = cfg["model"]["teacher"]
        model = TeacherLSTM(
            n_features    = n_features,
            hidden_size   = mc["hidden_size"],
            num_layers    = mc["num_layers"],
            n_classes     = mc["n_classes"],
            dropout       = 0.0,
            bidirectional = mc["bidirectional"],
        )
    elif name == "fedhealth":
        model = FedHealthModel(n_features=n_features, seq_len=seq_len, n_classes=2)
    elif name == "fedprox":
        mc    = cfg["model"]["teacher"]
        model = FedProxModel(
            n_features    = n_features,
            hidden_size   = mc["hidden_size"],
            num_layers    = mc["num_layers"],
            n_classes     = mc["n_classes"],
            dropout       = 0.0,
            bidirectional = mc["bidirectional"],
            mu            = cfg.get("baseline_fedprox", {}).get("mu", 0.01),
        )
    else:
        return None

    if Path(ckpt_path).exists():
        load_checkpoint(ckpt_path, model, device=device)
    else:
        print(f"[Warning] Baseline checkpoint not found: {ckpt_path}")

    model.eval()
    return model.to(device)


def _load_ablation(cfg: dict, name: str, ckpt_path: str, device: torch.device) -> Optional[nn.Module]:
    """
    Load an ablation model. All ablations share the teacher architecture
    (they differ in what training components were disabled, not architecture).
    """
    mc    = cfg["model"]["teacher"]
    model = TeacherLSTM(
        n_features    = cfg["data"]["mimic4"]["n_features"],
        hidden_size   = mc["hidden_size"],
        num_layers    = mc["num_layers"],
        n_classes     = mc["n_classes"],
        dropout       = 0.0,
        bidirectional = mc["bidirectional"],
    )

    if Path(ckpt_path).exists():
        load_checkpoint(ckpt_path, model, device=device)
    else:
        print(f"[Warning] Ablation checkpoint not found: {ckpt_path}")

    model.eval()
    return model.to(device)


# ---------------------------------------------------------------------------
# Edge deployment timing (Jetson Nano proxy)
# ---------------------------------------------------------------------------

def measure_timing(
    model: nn.Module,
    cfg: dict,
    device: torch.device,
    n_warmup: int = 10,
    n_runs:   int = 100,
) -> Dict:
    """
    Measure inference latency and estimate model size.

    Paper targets (edge, Jetson Nano 4GB):
      Inference latency : 47 ms
      Energy            : 112 mJ
      Model size (INT8) : 0.45 MB

    Energy is not directly measurable here; we report latency and size.
    """
    seq_len    = cfg["data"]["mimic4"]["seq_len"]
    n_features = cfg["data"]["mimic4"]["n_features"]
    batch      = torch.randn(1, seq_len, n_features).to(device)

    model.eval()
    with torch.no_grad():
        for _ in range(n_warmup):
            model(batch)

    times_ms = []
    with torch.no_grad():
        for _ in range(n_runs):
            t0 = time.perf_counter()
            model(batch)
            times_ms.append((time.perf_counter() - t0) * 1000.0)

    # Model size in MB (parameter bytes, FP32 = 4 bytes, INT8 = 1 byte)
    n_params  = sum(p.numel() for p in model.parameters())
    # Detect INT8 by checking first param dtype
    try:
        first_param = next(model.parameters())
        bytes_per   = 1 if first_param.dtype == torch.qint8 else 4
    except StopIteration:
        bytes_per = 4
    size_mb = n_params * bytes_per / 1e6

    return {
        "mean_latency_ms":  float(np.mean(times_ms)),
        "p50_latency_ms":   float(np.percentile(times_ms, 50)),
        "p95_latency_ms":   float(np.percentile(times_ms, 95)),
        "n_params":         n_params,
        "size_mb":          size_mb,
        "paper_latency_ms": 47.0,
        "paper_size_mb":    0.45,
        "paper_energy_mj":  112.0,
    }


# ---------------------------------------------------------------------------
# CSV writers
# ---------------------------------------------------------------------------

def write_performance_csv(rows: List[Dict], path: Path) -> None:
    if not rows:
        return
    fieldnames = sorted({k for r in rows for k in r.keys()})
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})
    print(f"Saved performance CSV → {path}")


def write_dict_csv(d: Dict, path: Path) -> None:
    rows = []
    for key, val in d.items():
        if isinstance(val, dict):
            row = {"name": key}
            row.update(val)
            rows.append(row)
    if not rows:
        return
    fieldnames = sorted({k for r in rows for k in r.keys()})
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: str(row.get(k, "")) for k in fieldnames})
    print(f"Saved CSV → {path}")


# ---------------------------------------------------------------------------
# Main evaluation loop
# ---------------------------------------------------------------------------

def run_all(args, cfg: dict) -> None:
    device  = torch.device(args.device)
    out_dir = Path(args.output_dir)
    res_dir = Path(args.results_dir)
    res_dir.mkdir(parents=True, exist_ok=True)

    tasks = ["arrhythmia", "sepsis", "mortality"]
    seed  = cfg["experiment"]["seed"]

    # Build model registry
    registry = build_model_registry(cfg, out_dir, device)

    # Decide which models to evaluate
    if args.only == "main":
        model_keys = [k for k in registry if k.startswith("biotwinagentnet")]
    elif args.only == "baselines":
        model_keys = [k for k in registry if k.startswith("baseline")]
    elif args.only == "ablations":
        model_keys = [k for k in registry if k.startswith("ablation")]
    else:
        model_keys = list(registry.keys())

    perf_rows    = []
    timing_rows  = {}
    privacy_rows = {}

    for model_name in model_keys:
        model = registry.get(model_name)
        if model is None:
            print(f"[Skip] {model_name}: model is None (checkpoint missing)")
            continue

        print(f"\n{'=' * 60}")
        print(f"Evaluating: {model_name}")
        print(f"{'=' * 60}")

        # Performance on all tasks
        for task in tasks:
            loader  = build_test_loader(cfg, task, batch_size=args.batch_size, seed=seed)
            metrics = run_evaluation(model, loader, device, task=task)

            paper_auroc = PAPER_TARGETS.get(task, {}).get("auroc", float("nan"))
            row = {
                "model":        model_name,
                "task":         task,
                "auroc":        metrics.get("auroc", float("nan")),
                "auprc":        metrics.get("auprc", float("nan")),
                "auroc_ci_lo":  metrics.get("auroc_ci_lo", float("nan")),
                "auroc_ci_hi":  metrics.get("auroc_ci_hi", float("nan")),
                "paper_auroc":  paper_auroc,
                "delta_auroc":  metrics.get("auroc", float("nan")) - paper_auroc,
                "n_samples":    metrics.get("n_samples", ""),
                "latency_ms":   metrics.get("mean_inference_ms", float("nan")),
            }
            if "early_warning_hours" in metrics:
                row["early_warning_hours"] = metrics["early_warning_hours"]
            perf_rows.append(row)

            print(f"  {task}: AUROC={row['auroc']:.4f} "
                  f"(paper={paper_auroc:.3f}, Δ={row['delta_auroc']:+.4f})")

        # Timing
        timing_rows[model_name] = measure_timing(model, cfg, device)

    # Privacy (teacher only)
    teacher_model = registry.get("biotwinagentnet_teacher")
    int8_model    = registry.get("biotwinagentnet_student_int8")
    if teacher_model is not None and args.only in ("main", "all", None):
        print(f"\n{'=' * 60}")
        print("Privacy evaluation")
        print(f"{'=' * 60}")
        priv = evaluate_privacy(teacher_model, int8_model, cfg, device, args.batch_size, seed)
        privacy_rows = priv

    # Write outputs
    write_performance_csv(perf_rows, res_dir / "all_results.csv")
    write_dict_csv(timing_rows, res_dir / "timing_results.csv")

    # Privacy CSV (flat)
    priv_flat = {}
    mi = privacy_rows.get("mi_attack", {})
    if "error" not in mi:
        priv_flat.update({f"mi_{k}": v for k, v in mi.items()})
    ai = privacy_rows.get("attribute_inference", {})
    if "error" not in ai:
        priv_flat.update({f"ai_{k}": v for k, v in ai.items()})
    wm = privacy_rows.get("watermark", {})
    if wm and "error" not in wm:
        fp32 = wm.get("fp32", {})
        priv_flat["wm_fp32_bit_agreement"] = fp32.get("bit_agreement", "")
        priv_flat["wm_paper_target"]        = wm.get("paper_bit_agreement", "")
    if priv_flat:
        priv_path = res_dir / "privacy_results.csv"
        with open(priv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=sorted(priv_flat.keys()))
            writer.writeheader()
            writer.writerow(priv_flat)
        print(f"Saved privacy CSV → {priv_path}")

    # Combined JSON
    combined = {
        "performance": perf_rows,
        "timing":      {k: {ek: (str(ev) if isinstance(ev, float) and
                               (np.isnan(ev) or np.isinf(ev)) else ev)
                             for ek, ev in v.items()}
                        for k, v in timing_rows.items()},
        "privacy":     {k: v for k, v in privacy_rows.items() if not isinstance(v, float)},
    }
    with open(res_dir / "all_results.json", "w") as f:
        json.dump(combined, f, indent=2, default=str)
    print(f"Saved combined JSON → {res_dir / 'all_results.json'}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="BioTwin-AgentNet full evaluation")
    parser.add_argument("--config",      type=str, default="configs/main.yaml")
    parser.add_argument("--output_dir",  type=str, default="checkpoints")
    parser.add_argument("--results_dir", type=str, default="results/reproduced")
    parser.add_argument("--device",      type=str, default="cpu")
    parser.add_argument("--batch_size",  type=int, default=64)
    parser.add_argument("--seed",        type=int, default=42)
    parser.add_argument(
        "--only",
        type=str,
        default="all",
        choices=["main", "baselines", "ablations", "all"],
    )
    return parser.parse_args()


def main():
    args = parse_args()
    cfg  = load_config(args.config)
    cfg["experiment"]["seed"] = args.seed
    set_global_seed(args.seed)
    run_all(args, cfg)
    print("\nAll evaluations complete.")


if __name__ == "__main__":
    main()
