"""
data/download.py
Downloads MIMIC-IV, PhysioNet Challenge 2019, and eICU datasets.

NOTE: These datasets require credentialed access from PhysioNet / eICU.
You must complete the required CITI training and sign the data use agreement
before downloading. This script does NOT bypass access controls.

Usage:
    python data/download.py --dataset mimic4 --physionet-user <username>
    python data/download.py --dataset physionet2019 --physionet-user <username>
    python data/download.py --dataset eicu --physionet-user <username>
"""

import os
import sys
import hashlib
import argparse
import subprocess
from pathlib import Path

# Official dataset sources (all credentialed — require DUA + CITI)
DATASETS = {
    "mimic4": {
        "url": "https://physionet.org/files/mimiciv/2.2/",
        "version": "2.2",
        "license": "PhysioNet Credentialed Health Data License 1.5.0",
        "doi": "10.13026/6mm1-ek67",
        "local_dir": "data/raw/mimic-iv",
        "note": (
            "50,000 ICU patients; 127 variables; 1-hr resampling; "
            "train/val/test 80/10/10 split; seed 42"
        ),
    },
    "physionet2019": {
        "url": "https://physionet.org/files/challenge-2019/1.0.0/",
        "version": "1.0.0",
        "license": "PhysioNet Challenge 2019 Data Use Agreement",
        "doi": "10.13026/v0kb-6j95",
        "local_dir": "data/raw/physionet2019",
        "note": "40,336 records; 40 variables; sepsis early warning",
    },
    "eicu": {
        "url": "https://physionet.org/files/eicu-crd/2.0/",
        "version": "2.0",
        "license": "PhysioNet Credentialed Health Data License 1.5.0",
        "doi": "10.13026/C2WM1R",
        "local_dir": "data/raw/eicu",
        "note": (
            "52,000 records; 335 hospitals; used ONLY for knowledge "
            "distillation (Phase 2); no patient overlap with MIMIC-IV"
        ),
    },
}

# SHA256 checksums for key files
# [UNVERIFIED] — mark actual checksums after download verification
CHECKSUMS = {
    "mimic4": {"MIMIC-IV-2.2.zip": "[UNVERIFIED]"},
    "physionet2019": {
        "training_setA.zip": "[UNVERIFIED]",
        "training_setB.zip": "[UNVERIFIED]",
    },
    "eicu": {"eicu-collaborative-research-database-2.0.zip": "[UNVERIFIED]"},
}


def sha256_file(path: Path, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_checksum(path: Path, expected: str) -> bool:
    if expected == "[UNVERIFIED]":
        print(f"  WARNING: Checksum for {path.name} is [UNVERIFIED]. "
              f"Skipping integrity check.")
        return True
    actual = sha256_file(path)
    if actual != expected:
        print(f"  ERROR: Checksum mismatch for {path.name}")
        print(f"    Expected: {expected}")
        print(f"    Got:      {actual}")
        return False
    print(f"  OK: Checksum verified for {path.name}")
    return True


def download_physionet(url: str, local_dir: str, username: str) -> None:
    """Download from PhysioNet using wget with credentials."""
    out_dir = Path(local_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        "wget",
        "--no-check-certificate",
        "-r",
        "-N",
        "-c",
        "-np",
        f"--user={username}",
        "--ask-password",
        url,
        "-P",
        str(out_dir),
    ]
    print(f"Running: {' '.join(cmd)}")
    print("You will be prompted for your PhysioNet password.")
    subprocess.run(cmd, check=True)


def main():
    parser = argparse.ArgumentParser(
        description="Download BioTwin-AgentNet datasets from official sources."
    )
    parser.add_argument(
        "--dataset",
        choices=list(DATASETS.keys()) + ["all"],
        required=True,
        help="Dataset to download",
    )
    parser.add_argument(
        "--physionet-user",
        required=True,
        help="Your PhysioNet username (required for all three datasets)",
    )
    parser.add_argument(
        "--output-root",
        default=".",
        help="Root directory for downloads (default: current directory)",
    )
    args = parser.parse_args()

    targets = list(DATASETS.keys()) if args.dataset == "all" else [args.dataset]

    for name in targets:
        info = DATASETS[name]
        local_dir = Path(args.output_root) / info["local_dir"]
        print(f"\n{'='*60}")
        print(f"Dataset: {name}")
        print(f"  DOI   : {info['doi']}")
        print(f"  URL   : {info['url']}")
        print(f"  Note  : {info['note']}")
        print(f"  Dir   : {local_dir}")
        print(
            "\n  IMPORTANT: This dataset requires credentialed PhysioNet access.\n"
            "  Complete CITI training and sign the DUA at physionet.org first.\n"
        )
        download_physionet(info["url"], str(local_dir), args.physionet_user)
        print(f"Download complete: {local_dir}")

    print("\nAll requested datasets downloaded.")
    print(
        "Next step: python data/extract.py --dataset <name> "
        "then python data/preprocess.py"
    )


if __name__ == "__main__":
    main()
