#!/usr/bin/env python3
"""
data/extract.py

Decompress and organise raw clinical dataset archives into the expected
directory structure for data/preprocess.py.

Expected input layout (after credentialed PhysioNet download):
    data/raw/mimic4/        — MIMIC-IV CSV archives (.csv.gz or .zip)
    data/raw/physionet2019/ — PhysioNet Challenge 2019 .psv files or tar.gz
    data/raw/eicu/          — eICU CSV archives (.csv.gz or .zip)

Usage:
    python data/extract.py --dataset mimic4
    python data/extract.py --dataset physionet2019
    python data/extract.py --dataset eicu
    python data/extract.py --dataset all
    python data/extract.py --dataset all --raw_dir /path/to/raw --out_dir /path/to/out
"""

from __future__ import annotations

import argparse
import gzip
import os
import shutil
import tarfile
import zipfile
from pathlib import Path


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REQUIRED_MIMIC4 = [
    "admissions.csv",
    "patients.csv",
    "chartevents.csv",
    "labevents.csv",
    "diagnoses_icd.csv",
    "d_icd_diagnoses.csv",
    "d_labitems.csv",
    "d_items.csv",
]

REQUIRED_PHYSIONET2019 = [
    # Training set A and B from PhysioNet Challenge 2019
    # https://physionet.org/content/challenge-2019/1.0.0/
    "training_setA",
    "training_setB",
]

REQUIRED_EICU = [
    "patient.csv",
    "vitalPeriodic.csv",
    "vitalAperiodic.csv",
    "lab.csv",
    "diagnosis.csv",
    "physicalExam.csv",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_gz(src: Path, dst_dir: Path) -> Path:
    """Decompress a single .csv.gz file."""
    dst = dst_dir / src.stem          # strip .gz → .csv
    with gzip.open(src, "rb") as fin:
        with open(dst, "wb") as fout:
            shutil.copyfileobj(fin, fout)
    return dst


def _extract_zip(src: Path, dst_dir: Path) -> None:
    with zipfile.ZipFile(src) as zf:
        zf.extractall(dst_dir)


def _extract_tar(src: Path, dst_dir: Path) -> None:
    with tarfile.open(src) as tf:
        tf.extractall(dst_dir)


def _find_archives(directory: Path, extensions: tuple = (".gz", ".zip", ".tar", ".tar.gz", ".tgz")) -> list[Path]:
    archives = []
    for ext in extensions:
        archives.extend(directory.glob(f"**/*{ext}"))
    return sorted(archives)


def _check_required(out_dir: Path, required: list[str], dataset: str) -> None:
    missing = [f for f in required if not (out_dir / f).exists()]
    if missing:
        print(f"  [Warning] {dataset}: these expected files were not found after extraction:")
        for f in missing:
            print(f"    {f}")
        print(f"  Confirm your PhysioNet download is complete.")
    else:
        print(f"  [OK] All required {dataset} files present.")


# ---------------------------------------------------------------------------
# Dataset extractors
# ---------------------------------------------------------------------------

def extract_mimic4(raw_dir: Path, out_dir: Path) -> None:
    print("Extracting MIMIC-IV ...")
    out_dir.mkdir(parents=True, exist_ok=True)

    archives = _find_archives(raw_dir)
    if not archives:
        print(f"  No archives found in {raw_dir}.")
        print("  Place MIMIC-IV CSV archives (.csv.gz, .zip) under data/raw/mimic4/")
        print("  Source: https://physionet.org/content/mimiciv/2.2/")
        print("  DOI: 10.13026/6mm1-ek67")
        return

    for arc in archives:
        print(f"  Extracting {arc.name} ...")
        if arc.suffix == ".gz" and arc.stem.endswith(".csv"):
            _extract_gz(arc, out_dir)
        elif arc.suffix == ".zip":
            _extract_zip(arc, out_dir)
        elif arc.suffix in {".tar", ".tgz"} or arc.name.endswith(".tar.gz"):
            _extract_tar(arc, out_dir)
        else:
            print(f"  [Skip] Unrecognised archive type: {arc}")

    # Flatten nested hosp/ icu/ subdirectories from the standard MIMIC-IV layout
    for subdir in ["hosp", "icu"]:
        sub = out_dir / subdir
        if sub.is_dir():
            for f in sub.iterdir():
                dest = out_dir / f.name
                if not dest.exists():
                    shutil.move(str(f), str(dest))
            sub.rmdir()

    _check_required(out_dir, REQUIRED_MIMIC4, "MIMIC-IV")
    print(f"  Done. Files in {out_dir}")


def extract_physionet2019(raw_dir: Path, out_dir: Path) -> None:
    print("Extracting PhysioNet Challenge 2019 ...")
    out_dir.mkdir(parents=True, exist_ok=True)

    archives = _find_archives(raw_dir)
    if not archives:
        print(f"  No archives found in {raw_dir}.")
        print("  Place PhysioNet 2019 archives (.tar.gz, .zip) under data/raw/physionet2019/")
        print("  Source: https://physionet.org/content/challenge-2019/1.0.0/")
        print("  DOI: 10.13026/v0kw-7n94")
        return

    for arc in archives:
        print(f"  Extracting {arc.name} ...")
        if arc.name.endswith(".tar.gz") or arc.suffix in {".tar", ".tgz"}:
            _extract_tar(arc, out_dir)
        elif arc.suffix == ".zip":
            _extract_zip(arc, out_dir)
        elif arc.suffix == ".gz":
            _extract_gz(arc, out_dir)
        else:
            print(f"  [Skip] Unrecognised archive type: {arc}")

    _check_required(out_dir, REQUIRED_PHYSIONET2019, "PhysioNet2019")
    print(f"  Done. Files in {out_dir}")


def extract_eicu(raw_dir: Path, out_dir: Path) -> None:
    print("Extracting eICU ...")
    out_dir.mkdir(parents=True, exist_ok=True)

    archives = _find_archives(raw_dir)
    if not archives:
        print(f"  No archives found in {raw_dir}.")
        print("  Place eICU CSV archives (.csv.gz, .zip) under data/raw/eicu/")
        print("  Source: https://physionet.org/content/eicu-crd/2.0/")
        print("  DOI: 10.13026/C2WM1R")
        return

    for arc in archives:
        print(f"  Extracting {arc.name} ...")
        if arc.suffix == ".gz" and arc.stem.endswith(".csv"):
            _extract_gz(arc, out_dir)
        elif arc.suffix == ".zip":
            _extract_zip(arc, out_dir)
        elif arc.name.endswith(".tar.gz") or arc.suffix in {".tar", ".tgz"}:
            _extract_tar(arc, out_dir)
        else:
            print(f"  [Skip] Unrecognised archive type: {arc}")

    _check_required(out_dir, REQUIRED_EICU, "eICU")
    print(f"  Done. Files in {out_dir}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Extract BioTwin-AgentNet raw dataset archives")
    parser.add_argument("--dataset",  default="all",
                        choices=["mimic4", "physionet2019", "eicu", "all"],
                        help="Which dataset to extract (default: all)")
    parser.add_argument("--raw_dir",  default="data/raw",
                        help="Root directory containing raw archives (default: data/raw)")
    parser.add_argument("--out_dir",  default="data/extracted",
                        help="Root directory for extracted files (default: data/extracted)")
    args = parser.parse_args()

    raw = Path(args.raw_dir)
    out = Path(args.out_dir)

    datasets = ["mimic4", "physionet2019", "eicu"] if args.dataset == "all" else [args.dataset]

    for ds in datasets:
        fn = {"mimic4": extract_mimic4,
              "physionet2019": extract_physionet2019,
              "eicu": extract_eicu}[ds]
        fn(raw / ds, out / ds)

    print("\nExtraction complete. Next step:")
    print("  python data/preprocess.py")


if __name__ == "__main__":
    main()
