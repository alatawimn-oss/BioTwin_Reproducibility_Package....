#!/usr/bin/env python3
"""
scripts/statistical_tests.py

DeLong AUROC tests, bootstrap confidence intervals, and Wilson CI
verification for the BioTwin-AgentNet paper.

Paper targets:
  AUROC arrhythmia : 0.943  CI (0.937, 0.949)
  AUROC sepsis     : 0.876  CI (0.869, 0.883)
  AUROC mortality  : 0.901  CI (0.894, 0.908)
  MI attack        : 52.3%  Wilson CI (50.9%, 53.7%)

Outputs:
  results/statistical_tests.json  — all test results
  results/statistical_tests.txt   — human-readable report

Usage:
    # With real prediction files from evaluate_all.py
    python scripts/statistical_tests.py \\
        --preds_dir results/reproduced \\
        --n_bootstrap 2000

    # Verify paper arithmetic only (no predictions needed)
    python scripts/statistical_tests.py --verify_paper_only
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats


# ---------------------------------------------------------------------------
# DeLong AUROC confidence interval
# ---------------------------------------------------------------------------

def _delong_auc_variance(y_true: np.ndarray, y_score: np.ndarray) -> Tuple[float, float]:
    """
    Compute AUROC and its variance using the DeLong et al. (1988) method.

    Reference:
        DeLong ER, DeLong DM, Clarke-Pearson DL.
        Comparing the areas under two or more correlated receiver operating
        characteristic curves: a nonparametric approach.
        Biometrics 1988;44(3):837-845.
        DOI: 10.2307/2531595

    Returns:
        (auroc, variance)
    """
    pos = y_score[y_true == 1]
    neg = y_score[y_true == 0]
    n1, n0 = len(pos), len(neg)

    # V10[i]: placement value for each positive sample
    v10 = np.array([
        np.mean((s > neg).astype(float) + 0.5 * (s == neg).astype(float))
        for s in pos
    ])
    # V01[j]: placement value for each negative sample
    v01 = np.array([
        np.mean((s < pos).astype(float) + 0.5 * (s == pos).astype(float))
        for s in neg
    ])

    auroc = float(np.mean(v10))
    var = (np.var(v10) / n1) + (np.var(v01) / n0)
    return auroc, float(var)


def delong_ci(
    y_true: np.ndarray,
    y_score: np.ndarray,
    confidence: float = 0.95,
) -> Tuple[float, float, float]:
    """
    DeLong AUROC with confidence interval.

    Returns:
        (auroc, lower, upper)
    """
    auroc, var = _delong_auc_variance(y_true, y_score)
    se = math.sqrt(var)
    z = stats.norm.ppf((1 + confidence) / 2)
    lower = max(0.0, auroc - z * se)
    upper = min(1.0, auroc + z * se)
    return auroc, lower, upper


# ---------------------------------------------------------------------------
# Bootstrap CI
# ---------------------------------------------------------------------------

def bootstrap_auroc_ci(
    y_true: np.ndarray,
    y_score: np.ndarray,
    n_bootstrap: int = 2000,
    confidence: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float, float]:
    """
    Bootstrap percentile CI for AUROC.

    Returns:
        (auroc, lower, upper)
    """
    from sklearn.metrics import roc_auc_score

    rng = np.random.default_rng(seed)
    n = len(y_true)
    auroc_base = float(roc_auc_score(y_true, y_score))
    boot_aurocs = []

    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        yt, ys = y_true[idx], y_score[idx]
        # Need both classes present
        if len(np.unique(yt)) < 2:
            continue
        try:
            boot_aurocs.append(float(roc_auc_score(yt, ys)))
        except Exception:
            continue

    alpha = 1 - confidence
    lower = float(np.percentile(boot_aurocs, 100 * alpha / 2))
    upper = float(np.percentile(boot_aurocs, 100 * (1 - alpha / 2)))
    return auroc_base, lower, upper


# ---------------------------------------------------------------------------
# Wilson CI for proportions
# ---------------------------------------------------------------------------

def wilson_ci(
    p: float,
    n: int,
    confidence: float = 0.95,
) -> Tuple[float, float]:
    """
    Wilson score CI.

    Paper uses this for MI attack accuracy: p=0.523, n=1000.
    Expected: (0.509, 0.537)
    """
    z = stats.norm.ppf((1 + confidence) / 2)
    denom = 1 + z**2 / n
    centre = (p + z**2 / (2 * n)) / denom
    margin = z * math.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / denom
    return max(0.0, centre - margin), min(1.0, centre + margin)


# ---------------------------------------------------------------------------
# DeLong two-model comparison (pairwise)
# ---------------------------------------------------------------------------

def delong_compare(
    y_true: np.ndarray,
    y_score_a: np.ndarray,
    y_score_b: np.ndarray,
) -> Tuple[float, float, float]:
    """
    DeLong test to compare two AUROCs on the same test set.
    Returns (auc_a, auc_b, p_value).
    """
    auc_a, var_a = _delong_auc_variance(y_true, y_score_a)
    auc_b, var_b = _delong_auc_variance(y_true, y_score_b)

    # Covariance term (zero if models are independent — conservative)
    diff = auc_a - auc_b
    se = math.sqrt(var_a + var_b)
    z = diff / se if se > 0 else 0.0
    p_value = float(2 * (1 - stats.norm.cdf(abs(z))))
    return float(auc_a), float(auc_b), p_value


# ---------------------------------------------------------------------------
# Paper arithmetic verification (no predictions needed)
# ---------------------------------------------------------------------------

def verify_paper_numbers() -> dict:
    """
    Verify every CI and statistic reported in the paper using
    published point estimates and sample sizes.
    """
    results = {}

    # MI attack Wilson CI: p=0.523, n=1000
    lo, hi = wilson_ci(0.523, 1000)
    results["mi_attack_wilson_ci"] = {
        "p": 0.523, "n": 1000,
        "ci_lower": round(lo, 3),
        "ci_upper": round(hi, 3),
        "paper_lower": 0.509,
        "paper_upper": 0.537,
        "pass": abs(lo - 0.509) < 0.002 and abs(hi - 0.537) < 0.002,
    }

    # AUROC CIs via DeLong approximation on synthetic scores
    # (Exact DeLong needs real predictions; here we verify the CI width
    #  is consistent with the reported n=5000 test-set size.)
    tasks = [
        ("arrhythmia", 0.943, 0.937, 0.949),
        ("sepsis",     0.876, 0.869, 0.883),
        ("mortality",  0.901, 0.894, 0.908),
    ]
    for task, auc, lo_paper, hi_paper in tasks:
        # Width check: DeLong SE for AUROC ~ sqrt(auc*(1-auc)/n_eff)
        # At n=5000, expected SE ~ 0.003 → CI width ~ 0.012
        ci_width = hi_paper - lo_paper
        results[f"auroc_ci_{task}"] = {
            "auroc":      auc,
            "ci_lower":   lo_paper,
            "ci_upper":   hi_paper,
            "ci_width":   round(ci_width, 4),
            "expected_width_at_n5000": 0.012,
            "width_consistent": 0.008 <= ci_width <= 0.016,
        }

    return results


# ---------------------------------------------------------------------------
# Load predictions from evaluate_all.py output
# ---------------------------------------------------------------------------

def load_predictions(preds_dir: Path, task: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load y_true and y_score from results/reproduced/<task>_preds.npz.
    evaluate_all.py saves these during evaluation.
    """
    path = preds_dir / f"{task}_preds.npz"
    if not path.exists():
        raise FileNotFoundError(
            f"Prediction file not found: {path}\n"
            f"Run: python evaluate_all.py --config configs/main.yaml first."
        )
    data = np.load(path)
    return data["y_true"], data["y_score"]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="BioTwin-AgentNet DeLong tests and bootstrap CIs"
    )
    parser.add_argument("--preds_dir",        default="results/reproduced",
                        help="Directory with <task>_preds.npz from evaluate_all.py")
    parser.add_argument("--n_bootstrap",      type=int, default=2000,
                        help="Number of bootstrap replicates (default 2000)")
    parser.add_argument("--confidence",       type=float, default=0.95)
    parser.add_argument("--seed",             type=int, default=42)
    parser.add_argument("--output",           default="results/statistical_tests.json")
    parser.add_argument("--verify_paper_only", action="store_true",
                        help="Only verify paper arithmetic; do not load predictions")
    args = parser.parse_args()

    report: dict = {}
    lines: list[str] = [
        "=" * 70,
        " BioTwin-AgentNet Statistical Tests",
        "=" * 70,
        "",
    ]

    # Always run paper verification
    lines.append("--- Paper arithmetic verification (no data needed) ---")
    paper = verify_paper_numbers()
    report["paper_verification"] = paper

    mi = paper["mi_attack_wilson_ci"]
    lines.append(
        f"  MI attack Wilson CI: ({mi['ci_lower']:.3f}, {mi['ci_upper']:.3f})"
        f"  paper: ({mi['paper_lower']:.3f}, {mi['paper_upper']:.3f})"
        f"  {'PASS' if mi['pass'] else 'FAIL'}"
    )
    for task in ["arrhythmia", "sepsis", "mortality"]:
        ci = paper[f"auroc_ci_{task}"]
        lines.append(
            f"  AUROC CI {task:<12}: [{ci['ci_lower']:.3f}, {ci['ci_upper']:.3f}]"
            f"  width {ci['ci_width']:.4f}"
            f"  {'consistent' if ci['width_consistent'] else 'UNEXPECTED WIDTH'}"
        )
    lines.append("")

    if args.verify_paper_only:
        lines.append("(--verify_paper_only: skipping prediction-based tests)")
    else:
        # DeLong CI and bootstrap CI for each task
        preds_dir = Path(args.preds_dir)
        tasks = ["arrhythmia", "sepsis", "mortality"]
        paper_aurocs = {
            "arrhythmia": (0.943, 0.937, 0.949),
            "sepsis":     (0.876, 0.869, 0.883),
            "mortality":  (0.901, 0.894, 0.908),
        }

        report["delong"] = {}
        report["bootstrap"] = {}

        lines.append("--- DeLong AUROC CIs ---")
        for task in tasks:
            try:
                y_true, y_score = load_predictions(preds_dir, task)
                auc, lo, hi = delong_ci(y_true, y_score, args.confidence)
                auc_p, lo_p, hi_p = paper_aurocs[task]
                within = lo_p <= auc <= hi_p
                report["delong"][task] = {
                    "auroc": round(auc, 4),
                    "ci_lower": round(lo, 4),
                    "ci_upper": round(hi, 4),
                    "paper_auroc": auc_p,
                    "paper_ci": [lo_p, hi_p],
                    "auroc_within_paper_ci": within,
                }
                lines.append(
                    f"  {task:<12}: AUROC={auc:.4f} CI=[{lo:.4f},{hi:.4f}]"
                    f"  {'WITHIN paper CI' if within else 'OUTSIDE paper CI'}"
                )
            except FileNotFoundError as e:
                lines.append(f"  {task:<12}: {e}")
                report["delong"][task] = {"error": str(e)}

        lines.append("")
        lines.append("--- Bootstrap AUROC CIs ---")
        for task in tasks:
            try:
                y_true, y_score = load_predictions(preds_dir, task)
                auc, lo, hi = bootstrap_auroc_ci(
                    y_true, y_score,
                    n_bootstrap=args.n_bootstrap,
                    confidence=args.confidence,
                    seed=args.seed,
                )
                auc_p, lo_p, hi_p = paper_aurocs[task]
                report["bootstrap"][task] = {
                    "auroc": round(auc, 4),
                    "ci_lower": round(lo, 4),
                    "ci_upper": round(hi, 4),
                    "n_bootstrap": args.n_bootstrap,
                    "paper_auroc": auc_p,
                }
                lines.append(
                    f"  {task:<12}: AUROC={auc:.4f} Bootstrap CI=[{lo:.4f},{hi:.4f}]"
                    f"  (n_boot={args.n_bootstrap})"
                )
            except FileNotFoundError as e:
                lines.append(f"  {task:<12}: {e}")
                report["bootstrap"][task] = {"error": str(e)}

        lines.append("")
        lines.append("--- DeLong pairwise model comparisons (teacher vs baselines) ---")
        baselines = ["centralized_cnn", "fedavg", "fedhealth", "fedprox"]
        report["pairwise"] = {}
        for task in ["arrhythmia"]:
            try:
                y_true_t, y_score_t = load_predictions(preds_dir, f"teacher_{task}")
                for bl in baselines:
                    try:
                        _, y_score_bl = load_predictions(preds_dir, f"{bl}_{task}")
                        auc_t, auc_bl, p = delong_compare(y_true_t, y_score_t, y_score_bl)
                        key = f"teacher_vs_{bl}_{task}"
                        report["pairwise"][key] = {
                            "auc_teacher": round(auc_t, 4),
                            "auc_baseline": round(auc_bl, 4),
                            "p_value": round(p, 6),
                            "significant_at_0.05": p < 0.05,
                        }
                        lines.append(
                            f"  teacher vs {bl:<20} {task}: "
                            f"AUC {auc_t:.4f} vs {auc_bl:.4f}  p={p:.4f}"
                            f"  {'*' if p < 0.05 else 'ns'}"
                        )
                    except FileNotFoundError:
                        lines.append(f"  teacher vs {bl}: predictions missing")
            except FileNotFoundError:
                lines.append(f"  teacher_{task} predictions not found")

    # Save outputs
    lines += ["", "=" * 70]
    report_text = "\n".join(lines)

    out_json = Path(args.output)
    out_txt  = out_json.with_suffix(".txt")
    out_json.parent.mkdir(parents=True, exist_ok=True)

    with open(out_json, "w") as f:
        json.dump(report, f, indent=2)
    with open(out_txt, "w") as f:
        f.write(report_text)

    print(report_text)
    print(f"\nSaved: {out_json}")
    print(f"Saved: {out_txt}")


if __name__ == "__main__":
    main()
