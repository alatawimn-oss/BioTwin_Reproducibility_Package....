#!/usr/bin/env python3
"""
scripts/partition_dirichlet.py

Dirichlet non-IID data partitioning for federated learning experiments.

Splits the MIMIC-IV training set across N clients using a Dirichlet(alpha)
distribution over class labels, reproducing the heterogeneous FL setup
in the BioTwin-AgentNet paper.

Paper settings (Section III-B):
  Clients       : 100
  Dirichlet alpha: 0.5  (moderate heterogeneity)
  Tasks         : arrhythmia, sepsis, mortality (binary each)

Outputs (per task):
  data/partitions/<task>/client_<i>.txt  — patient IDs for each client
  data/partitions/<task>/partition_stats.json — per-client label distribution

Usage:
    python scripts/partition_dirichlet.py \\
        --train_ids data/splits/mimic4_train_ids.txt \\
        --labels_dir data/extracted/mimic4 \\
        --n_clients 100 \\
        --alpha 0.5 \\
        --seed 42 \\
        --tasks arrhythmia sepsis mortality

    # Quick smoke test with synthetic labels (no real data needed):
    python scripts/partition_dirichlet.py --synthetic --n_clients 100 --alpha 0.5
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))


# ---------------------------------------------------------------------------
# Core partitioning
# ---------------------------------------------------------------------------

def dirichlet_partition(
    indices: np.ndarray,
    labels: np.ndarray,
    n_clients: int,
    alpha: float,
    seed: int,
    min_samples: int = 5,
) -> List[np.ndarray]:
    """
    Partition `indices` across `n_clients` using Dirichlet(alpha) over classes.

    Args:
        indices:    Sample indices to partition (shape [N])
        labels:     Binary labels (shape [N]), values in {0, 1}
        n_clients:  Number of FL clients
        alpha:      Dirichlet concentration. Lower = more heterogeneous.
                    Paper uses alpha=0.5.
        seed:       RNG seed for reproducibility
        min_samples: Minimum samples per client (re-samples if violated)

    Returns:
        List of length n_clients, each element is an array of sample indices.
    """
    rng = np.random.default_rng(seed)
    classes = np.unique(labels)
    client_indices: List[List[int]] = [[] for _ in range(n_clients)]

    for cls in classes:
        cls_idx = indices[labels == cls]
        rng.shuffle(cls_idx)
        # Dirichlet proportions for this class
        proportions = rng.dirichlet(alpha=np.full(n_clients, alpha))
        # Convert to counts
        counts = (proportions * len(cls_idx)).astype(int)
        # Fix rounding
        diff = len(cls_idx) - counts.sum()
        if diff > 0:
            for i in rng.choice(n_clients, size=diff, replace=False):
                counts[i] += 1
        elif diff < 0:
            for i in rng.choice(n_clients, size=-diff, replace=False):
                if counts[i] > 0:
                    counts[i] -= 1

        # Assign
        start = 0
        for cid, cnt in enumerate(counts):
            client_indices[cid].extend(cls_idx[start:start + cnt].tolist())
            start += cnt

    # Shuffle each client's data
    for cid in range(n_clients):
        arr = np.array(client_indices[cid])
        rng.shuffle(arr)
        client_indices[cid] = arr

    return client_indices


def compute_partition_stats(
    client_partitions: List[np.ndarray],
    labels: np.ndarray,
    all_indices: np.ndarray,
) -> dict:
    """
    Compute per-client and global partition statistics.

    Returns dict with:
        per_client: list of {n_samples, n_pos, n_neg, pos_ratio}
        global: {min_n, max_n, mean_n, std_n, effective_n (Fedshare)}
    """
    # Build index-to-label map
    idx_to_label = {int(i): int(l) for i, l in zip(all_indices, labels)}

    per_client = []
    sizes = []
    for part in client_partitions:
        n = len(part)
        pos = sum(idx_to_label.get(int(i), 0) for i in part)
        neg = n - pos
        per_client.append({
            "n_samples": n,
            "n_pos":     pos,
            "n_neg":     neg,
            "pos_ratio": round(pos / n, 4) if n > 0 else 0.0,
        })
        sizes.append(n)

    sizes_arr = np.array(sizes, dtype=float)
    return {
        "per_client": per_client,
        "global": {
            "min_n":    int(np.min(sizes_arr)),
            "max_n":    int(np.max(sizes_arr)),
            "mean_n":   float(np.mean(sizes_arr)),
            "std_n":    float(np.std(sizes_arr)),
            "total_n":  int(np.sum(sizes_arr)),
            "n_clients": len(client_partitions),
            # Effective sample size (harmonic mean, used for FedAvg weight)
            "harmonic_mean_n": float(
                len(sizes_arr) / np.sum(1.0 / np.maximum(sizes_arr, 1))
            ),
        },
    }


# ---------------------------------------------------------------------------
# Synthetic label generator (for smoke tests)
# ---------------------------------------------------------------------------

def make_synthetic_labels(
    patient_ids: List[str],
    task: str,
    seed: int = 42,
) -> np.ndarray:
    """
    Generate synthetic binary labels for a task.
    Positive rates match approximate paper prevalence:
        arrhythmia ~25%, sepsis ~15%, mortality ~10%
    """
    rng = np.random.default_rng(seed)
    rates = {"arrhythmia": 0.25, "sepsis": 0.15, "mortality": 0.10}
    p = rates.get(task, 0.20)
    return rng.binomial(1, p, size=len(patient_ids)).astype(int)


# ---------------------------------------------------------------------------
# Real label loader (requires preprocessed HDF5)
# ---------------------------------------------------------------------------

def load_labels_from_hdf5(
    patient_ids: List[str],
    labels_dir: Path,
    task: str,
) -> np.ndarray:
    """
    Load binary labels for each patient from the preprocessed HDF5 file.
    Requires data/preprocess.py to have been run first.

    HDF5 structure (from data/preprocess.py):
        /patients/<patient_id>/label_<task>  (scalar int)
    """
    try:
        import h5py
    except ImportError:
        raise ImportError("h5py required: pip install h5py --break-system-packages")

    h5_path = labels_dir / "mimic4_processed.h5"
    if not h5_path.exists():
        raise FileNotFoundError(
            f"Preprocessed file not found: {h5_path}\n"
            f"Run: python data/preprocess.py first."
        )

    labels = []
    with h5py.File(h5_path, "r") as f:
        for pid in patient_ids:
            key = f"patients/{pid}/label_{task}"
            if key in f:
                labels.append(int(f[key][()]))
            else:
                labels.append(0)  # missing → negative
    return np.array(labels, dtype=int)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Dirichlet non-IID partition for BioTwin-AgentNet FL"
    )
    parser.add_argument("--train_ids",   default="data/splits/mimic4_train_ids.txt",
                        help="File with one patient ID per line")
    parser.add_argument("--labels_dir",  default="data/extracted/mimic4",
                        help="Directory containing mimic4_processed.h5")
    parser.add_argument("--out_dir",     default="data/partitions",
                        help="Output directory for partition files")
    parser.add_argument("--n_clients",   type=int,   default=100)
    parser.add_argument("--alpha",       type=float, default=0.5,
                        help="Dirichlet alpha (0.5=paper setting)")
    parser.add_argument("--seed",        type=int,   default=42)
    parser.add_argument("--tasks",       nargs="+",
                        default=["arrhythmia", "sepsis", "mortality"])
    parser.add_argument("--synthetic",   action="store_true",
                        help="Use synthetic labels (smoke test; does not need real data)")
    args = parser.parse_args()

    # Load patient IDs
    train_path = Path(args.train_ids)
    if not train_path.exists():
        print(f"[Error] Train IDs file not found: {train_path}")
        sys.exit(1)

    with open(train_path) as f:
        patient_ids = [line.strip() for line in f if line.strip()]

    n = len(patient_ids)
    indices = np.arange(n)
    print(f"Loaded {n} patient IDs from {train_path}")
    print(f"n_clients={args.n_clients}  alpha={args.alpha}  seed={args.seed}")
    print()

    out_root = Path(args.out_dir)

    for task in args.tasks:
        print(f"Partitioning task: {task}")
        task_dir = out_root / task
        task_dir.mkdir(parents=True, exist_ok=True)

        # Load labels
        if args.synthetic:
            labels = make_synthetic_labels(patient_ids, task, seed=args.seed)
            print(f"  Using synthetic labels (pos rate {labels.mean():.2f})")
        else:
            try:
                labels = load_labels_from_hdf5(
                    patient_ids, Path(args.labels_dir), task
                )
                print(f"  Loaded real labels (pos rate {labels.mean():.2f})")
            except (FileNotFoundError, ImportError) as e:
                print(f"  [Warning] {e}")
                print(f"  Falling back to synthetic labels.")
                labels = make_synthetic_labels(patient_ids, task, seed=args.seed)

        # Partition
        partitions = dirichlet_partition(
            indices=indices,
            labels=labels,
            n_clients=args.n_clients,
            alpha=args.alpha,
            seed=args.seed,
        )

        # Write per-client ID files
        for cid, part in enumerate(partitions):
            client_file = task_dir / f"client_{cid:03d}.txt"
            with open(client_file, "w") as f:
                for idx in part:
                    f.write(f"{patient_ids[idx]}\n")

        # Write stats
        stats = compute_partition_stats(partitions, labels, indices)
        stats["alpha"] = args.alpha
        stats["seed"]  = args.seed
        stats["task"]  = task
        stats["n_clients"] = args.n_clients

        stats_path = task_dir / "partition_stats.json"
        with open(stats_path, "w") as f:
            json.dump(stats, f, indent=2)

        g = stats["global"]
        print(f"  Clients: {g['n_clients']}  "
              f"min={g['min_n']}  max={g['max_n']}  "
              f"mean={g['mean_n']:.1f}  std={g['std_n']:.1f}")
        print(f"  Saved to {task_dir}/")
        print()

    print("Partition complete.")
    print(f"Load these files in train.py via --partition_dir {out_root}")


if __name__ == "__main__":
    main()
