#!/usr/bin/env bash
# scripts/run_main.sh
#
# Train and evaluate the main BioTwin-AgentNet model only
# (teacher + student, phases 1–3). No baselines, no ablations.
#
# Usage:
#   bash scripts/run_main.sh [--device cpu|cuda] [--seed 42]
#   bash scripts/run_main.sh --phase 1          # phase 1 only
#   bash scripts/run_main.sh --skip_training    # eval only

set -euo pipefail

DEVICE="cpu"
SEED=42
CONFIG="configs/main.yaml"
OUTPUT_DIR="checkpoints"
RESULTS_DIR="results/reproduced"
PHASE="all"
SKIP_TRAINING=0
USE_DP="--use_dp"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --device)        DEVICE="$2";      shift 2 ;;
        --seed)          SEED="$2";        shift 2 ;;
        --config)        CONFIG="$2";      shift 2 ;;
        --output_dir)    OUTPUT_DIR="$2";  shift 2 ;;
        --results_dir)   RESULTS_DIR="$2"; shift 2 ;;
        --phase)         PHASE="$2";       shift 2 ;;
        --skip_training) SKIP_TRAINING=1;  shift   ;;
        --no_dp)         USE_DP="";        shift   ;;
        --help)
            echo "Usage: $0 [--device cpu|cuda] [--seed 42] [--phase 1|2|3|all]"
            echo "         [--skip_training] [--no_dp]"
            exit 0
            ;;
        *) echo "[Error] Unknown argument: $1"; exit 1 ;;
    esac
done

if [[ -z "${WATERMARK_SECRET_SEED:-}" ]]; then
    echo "[ERROR] WATERMARK_SECRET_SEED environment variable is not set."
    exit 1
fi

echo "========================================================"
echo " BioTwin-AgentNet — Main Model Pipeline"
echo " Phase: $PHASE | Device: $DEVICE | Seed: $SEED"
echo "========================================================"

mkdir -p "$OUTPUT_DIR"/{phase1,phase2,phase3}
mkdir -p "$RESULTS_DIR" results/{comparison,figures}

# Training
if [[ $SKIP_TRAINING -eq 0 ]]; then
    echo ""
    echo "[1/3] Training (phase $PHASE)..."
    python train.py \
        --phase "$PHASE" \
        --config "$CONFIG" \
        --output_dir "$OUTPUT_DIR" \
        --device "$DEVICE" \
        $USE_DP \
        --seed "$SEED"
    echo "      Training complete."
else
    echo "[1/3] SKIPPED (--skip_training)"
fi

# Evaluate main model only
echo ""
echo "[2/3] Evaluating main model..."
python evaluate_all.py \
    --config "$CONFIG" \
    --output_dir "$OUTPUT_DIR" \
    --results_dir "$RESULTS_DIR" \
    --device "$DEVICE" \
    --batch_size 64 \
    --seed "$SEED" \
    --only main
echo "      Evaluation complete."

# Comparison
echo ""
echo "[3/3] Comparing with paper targets..."
set +e
python compare_results.py \
    --results_dir "$RESULTS_DIR" \
    --output_dir results/comparison \
    --tolerance 0.01
STATUS=$?
set -e

echo ""
echo "========================================================"
echo " Done. Compare status: $STATUS (0=PASS, 1=FAIL, 2=INCOMPLETE)"
echo "========================================================"
exit $STATUS
