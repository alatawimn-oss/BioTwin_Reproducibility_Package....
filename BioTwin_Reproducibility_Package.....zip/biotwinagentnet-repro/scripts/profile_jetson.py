#!/usr/bin/env python3
"""
scripts/profile_jetson.py

Edge deployment profiling script for BioTwin-AgentNet student model on
NVIDIA Jetson Nano (4 GB).

Paper targets (Table 6):
  Inference latency : 47 ms per sample
  Energy per infer  : 112 mJ
  Model size (INT8) : 0.45 MB
  MAML adaptation   : 23.1 ms (5-shot, 5 inner steps)

This script:
  1. Loads the INT8-quantised student checkpoint.
  2. Runs 1000 forward passes and reports mean / std / p95 latency.
  3. Estimates energy via tegrastats if running on Jetson; falls back to
     CPU power estimation using psutil on other platforms.
  4. Reports model size on disk.
  5. Runs a MAML 5-shot adaptation and reports wall-clock time.
  6. Saves a JSON report to results/edge_profile.json.

Usage (on Jetson Nano or any machine for latency/size):
    python scripts/profile_jetson.py \\
        --checkpoint checkpoints/phase3/student_int8.pt \\
        --config configs/main.yaml \\
        --device cpu \\
        --n_trials 1000 \\
        --batch_size 1

    # To simulate the paper's Jetson environment (no GPU required):
    python scripts/profile_jetson.py --simulate_jetson

Environment variables:
    WATERMARK_SECRET_SEED — required only if watermark verification is included
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import yaml

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.student import StudentLSTM
from src.models.quantization import quantize_model_dynamic
from src.meta.maml import MAMLWrapper
from src.utils.seeding import set_global_seed
from src.utils.checkpointing import load_checkpoint


# ---------------------------------------------------------------------------
# Tegrastats energy reader (Jetson only)
# ---------------------------------------------------------------------------

def _read_tegrastats_power_mw() -> float | None:
    """
    Read instantaneous SoC power from tegrastats on Jetson.
    Returns milliwatts or None if not on Jetson.
    """
    tegrastats = Path("/usr/bin/tegrastats")
    if not tegrastats.exists():
        return None
    try:
        import subprocess, re
        result = subprocess.run(
            [str(tegrastats), "--interval", "100"],
            capture_output=True, text=True, timeout=0.5,
        )
        # tegrastats output: ... POM_5V_CPU 450/300 POM_5V_GPU 0/0 ...
        # Sum all POM_5V_* current readings (mW)
        matches = re.findall(r"POM_5V_\w+ (\d+)/\d+", result.stdout)
        if matches:
            return sum(int(m) for m in matches)
    except Exception:
        pass
    return None


def _estimate_cpu_power_mw() -> float:
    """
    Fallback: estimate CPU power via psutil (not accurate on non-Jetson).
    Returns a fixed estimate of 2000 mW for desktop/server CPUs
    or uses RAPL if available on Linux x86.
    """
    try:
        import psutil
        # Try RAPL energy counters (Linux x86 only)
        rapl_path = Path("/sys/class/powercap/intel-rapl/intel-rapl:0/energy_uj")
        if rapl_path.exists():
            e0 = int(rapl_path.read_text())
            time.sleep(0.1)
            e1 = int(rapl_path.read_text())
            return (e1 - e0) / 100.0  # uJ / 100ms = mW
    except Exception:
        pass
    return 2000.0  # conservative desktop estimate


# ---------------------------------------------------------------------------
# Profiling functions
# ---------------------------------------------------------------------------

def profile_inference(
    model: torch.nn.Module,
    n_features: int,
    seq_len: int,
    n_trials: int,
    batch_size: int,
    device: torch.device,
    warmup: int = 50,
) -> dict:
    """
    Measure per-sample inference latency.

    Returns dict with keys:
        mean_ms, std_ms, p50_ms, p95_ms, p99_ms,
        min_ms, max_ms, n_trials
    """
    model.eval()
    x = torch.randn(batch_size, seq_len, n_features, device=device)

    # Warmup
    with torch.no_grad():
        for _ in range(warmup):
            _ = model(x)

    if device.type == "cuda":
        torch.cuda.synchronize()

    latencies = []
    with torch.no_grad():
        for _ in range(n_trials):
            t0 = time.perf_counter()
            _ = model(x)
            if device.type == "cuda":
                torch.cuda.synchronize()
            t1 = time.perf_counter()
            latencies.append((t1 - t0) * 1000.0 / batch_size)  # ms/sample

    arr = np.array(latencies)
    return {
        "mean_ms":   float(np.mean(arr)),
        "std_ms":    float(np.std(arr)),
        "p50_ms":    float(np.percentile(arr, 50)),
        "p95_ms":    float(np.percentile(arr, 95)),
        "p99_ms":    float(np.percentile(arr, 99)),
        "min_ms":    float(np.min(arr)),
        "max_ms":    float(np.max(arr)),
        "n_trials":  n_trials,
    }


def profile_energy(
    model: torch.nn.Module,
    n_features: int,
    seq_len: int,
    device: torch.device,
    n_samples: int = 100,
) -> dict:
    """
    Estimate energy per inference in millijoules.
    Uses tegrastats on Jetson; falls back to RAPL or fixed estimate otherwise.
    """
    model.eval()
    x = torch.randn(1, seq_len, n_features, device=device)

    power_mw = _read_tegrastats_power_mw()
    source = "tegrastats"
    if power_mw is None:
        power_mw = _estimate_cpu_power_mw()
        source = "rapl_or_estimate"

    # Time n_samples inferences
    with torch.no_grad():
        t0 = time.perf_counter()
        for _ in range(n_samples):
            _ = model(x)
        if device.type == "cuda":
            torch.cuda.synchronize()
        t1 = time.perf_counter()

    inference_time_s = (t1 - t0) / n_samples
    energy_mj = power_mw * inference_time_s  # mW * s = mJ

    return {
        "energy_mj":          float(energy_mj),
        "power_mw":           float(power_mw),
        "inference_time_ms":  float(inference_time_s * 1000),
        "energy_source":      source,
        "paper_target_mj":    112.0,
        "on_jetson":          source == "tegrastats",
    }


def profile_model_size(checkpoint_path: Path) -> dict:
    """Report model file size on disk."""
    if not checkpoint_path.exists():
        return {"size_mb": None, "path": str(checkpoint_path), "exists": False}
    size_bytes = checkpoint_path.stat().st_size
    size_mb = size_bytes / 1e6
    return {
        "size_mb":         float(size_mb),
        "size_bytes":      int(size_bytes),
        "path":            str(checkpoint_path),
        "paper_target_mb": 0.45,
        "exists":          True,
    }


def profile_maml_adaptation(
    model: torch.nn.Module,
    n_features: int,
    seq_len: int,
    device: torch.device,
    n_way: int = 2,
    k_shot: int = 5,
    inner_steps: int = 5,
    inner_lr: float = 0.01,
    n_trials: int = 50,
) -> dict:
    """
    Measure MAML 5-shot adaptation wall-clock time.

    Paper: 23.1 ms for 2-way 5-shot, 5 inner steps on Jetson Nano.
    """
    maml = MAMLWrapper(
        model=model,
        inner_lr=inner_lr,
        inner_steps=inner_steps,
        first_order=True,  # FOMAML for edge speed
    )

    times = []
    for _ in range(n_trials):
        # Support set: k_shot samples per class
        support_x = torch.randn(n_way * k_shot, seq_len, n_features, device=device)
        support_y = torch.cat([
            torch.zeros(k_shot, dtype=torch.long),
            torch.ones(k_shot, dtype=torch.long),
        ]).to(device)

        t0 = time.perf_counter()
        _ = maml.adapt(support_x, support_y)
        t1 = time.perf_counter()
        times.append((t1 - t0) * 1000.0)

    arr = np.array(times)
    return {
        "mean_ms":        float(np.mean(arr)),
        "std_ms":         float(np.std(arr)),
        "p95_ms":         float(np.percentile(arr, 95)),
        "n_way":          n_way,
        "k_shot":         k_shot,
        "inner_steps":    inner_steps,
        "inner_lr":       inner_lr,
        "n_trials":       n_trials,
        "paper_target_ms": 23.1,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="BioTwin-AgentNet edge profiling (Jetson Nano / CPU)"
    )
    parser.add_argument("--checkpoint",   default="checkpoints/phase3/student_int8.pt")
    parser.add_argument("--config",       default="configs/main.yaml")
    parser.add_argument("--device",       default="cpu", choices=["cpu", "cuda"])
    parser.add_argument("--n_trials",     type=int, default=1000)
    parser.add_argument("--batch_size",   type=int, default=1,
                        help="Batch size for latency (paper uses 1)")
    parser.add_argument("--output",       default="results/edge_profile.json")
    parser.add_argument("--simulate_jetson", action="store_true",
                        help="Force CPU mode and show paper target comparisons")
    parser.add_argument("--seed",         type=int, default=42)
    args = parser.parse_args()

    set_global_seed(args.seed)

    if args.simulate_jetson:
        args.device = "cpu"

    device = torch.device(args.device)

    # Load config
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    n_features = cfg.get("n_features", 127)
    seq_len    = cfg.get("seq_len", 48)
    n_classes  = cfg.get("n_classes", 2)
    hidden     = cfg.get("student", {}).get("hidden_size", 128)
    n_layers   = cfg.get("student", {}).get("num_layers", 2)

    print("=" * 60)
    print(" BioTwin-AgentNet Edge Profiling")
    print("=" * 60)
    print(f" Device     : {args.device}")
    print(f" Checkpoint : {args.checkpoint}")
    print(f" n_trials   : {args.n_trials}")
    print()

    # Build student model
    student = StudentLSTM(
        n_features=n_features,
        hidden_size=hidden,
        num_layers=n_layers,
        n_classes=n_classes,
        dropout=0.0,
    )

    # Load checkpoint if available
    ckpt_path = Path(args.checkpoint)
    if ckpt_path.exists():
        print(f" Loading checkpoint: {ckpt_path}")
        load_checkpoint(str(ckpt_path), student)
    else:
        print(f" [Warning] Checkpoint not found: {ckpt_path}")
        print(f"           Profiling with random weights.")

    # Quantise if loading FP32 checkpoint
    if ckpt_path.suffix == ".pt" and "int8" not in ckpt_path.name:
        student = quantize_model_dynamic(student)

    student = student.to(device)
    student.eval()

    report: dict = {
        "device":       args.device,
        "checkpoint":   str(ckpt_path),
        "seed":         args.seed,
        "n_features":   n_features,
        "seq_len":      seq_len,
    }

    # 1. Inference latency
    print(" Profiling inference latency...")
    lat = profile_inference(
        student, n_features, seq_len,
        n_trials=args.n_trials,
        batch_size=args.batch_size,
        device=device,
    )
    report["latency"] = lat
    print(f"   Mean  : {lat['mean_ms']:.2f} ms  (paper: 47.0 ms)")
    print(f"   P95   : {lat['p95_ms']:.2f} ms")
    print(f"   Std   : {lat['std_ms']:.2f} ms")

    # 2. Energy
    print(" Profiling energy...")
    eng = profile_energy(student, n_features, seq_len, device)
    report["energy"] = eng
    print(f"   Energy: {eng['energy_mj']:.1f} mJ  (paper: 112.0 mJ)")
    print(f"   Source: {eng['energy_source']}")
    if not eng["on_jetson"]:
        print("   [Note] Not on Jetson; energy estimate is approximate.")

    # 3. Model size
    print(" Measuring model size...")
    sz = profile_model_size(ckpt_path)
    report["model_size"] = sz
    if sz["exists"]:
        print(f"   Size: {sz['size_mb']:.3f} MB  (paper: 0.45 MB)")
    else:
        print(f"   [Warning] File not found — cannot measure size.")

    # 4. MAML adaptation time
    print(" Profiling MAML 5-shot adaptation...")
    # Use FP32 student for MAML (gradients required)
    student_fp32 = StudentLSTM(
        n_features=n_features, hidden_size=hidden,
        num_layers=n_layers, n_classes=n_classes, dropout=0.0,
    ).to(device)
    if ckpt_path.exists():
        try:
            load_checkpoint(str(ckpt_path).replace("int8", "final"), student_fp32)
        except Exception:
            pass  # use random weights

    adapt = profile_maml_adaptation(student_fp32, n_features, seq_len, device)
    report["maml_adaptation"] = adapt
    print(f"   Mean adaptation: {adapt['mean_ms']:.2f} ms  (paper: 23.1 ms)")
    print(f"   P95             : {adapt['p95_ms']:.2f} ms")

    # 5. Save report
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(report, f, indent=2)
    print()
    print(f" Report saved: {out_path}")

    # 6. Summary vs paper
    print()
    print(" Paper vs Reproduced:")
    print(f"   Latency  : {lat['mean_ms']:6.1f} ms  | paper 47.0 ms")
    print(f"   Energy   : {eng['energy_mj']:6.1f} mJ  | paper 112.0 mJ")
    if sz["exists"]:
        print(f"   Size     : {sz['size_mb']:6.3f} MB  | paper 0.45 MB")
    print(f"   Adapt    : {adapt['mean_ms']:6.1f} ms  | paper 23.1 ms")
    print("=" * 60)


if __name__ == "__main__":
    main()
