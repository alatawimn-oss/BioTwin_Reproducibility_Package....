#!/usr/bin/env bash
# scripts/run_all.sh
#
# Full BioTwin-AgentNet reproducibility pipeline:
#   Phase 1  — teacher FL training
#   Phase 2  — knowledge distillation on eICU
#   Phase 3  — student FL + INT8 quantization
#   Baselines — centralized CNN, FedAvg, FedHealth, FedProx
#   Ablations — no_fl, no_dp, no_he, no_cl, no_ml, no_kd, no_blockchain
#   Evaluation — all models, all tasks, privacy attacks, timing
#   Comparison — reproduced vs paper numbers
#   Figures   — all paper figures
#
# Usage:
#   bash scripts/run_all.sh [--device cpu|cuda] [--seed 42] [--config configs/main.yaml]
#
# Environment:
#   WATERMARK_SECRET_SEED — required; set before running
#   CUDA_VISIBLE_DEVICES  — optional; GPU selection

set -euo pipefail

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEVICE="cpu"
SEED=42
CONFIG="configs/main.yaml"
OUTPUT_DIR="checkpoints"
RESULTS_DIR="results/reproduced"
SKIP_TRAINING=0
SKIP_BASELINES=0
SKIP_ABLATIONS=0

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --device)        DEVICE="$2";      shift 2 ;;
        --seed)          SEED="$2";        shift 2 ;;
        --config)        CONFIG="$2";      shift 2 ;;
        --output_dir)    OUTPUT_DIR="$2";  shift 2 ;;
        --results_dir)   RESULTS_DIR="$2"; shift 2 ;;
        --skip_training) SKIP_TRAINING=1;  shift   ;;
        --skip_baselines) SKIP_BASELINES=1; shift  ;;
        --skip_ablations) SKIP_ABLATIONS=1; shift  ;;
        --help)
            echo "Usage: $0 [--device cpu|cuda] [--seed 42] [--config path]"
            echo "         [--skip_training] [--skip_baselines] [--skip_ablations]"
            exit 0
            ;;
        *) echo "[Error] Unknown argument: $1"; exit 1 ;;
    esac
done

# ---------------------------------------------------------------------------
# Validate environment
# ---------------------------------------------------------------------------
if [[ -z "${WATERMARK_SECRET_SEED:-}" ]]; then
    echo "[ERROR] WATERMARK_SECRET_SEED environment variable is not set."
    echo "        Set it before running: export WATERMARK_SECRET_SEED=<your-secret>"
    exit 1
fi

echo "========================================================================"
echo " BioTwin-AgentNet Full Reproducibility Pipeline"
echo "========================================================================"
echo " Config      : $CONFIG"
echo " Device      : $DEVICE"
echo " Seed        : $SEED"
echo " Output dir  : $OUTPUT_DIR"
echo " Results dir : $RESULTS_DIR"
echo "========================================================================"
echo ""

START_TIME=$(date +%s)

# ---------------------------------------------------------------------------
# Step 1: Create output directories
# ---------------------------------------------------------------------------
echo "[1/10] Creating output directories..."
mkdir -p "$OUTPUT_DIR"/{phase1,phase2,phase3,baselines,ablations}
mkdir -p "$RESULTS_DIR"
mkdir -p results/{comparison,figures,expected}
mkdir -p data/partitions
echo "      Done."

# ---------------------------------------------------------------------------
# Step 2: Main training (phases 1-3)
# ---------------------------------------------------------------------------
if [[ $SKIP_TRAINING -eq 0 ]]; then
    echo ""
    echo "[2/10] Training main model (phases 1–3)..."
    python train.py \
        --phase all \
        --config "$CONFIG" \
        --output_dir "$OUTPUT_DIR" \
        --device "$DEVICE" \
        --use_dp \
        --seed "$SEED"
    echo "      Phase 1–3 training complete."
else
    echo "[2/10] SKIPPED (--skip_training)"
fi

# ---------------------------------------------------------------------------
# Step 3: Baseline training
# ---------------------------------------------------------------------------
if [[ $SKIP_BASELINES -eq 0 ]]; then
    echo ""
    echo "[3/10] Training baselines..."
    bash scripts/run_baselines.sh \
        --device "$DEVICE" \
        --seed "$SEED" \
        --config "$CONFIG" \
        --output_dir "$OUTPUT_DIR"
    echo "      Baselines complete."
else
    echo "[3/10] SKIPPED (--skip_baselines)"
fi

# ---------------------------------------------------------------------------
# Step 4: Ablation training
# ---------------------------------------------------------------------------
if [[ $SKIP_ABLATIONS -eq 0 ]]; then
    echo ""
    echo "[4/10] Training ablations..."
    bash scripts/run_ablation.sh \
        --device "$DEVICE" \
        --seed "$SEED" \
        --config "$CONFIG" \
        --output_dir "$OUTPUT_DIR"
    echo "      Ablations complete."
else
    echo "[4/10] SKIPPED (--skip_ablations)"
fi

# ---------------------------------------------------------------------------
# Step 5: Evaluation
# ---------------------------------------------------------------------------
echo ""
echo "[5/10] Running full evaluation..."
python evaluate_all.py \
    --config "$CONFIG" \
    --output_dir "$OUTPUT_DIR" \
    --results_dir "$RESULTS_DIR" \
    --device "$DEVICE" \
    --batch_size 64 \
    --seed "$SEED" \
    --only all
echo "      Evaluation complete."

# ---------------------------------------------------------------------------
# Step 6: Per-model test report
# ---------------------------------------------------------------------------
echo ""
echo "[6/10] Running test.py (teacher + student)..."
python test.py \
    --config "$CONFIG" \
    --output_dir "$OUTPUT_DIR" \
    --results_dir "$RESULTS_DIR" \
    --device "$DEVICE" \
    --model all \
    --eval all \
    --seed "$SEED"
echo "      Test report saved to $RESULTS_DIR/test_results.json"

# ---------------------------------------------------------------------------
# Step 7: Compare reproduced vs paper
# ---------------------------------------------------------------------------
echo ""
echo "[7/10] Comparing reproduced results with paper..."
set +e
python compare_results.py \
    --results_dir "$RESULTS_DIR" \
    --output_dir results/comparison \
    --tolerance 0.01
COMPARE_STATUS=$?
set -e
if [[ $COMPARE_STATUS -eq 0 ]]; then
    echo "      [PASS] All metrics within tolerance."
elif [[ $COMPARE_STATUS -eq 2 ]]; then
    echo "      [INCOMPLETE] Some results missing; run evaluate_all.py."
else
    echo "      [FAIL] Some metrics outside tolerance — see results/comparison/comparison.txt"
fi

# ---------------------------------------------------------------------------
# Step 7b: Dirichlet non-IID partition (for Figures 5 and 9)
# ---------------------------------------------------------------------------
echo ""
echo "[7b/10] Generating Dirichlet non-IID FL partitions..."
python scripts/partition_dirichlet.py \
    --train_ids data/splits/mimic4_train_ids.txt \
    --n_clients 100 \
    --alpha 0.5 \
    --seed "$SEED" \
    --tasks arrhythmia sepsis mortality
echo "       Partitions saved to data/partitions/"

# ---------------------------------------------------------------------------
# Step 7c: Statistical tests (DeLong CIs, bootstrap CIs, Wilson CI)
# ---------------------------------------------------------------------------
echo ""
echo "[7c/10] Running statistical tests..."
python scripts/statistical_tests.py \
    --preds_dir "$RESULTS_DIR" \
    --n_bootstrap 2000 \
    --seed "$SEED" \
    --output results/statistical_tests.json
echo "       Statistical tests saved to results/statistical_tests.{json,txt}"

# ---------------------------------------------------------------------------
# Step 7d: Verify paper arithmetic (pure-Python, no trained models needed)
# ---------------------------------------------------------------------------
echo ""
echo "[7d/10] Verifying paper arithmetic consistency..."
set +e
python scripts/verify_paper_numbers.py
VERIFY_STATUS=$?
set -e
if [[ $VERIFY_STATUS -eq 0 ]]; then
    echo "       [PASS] All paper arithmetic checks passed."
else
    echo "       [WARN] Some paper arithmetic checks failed — see output above."
fi

# ---------------------------------------------------------------------------
# Step 8: Edge profiling (Jetson Nano targets)
# ---------------------------------------------------------------------------
echo ""
echo "[8/10] Profiling edge deployment..."
python scripts/profile_jetson.py \
    --checkpoint checkpoints/phase3/student_int8.pt \
    --config "$CONFIG" \
    --device "$DEVICE" \
    --n_trials 1000 \
    --seed "$SEED" \
    --output results/edge_profile.json
echo "       Edge profile saved to results/edge_profile.json"

# ---------------------------------------------------------------------------
# Step 9: Generate figures
# ---------------------------------------------------------------------------
echo ""
echo "[9/10] Generating paper figures..."
python figures/make_figures.py \
    --results_dir "$RESULTS_DIR" \
    --out_dir results/figures
echo "      Figures saved to results/figures/"

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
END_TIME=$(date +%s)
ELAPSED=$(( END_TIME - START_TIME ))
MINUTES=$(( ELAPSED / 60 ))
SECONDS=$(( ELAPSED % 60 ))

echo ""
echo "========================================================================"
echo " Pipeline complete in ${MINUTES}m ${SECONDS}s"
echo "========================================================================"
echo ""
echo " Outputs:"
echo "   Checkpoints : $OUTPUT_DIR/"
echo "   Results CSV : $RESULTS_DIR/all_results.csv"
echo "   Privacy CSV : $RESULTS_DIR/privacy_results.csv"
echo "   Timing CSV  : $RESULTS_DIR/timing_results.csv"
echo "   Comparison  : results/comparison/comparison.txt"
echo "   Figures     : results/figures/*.png"
echo ""
echo " Exit status from compare_results.py: $COMPARE_STATUS (0=pass|1=fail|2=incomplete)"
echo " Paper arithmetic verify:            $VERIFY_STATUS   (0=pass|non-zero=fail)"
echo "========================================================================"
exit $COMPARE_STATUS
