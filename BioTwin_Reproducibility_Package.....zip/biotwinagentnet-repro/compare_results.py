"""
compare_results.py

Compare reproduced results against paper-reported numbers.

Reads:
  results/reproduced/all_results.csv
  results/reproduced/privacy_results.csv
  results/expected/paper_results.csv       (ground truth from paper)

Outputs:
  results/comparison/comparison_table.csv  — per-metric absolute + relative Δ
  results/comparison/comparison.txt        — human-readable summary

Paper tables reproduced:
  Table 3 — AUROC for arrhythmia, sepsis, mortality (teacher + baselines)
  Table 4 — Ablation AUROC deltas
  Table 5 — Privacy: MI attack, attribute inference
  Table 6 — Edge deployment: latency, energy, model size

Usage:
    python compare_results.py
    python compare_results.py --results_dir results/reproduced
    python compare_results.py --tolerance 0.01
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Paper ground-truth (hard-coded from paper; also in results/expected/)
# ---------------------------------------------------------------------------

PAPER_TABLE3 = {
    # (model_name, task): AUROC — from Table 5 of the paper
    ("biotwinagentnet_teacher", "arrhythmia"): 0.943,
    ("biotwinagentnet_teacher", "sepsis"):     0.876,
    ("biotwinagentnet_teacher", "mortality"):  0.901,
    ("baseline_centralized_cnn", "arrhythmia"): 0.877,
    ("baseline_centralized_cnn", "sepsis"):     0.842,
    ("baseline_centralized_cnn", "mortality"):  0.872,
    ("baseline_fedavg",          "arrhythmia"): 0.881,
    ("baseline_fedavg",          "sepsis"):     0.829,
    ("baseline_fedavg",          "mortality"):  0.864,
    ("baseline_fedhealth",       "arrhythmia"): 0.912,
    ("baseline_fedhealth",       "sepsis"):     0.856,
    ("baseline_fedhealth",       "mortality"):  0.879,
    ("baseline_fedprox",         "arrhythmia"): 0.908,
    ("baseline_fedprox",         "sepsis"):     0.853,
    ("baseline_fedprox",         "mortality"):  0.881,
}

# Ablation AUROC — Table 10 of the paper reports overall (continual-learning average) AUROC
# baseline = 0.891; task-specific arrhythmia values not separately stated in Table 10
PAPER_TABLE4 = {
    # (ablation_name, metric): value from Table 10
    ("ablation_no_fl",         "auroc"): 0.877,   # -0.014 (centralized CNN baseline)
    ("ablation_no_dp",         "auroc"): 0.910,   # +0.019
    ("ablation_no_he",         "auroc"): 0.889,   # -0.002
    ("ablation_no_cl",         "auroc"): 0.883,   # -0.008
    ("ablation_no_ml",         "auroc"): 0.867,   # -0.024
    ("ablation_no_kd",         "auroc"): 0.914,   # +0.023 (cloud teacher AUROC)
    ("ablation_no_blockchain", "auroc"): 0.889,   # -0.002
    ("ablation_no_fl",         "mi_pct"):  78.4,
    ("ablation_no_dp",         "mi_pct"):  78.4,
    ("ablation_no_he",         "mi_pct"):  72.6,
    ("ablation_no_cl",         "mi_pct"):  52.1,
    ("ablation_no_ml",         "mi_pct"):  52.5,
    ("ablation_no_kd",         "mi_pct"):  52.2,
    ("ablation_no_blockchain", "mi_pct"):  53.1,
    ("ablation_no_fl",         "latency_ms"): 243.0,
    ("ablation_no_kd",         "latency_ms"): 187.0,
    ("ablation_no_fl",         "score"): 67.6,   # deltaS = -32.4
    ("ablation_no_dp",         "score"): 92.8,   # deltaS = -7.2
    ("ablation_no_he",         "score"): 93.8,   # deltaS = -6.2
    ("ablation_no_cl",         "score"): 90.9,   # deltaS = -9.1
    ("ablation_no_ml",         "score"): 99.1,   # deltaS = -0.9
    ("ablation_no_kd",         "score"): 78.4,   # deltaS = -21.6
    ("ablation_no_blockchain", "score"): 81.7,   # deltaS = -18.3
}

PAPER_TABLE5 = {
    # Privacy evaluation (Section 3.3)
    "mi_accuracy_pct":       52.3,
    "mi_ci_lo_pct":          50.9,
    "mi_ci_hi_pct":          53.7,
    "attr_above_random_pct": 11.3,
    "wm_bit_agreement":      0.987,
}

PAPER_TABLE6_EDGE = {
    # Table 8: Computational Efficiency
    "inference_latency_ms":  47.0,
    "energy_mj":            112.0,
    "model_size_mb":          0.45,
    "cloud_auroc":            0.921,  # cloud teacher
    "edge_auroc":             0.891,  # deployed student (continual-learning average)
}

PAPER_TABLE9_COMM = {
    # Table 9: Communication Efficiency
    "fedavg_per_round_mb":    42.8,
    "fedavg_rounds":         203,
    "fedavg_total_gb":         8.69,
    "biotwin_per_round_mb":    5.6,
    "biotwin_rounds":        142,
    "biotwin_total_gb":        0.80,
    "reduction_pct":          90.8,   # (8.69-0.80)/8.69
}

# Keep old name for compatibility
PAPER_TABLE6 = PAPER_TABLE6_EDGE


# ---------------------------------------------------------------------------
# CSV reader helpers
# ---------------------------------------------------------------------------

def read_csv(path: Path) -> List[Dict]:
    if not path.exists():
        return []
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def float_or_nan(s) -> float:
    try:
        v = float(s)
        return v
    except (TypeError, ValueError):
        return float("nan")


# ---------------------------------------------------------------------------
# Comparison logic
# ---------------------------------------------------------------------------

def compare_table3(repro_rows: List[Dict], tolerance: float) -> List[Dict]:
    """Compare Table 3 (main + baselines AUROC)."""
    results = []
    for (model, task), paper_auroc in PAPER_TABLE3.items():
        # Find matching row in reproduced CSV
        match = next(
            (r for r in repro_rows
             if r.get("model") == model and r.get("task") == task),
            None,
        )
        repro_auroc = float_or_nan(match.get("auroc")) if match else float("nan")
        delta       = repro_auroc - paper_auroc
        status      = _status(delta, tolerance)

        results.append({
            "table":        "Table3",
            "model":        model,
            "task":         task,
            "metric":       "AUROC",
            "paper":        paper_auroc,
            "reproduced":   repro_auroc,
            "delta":        delta,
            "delta_pct":    (delta / paper_auroc * 100) if paper_auroc else float("nan"),
            "within_tol":   status,
        })
    return results


def compare_table4(repro_rows: List[Dict], tolerance: float) -> List[Dict]:
    """Compare Table 4 (ablation: AUROC, MI%, latency, score) from Table 10 of paper."""
    # CSV column name for each metric key in PAPER_TABLE4
    METRIC_CSV_COL = {
        "auroc":      "auroc",
        "mi_pct":     "mi_accuracy_pct",
        "latency_ms": "mean_latency_ms",
        "score":      "system_score",
    }
    # Tolerance multiplier per metric (AUROC tight; others wider)
    METRIC_TOL_MULT = {
        "auroc":      1.0,
        "mi_pct":     10.0,
        "latency_ms": 20.0,
        "score":       5.0,
    }

    results = []
    for (ablation, metric), paper_val in PAPER_TABLE4.items():
        csv_col = METRIC_CSV_COL.get(metric, metric)
        match = next(
            (r for r in repro_rows if r.get("model") == ablation),
            None,
        )
        repro_val = float_or_nan(match.get(csv_col)) if match else float("nan")
        delta     = repro_val - paper_val
        tol       = tolerance * METRIC_TOL_MULT.get(metric, 1.0)
        status    = _status(delta, tol)

        results.append({
            "table":      "Table4",
            "model":      ablation,
            "task":       metric,
            "metric":     metric,
            "paper":      paper_val,
            "reproduced": repro_val,
            "delta":      delta,
            "delta_pct":  (delta / paper_val * 100) if paper_val else float("nan"),
            "within_tol": status,
        })
    return results


def compare_table5(priv_rows: List[Dict], tolerance: float) -> List[Dict]:
    """Compare Table 5 (privacy metrics)."""
    results = []
    if not priv_rows:
        return results

    row = priv_rows[0]  # single-row CSV

    comparisons = [
        ("mi_accuracy_pct",       "mi_mi_accuracy_pct",      "MI attack acc (%)"),
        ("mi_ci_lo_pct",          "mi_wilson_ci_lo_pct",     "MI Wilson CI lo (%)"),
        ("mi_ci_hi_pct",          "mi_wilson_ci_hi_pct",     "MI Wilson CI hi (%)"),
        ("attr_above_random_pct", "ai_above_random_pct",     "Attr inf above random (pp)"),
        ("wm_bit_agreement",      "wm_fp32_bit_agreement",   "Watermark bit agreement"),
    ]

    for paper_key, csv_key, label in comparisons:
        paper_val = PAPER_TABLE5.get(paper_key, float("nan"))
        repro_val = float_or_nan(row.get(csv_key))
        delta     = repro_val - paper_val
        status    = _status(delta, tolerance * 10)  # privacy metrics have wider tolerance

        results.append({
            "table":      "Table5",
            "model":      "biotwinagentnet_teacher",
            "task":       "privacy",
            "metric":     label,
            "paper":      paper_val,
            "reproduced": repro_val,
            "delta":      delta,
            "delta_pct":  (delta / paper_val * 100) if paper_val else float("nan"),
            "within_tol": status,
        })
    return results


def compare_table6(timing_rows: List[Dict], tolerance: float) -> List[Dict]:
    """Compare Table 6 (edge deployment metrics)."""
    results = []
    # Find INT8 student row
    row = next(
        (r for r in timing_rows if r.get("name") == "biotwinagentnet_student_int8"),
        None,
    )
    if row is None:
        return results

    comparisons = [
        ("inference_latency_ms", "mean_latency_ms", "Inference latency (ms)"),
        ("model_size_mb",        "size_mb",         "Model size (MB)"),
    ]

    for paper_key, csv_key, label in comparisons:
        paper_val = PAPER_TABLE6.get(paper_key, float("nan"))
        repro_val = float_or_nan(row.get(csv_key))
        delta     = repro_val - paper_val
        status    = _status(delta, paper_val * 0.20)  # 20% tolerance on hardware metrics

        results.append({
            "table":      "Table6",
            "model":      "biotwinagentnet_student_int8",
            "task":       "edge",
            "metric":     label,
            "paper":      paper_val,
            "reproduced": repro_val,
            "delta":      delta,
            "delta_pct":  (delta / paper_val * 100) if paper_val else float("nan"),
            "within_tol": status,
        })
    return results


def _status(delta: float, tolerance: float) -> str:
    if np.isnan(delta):
        return "MISSING"
    if abs(delta) <= tolerance:
        return "PASS"
    return "FAIL"


# ---------------------------------------------------------------------------
# Human-readable summary
# ---------------------------------------------------------------------------

HEADER_WIDTH = 70

def build_summary(all_rows: List[Dict]) -> str:
    lines = []
    lines.append("=" * HEADER_WIDTH)
    lines.append("BioTwin-AgentNet Reproducibility Report")
    lines.append("=" * HEADER_WIDTH)

    tables = sorted({r["table"] for r in all_rows})
    for tbl in tables:
        tbl_rows = [r for r in all_rows if r["table"] == tbl]
        pass_n   = sum(1 for r in tbl_rows if r["within_tol"] == "PASS")
        fail_n   = sum(1 for r in tbl_rows if r["within_tol"] == "FAIL")
        miss_n   = sum(1 for r in tbl_rows if r["within_tol"] == "MISSING")
        total    = len(tbl_rows)

        lines.append(f"\n{tbl}  ({pass_n}/{total} pass, {fail_n} fail, {miss_n} missing)")
        lines.append("-" * HEADER_WIDTH)
        lines.append(
            f"  {'Model':<40} {'Task':<12} {'Metric':<30} "
            f"{'Paper':>8} {'Repro':>8} {'Delta':>8} {'Status':>8}"
        )
        lines.append("  " + "-" * (HEADER_WIDTH - 2))

        for r in tbl_rows:
            model_short = r["model"].replace("biotwinagentnet_", "btan_")
            model_short = model_short.replace("baseline_", "bl_")
            model_short = model_short.replace("ablation_", "abl_")
            paper_s  = f"{r['paper']:.4f}" if not _nan(r["paper"]) else "—"
            repro_s  = f"{float(r['reproduced']):.4f}" if not _nan(r["reproduced"]) else "—"
            delta_s  = f"{float(r['delta']):+.4f}" if not _nan(r["delta"]) else "—"
            status_s = r["within_tol"]
            lines.append(
                f"  {model_short:<40} {r['task']:<12} {r['metric']:<30} "
                f"{paper_s:>8} {repro_s:>8} {delta_s:>8} {status_s:>8}"
            )

    lines.append("\n" + "=" * HEADER_WIDTH)
    return "\n".join(lines)


def _nan(v) -> bool:
    try:
        return np.isnan(float(v))
    except (TypeError, ValueError):
        return True


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="Compare reproduced vs paper results")
    parser.add_argument("--results_dir",  type=str, default="results/reproduced")
    parser.add_argument("--expected_dir", type=str, default="results/expected")
    parser.add_argument("--output_dir",   type=str, default="results/comparison")
    parser.add_argument(
        "--tolerance",
        type=float,
        default=0.01,
        help="Maximum absolute AUROC delta to count as PASS (default: 0.01)",
    )
    return parser.parse_args()


def main():
    args    = parse_args()
    res_dir = Path(args.results_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load reproduced CSVs
    repro_rows   = read_csv(res_dir / "all_results.csv")
    priv_rows    = read_csv(res_dir / "privacy_results.csv")
    timing_rows  = read_csv(res_dir / "timing_results.csv")

    if not repro_rows:
        print(f"[Warning] No data found in {res_dir / 'all_results.csv'}. "
              "Run evaluate_all.py first.")

    # Build comparison rows
    all_rows = []
    all_rows.extend(compare_table3(repro_rows, args.tolerance))
    all_rows.extend(compare_table4(repro_rows, args.tolerance))
    all_rows.extend(compare_table5(priv_rows,  args.tolerance))
    all_rows.extend(compare_table6(timing_rows, args.tolerance))

    # Write comparison CSV
    if all_rows:
        fieldnames = [
            "table", "model", "task", "metric",
            "paper", "reproduced", "delta", "delta_pct", "within_tol",
        ]
        with open(out_dir / "comparison_table.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, "") for k in fieldnames})
        print(f"Comparison CSV → {out_dir / 'comparison_table.csv'}")

    # Write human-readable summary
    summary = build_summary(all_rows)
    print("\n" + summary)
    with open(out_dir / "comparison.txt", "w") as f:
        f.write(summary + "\n")
    print(f"\nComparison report → {out_dir / 'comparison.txt'}")

    # Exit code: 0 if all non-missing results pass, 1 otherwise
    fails = [r for r in all_rows if r["within_tol"] == "FAIL"]
    if fails:
        print(f"\n[FAIL] {len(fails)} metric(s) outside tolerance={args.tolerance}.")
        sys.exit(1)
    else:
        missing = [r for r in all_rows if r["within_tol"] == "MISSING"]
        if missing:
            print(f"\n[INCOMPLETE] {len(missing)} metric(s) missing (run evaluate_all.py first).")
            sys.exit(2)
        print(f"\n[PASS] All {len(all_rows)} reproduced metrics within tolerance={args.tolerance}.")
        sys.exit(0)


if __name__ == "__main__":
    main()
